#!/usr/bin/env python3
"""Reproduce los cálculos DC documentales de Auditoria Auditor 6-L.

No modela transitorios, comportamiento térmico, protecciones, EMC ni hardware.
Los valores marcados como estimados son estimaciones documentales, no medidas.
"""
import json

V_NOMINAL = 5.0
I_SOURCE_NOMINAL = 10.0
SCENARIOS = [
    ("típico guía", 2.3, "estimación del repositorio"),
    ("pico guía", 5.0, "estimación del repositorio"),
    ("envolvente documental", 7.0, "Pi 2.5 A + Solo 2 A estimados + pantalla 2 A recomendados + ZE29A <0.5 A"),
]

results = []
for name, current, basis in SCENARIOS:
    results.append({
        "name": name,
        "load_a": current,
        "power_w_at_5v": round(V_NOMINAL * current, 2),
        "nominal_utilization_percent": round(100 * current / I_SOURCE_NOMINAL, 1),
        "nominal_capacity_pass": current <= I_SOURCE_NOMINAL,
        "basis": basis,
    })

print(json.dumps({
    "model_type": "analytical DC arithmetic; not SPICE or a hardware test",
    "source_nominal_a": I_SOURCE_NOMINAL,
    "scenarios": results,
    "verdict": "NO-GO: nominal capacity alone does not validate wiring or safety",
}, indent=2, ensure_ascii=False))
