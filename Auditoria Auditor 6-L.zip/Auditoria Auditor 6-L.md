# Auditoría eléctrica independiente

## Alcoholímetro - Auditor 6-L

**Fecha:** 21 de octubre de 2026  
**Repositorio auditado:** GuillermoAladro/Alcoholimetro  
**Rama y revisión:** main, commit 84be97669a9efec43e79b3dadc4af5e87458c41a  
**Rol:** auditoría documental y modelo analítico de la alimentación y las interconexiones eléctricas.

> **VEREDICTO: NO-GO PARA ENERGIZAR.** La topología de papel tiene partes coherentes, pero la protección del raíl de 5 V no está coordinada, el conector de carga del Solo no está dimensionado, la entrada de red no tiene un esquema confirmado y el diseño actual A no está incluido como fuente completa en el repo. No se hizo montaje físico ni ensayo de banco; por tanto no se puede afirmar que el circuito real funcione.

## 1. Resumen ejecutivo

La guía principal describe una fuente Mean Well LRS-50-5 de 5 V/10 A, cuatro cargas de 5 V, tierra de protección a la carcasa, UART de 3,3 V entre la Raspberry Pi 3B+ y el sensor Winsen ZE29A, y conexiones HDMI, CSI y USB. La asignación de terminales en MONTAJE-GENERAL coincide con el plano oficial de Mean Well. La ficha de la fuente dentro de componentes, sin embargo, invierte la numeración de los bornes AC y DC; esa contradicción debe corregirse antes de usar las fichas para fabricar.

El modelo de potencia pasa solamente la comprobación de capacidad nominal de la fuente. La carga típica de 2,3 A y el pico de 5 A son estimaciones del propio repo. Un escenario de 7 A formado por máximos/recomendaciones publicados también queda por debajo de 10 A, pero no son medidas reales. El punto más débil está aguas abajo: un cable de troncal de 0,75 mm2 se declara para 6 A mientras que la fuente puede entrar en limitación por encima de 10 A. La versión antigua no tiene fusibles de rama; el diseño A los añade, pero el tramo común anterior a las ramas sigue sin protección demostrada.

Además, el puerto USB-A a tornillo no tiene corriente nominal publicada y se pretende usar para un lector cuya corriente de 2 A es una estimación. USB-IF limita a 1,5 A el puerto dedicado de carga BC 1.2. Un puente entre D+ y D- anuncia ese tipo de puerto; no convierte un conector desconocido en una fuente certificada de 2 A.

La decisión del diseño A, fechada el 21-10-2026, es posterior a la guía de montaje del 20-10-2026. El propio documento dice que A fue el elegido y que cambia protecciones, ubicación, botón, cámara, Wi-Fi y recorrido del aire. El archivo de definición A y su script se citan como documentos externos, pero no están en el árbol Git auditado. La guía antigua no se ha rehecho sobre A. No se debe fabricar una mezcla de las dos versiones.

## 2. Alcance y método

Se tomó el árbol versionado completo de main en el commit indicado. El repositorio afirma que es un esquema de papel y que no se ha medido; esta auditoría conserva esa distinción.

| Cobertura del árbol Git | Revisión |
|---|---|
| 234 archivos versionados: 69 Markdown, 150 PDF, 4 PNG, 4 SVG, 4 ZIP, 1 XLSX, 1 DXF y 1 shell script | Inventariados; el CSV incluido en el ZIP conserva cada ruta, tamaño y hash del objeto Git |
| 69 archivos Markdown | Leídos/indexados; se revisaron las guías principales, pendientes y las fichas de los 31 componentes |
| 150 PDF locales | Texto extraído de todos; 2 no tienen texto seleccionable y se inspeccionaron visualmente. El PDF de ruta larga se leyó directamente desde Git |
| 4 PNG y 4 SVG | Diagramas de cableado revisados visualmente y cotejados con las descripciones |
| 4 ZIP | 66 miembros inventariados; los 62 PDF de especificaciones USB dentro de los ZIP se extrajeron; los modelos STEP se identificaron como CAD mecánico |
| XLSX, DXF y script | Se inspeccionaron todas las celdas del BOM, las entidades del dibujo y el contenido del script. El script no se ejecutó |
| Ausencias relevantes | No están hardware/, firmware/, docs/, carcasa/, diseno-cajon-A.md ni cajon/specs.py, aunque se mencionan en la documentación |

La revisión combina lectura de documentación y datasheets, inspección visual de diagramas y cálculos de DC. Se consultaron además páginas oficiales de Mean Well, Raspberry Pi, Winsen, USB-IF y el BOE. No se simularon transitorios de conmutación, comportamiento de protecciones, temperatura, aislamiento ni puesta a tierra. No se conectó ningún equipo real.

## 3. Estado de las pruebas

| Puerta de auditoría | Resultado | Evidencia y límite |
|---|---|---|
| Pinout principal de la LRS-50-5 en MONTAJE-GENERAL | PASS documental | El datasheet oficial asigna 1=AC/L, 2=AC/N, 3=FG, 4=DC -V y 5=DC +V |
| Ficha de componente de la LRS-50-5 | FAIL documental | La tabla de bornes de su README da el orden inverso para AC y DC |
| UART Pi-ZE29A y niveles GPIO | PASS documental, pendiente de placa | TX/RX están cruzados correctamente; el manual especifica UART TTL de 3,3 V |
| Potencia nominal de la fuente | PASS solo en modelo | 10 A disponibles; el escenario conservador documental da hasta 7 A, con cargas no verificadas |
| Troncal de 5 V frente a cortocircuito | FAIL | Cable indicado para 6 A; protección de sobrecorriente de la fuente puede superar 10 A y no hay fusible principal DC documentado |
| Borne USB-A usado por el Solo | FAIL / no demostrado | Sin rating en la pieza; 2 A del Solo es una estimación y excede el límite de referencia USB BC 1.2 de 1,5 A |
| Tensión en las cargas | FAIL / no demostrado | 5,20 V se fija sin tolerancia de margen; el cálculo documental del cable micro-USB deja 4,76 V en la Pi a 2,5 A |
| C14, fusible e interruptor de 230 V | HOLD | Los dibujos del vendedor no coinciden; no hay esquema medido del módulo recibido |
| Tierra de protección y continuidad de carcasa | HOLD | No hay ensayo físico de PE; soldadura, ojales, secciones y tierras parásitas siguen abiertos |
| Diseño que se va a fabricar | FAIL documental | El montaje detallado pertenece a la versión anterior; el diseño A elegido no está completo en el repo |

## 4. Hallazgos y soluciones

### F-01 - Protección insuficiente del bus de 5 V

**Prioridad crítica.** El montaje antiguo lleva la salida de 10 A de la LRS-50-5 directamente a dos WAGO y luego a cuatro cargas, sin fusible o PTC en el troncal ni fusible por rama. El cable rojo/negro de 0,75 mm2 se lista con 6 A. La ficha de la fuente calcula una zona de limitación de aproximadamente 10,6 a 14,4 A cuando se ajusta a 5,20 V. En un cortocircuito, la fuente puede intentar entregar más corriente que la asignación indicada para el troncal.

El diseño A citado añade fusibles de 3 A, 3 A, 3 A y 2 A a las ramas. Es una mejora de la arquitectura, pero el tramo desde la fuente hasta el punto de distribución sigue compartido y no queda protegido por esos fusibles. Los valores de las ramas son provisionales hasta medir los consumos y verificar el rating del cable, los conectores y sus curvas de disparo.

**Solución:** añadir protección DC principal junto a la salida positiva de la fuente, antes del troncal, y protección individual en la salida positiva de cada rama. Dimensionar el troncal para la corriente y el régimen de fallo que permitan la fuente y su fusible principal. Elegir cada fusible para proteger el elemento de menor rating de su rama. Usar cobre con sección y aislamiento identificados; separar físicamente la DC de la red o instalar una barrera aprobada. Recalcular y probar la coordinación antes de liberar.

### F-02 - La salida USB-A no acredita la corriente del Solo

**Prioridad crítica.** El bloque USB-A #18 no publica corriente máxima. Las fichas de conectores USB-A comparables en el propio repo suelen indicar 1 a 1,5 A; el límite de referencia de USB-IF para un puerto BC 1.2 DCP es 1,5 A. El pico de 2 A atribuido al Solo no está medido ni publicado. Un puente D+/D- solo anuncia el tipo de puerto de carga BC 1.2 y no crea capacidad adicional. El cable A-C tampoco tiene verificados la resistencia CC de 56 kOhm, la orientación del codo ni su resistencia eléctrica.

**Solución:** retirar ese bloque del camino de 2 A salvo que fabricante y ensayo acrediten el rating total del bloque, terminales y pistas. Sustituirlo por una salida de alimentación con rating continuo y de pico documentado y limitación de corriente, adecuada al conector/carga USB-C del Solo. Usar un cable compatible y probar reconocimiento, tensión y corriente a plena carga. Mantener los 2 A como estimación hasta medir.

### F-03 - El ajuste de 5,20 V no demuestra tensión válida en los dispositivos

**Prioridad alta.** El ZE29A admite 5,0 V +/-0,3 V, con máximo de 5,3 V. La instrucción de 5,20 V deja solo 0,10 V nominales hasta ese máximo, antes de considerar tolerancia, rizado y caída. La propia ficha de la LRS indica salida ajustable y rizado; su protección OVP se activa en torno a 5,9-7,3 V, muy por encima del máximo del sensor y del rango de una salida USB de 5 V. Esa OVP no es una protección fina para las cargas.

La ficha del latiguillo micro-USB calcula, en un caso desfavorable a 2,5 A, unos 4,76 V en el lado Pi aun con 5,20 V en la WAGO. El valor de la fuente no es el valor en los pines de la placa. Raspberry Pi recomienda una alimentación de 5,1 V para esta clase de placa, y su product brief indica una fuente externa de 5 V/2,5 A.

**Solución:** no fijar 5,20 V como valor de liberación. Usar una salida común de 5 V dentro de la ventana de todos los periféricos y añadir una rama de baja impedancia/regulada para la Pi, por ejemplo un regulador DC-DC de 5,1 V con corriente suficiente y limitación/OVP propia. La selección final depende de las medidas reales. Medir tensión y rizado en cada conector, con cargas simultáneas y durante arranque; comprobar Pi sin avisos de subtensión y sensor siempre dentro de 4,7-5,3 V. Añadir protección de sobretensión secundaria cuyo umbral respete el máximo del periférico más restrictivo.

### F-04 - Entrada de 230 V sin esquema verificable

**Prioridad crítica.** El módulo C14 #15 se vende como entrada, portafusibles e interruptor iluminado de cuatro pines. El repo informa que sus dos diagramas de vendedor discrepan y que las reseñas observan una lámpara que no se apaga. No se sabe si el interruptor es de uno o dos polos, qué pin lleva el fusible ni si el esquema de la pieza concreta coincide con el cableado W2-W5. El Schuko puede insertarse en ambas orientaciones.

**Solución:** no energizar el módulo actual mientras no se haya medido y documentado, sin tensión, su continuidad pin a pin, polos de interruptor y fusible con y sin fusible. La alternativa de liberación es un conjunto de entrada con rating, esquema y certificaciones identificables, desconexión apropiada de los conductores activos y alivio mecánico del cable. Mantener la tierra de protección continua y sin interruptor. La parte de red debe aprobarla una persona cualificada antes de enchufar.

### F-05 - La tierra de protección no está probada y puede tener retornos no intencionados

**Prioridad crítica.** La guía propone un solo espárrago M4 con cinco ojales. No hay material/espesor de chapa ni método de soldadura confirmados, el propio README advierte que un punto único es un modo único de fallo y el resultado no se ha medido. Separadores de nylon no garantizan aislamiento: pueden existir puentes metálicos por tornillos, agujeros de la Pi, blindajes HDMI/USB y el coaxial RP-SMA al techo.

**Solución:** elaborar un esquema de bonding que una al PE todas las partes metálicas accesibles con uniones diseñadas y verificables. Decidir si el 0 V de DC queda flotante o se une a PE en un punto de diseño; medir continuidad entre el 0 V y carcasa en el conjunto completo para encontrar puentes parásitos. Comprobar la continuidad PE a cada panel con un comprobador de alta corriente y criterio de la norma aplicable; no aceptar una lectura de continuidad con multímetro como ensayo de seguridad.

### F-06 - El documento vigente de montaje no es el diseño elegido

**Prioridad alta.** MONTAJE-GENERAL dice seguir la guía de 20-10-2026 y dedica un apartado a diferencias con el diseño A del 21-10-2026, que identifica como elegido. A elimina el botón, cambia el FFC por la cinta incluida, añade fusibles de rama, mueve fuente/C14 y modifica la red Wi-Fi y el tubo. No están versionados el documento A, su script ni el esquema mecánico completo. No se puede reconstruir con certeza la colocación, los cables ni los puntos de tierra actuales.

**Solución:** incorporar a Git la fuente firmada del diseño A, la BOM completa y el esquema actualizado de potencia/señales. Elegir A como única referencia por ser la decisión posterior registrada en el propio montaje. Revisar todas las rutas que el documento marca como modificadas y regenerar las figuras antes de fabricar.

### F-07 - La ficha de la fuente invierte la numeración oficial

**Prioridad alta de documentación.** La página oficial de la LRS-50 y MONTAJE-GENERAL coinciden: pin 1 AC/L, 2 AC/N, 3 FG, 4 DC -V, 5 DC +V. En cambio, componentes/meanwell-lrs-50-5/README.md, tabla de especificaciones, escribe 1=-V, 2=+V, 3=FG, 4=AC/L, 5=AC/N. El dibujo de alimentación usa el orden correcto, pero la contradicción puede inducir a cablear la red en los bornes DC si alguien sigue la ficha equivocada.

**Solución:** corregir esa tabla y marcar la hoja oficial como autoridad. Añadir una etiqueta del fabricante en el diagrama y comprobar las marcas impresas de la unidad antes de cablearla. No trasladar una numeración deducida de otra revisión o dibujo.

### F-08 - La disposición física no acredita separación ni temperatura

**Prioridad alta.** La LRS es una fuente con bornes de entrada de red que quedan accesibles durante montaje; el propio dossier del proyecto reconoce esa condición. La ubicación final de los bornes, la tapa/barreira, el recorrido de cables AC/DC, los pasacables y la ventilación no están cerrados. La guía cita temperaturas de funcionamiento de 0-50 C para Pi/cámara, 10-40 C para ZE29A y menos de 40 C para el Solo. No hay prueba de temperatura con carcasa cerrada.

**Solución:** separar compartimento de red y SELV, cubrir bornes, mantener las distancias/aislamiento exigidos por el diseño final, retener cables y proteger bordes de chapa. Verificar ventilación y hacer prueba térmica estabilizada con carga máxima simultánea y temperatura ambiente de peor caso. No superar el límite del componente más restrictivo.

### F-09 - Conectores/polaridad sin verificar

**Prioridad alta antes de alimentar.** No están confirmados el paso/tipo del J1 del ZE29A, el color de cada hilo de la clavija, la polaridad del latiguillo micro-USB, el tipo de USB-C/A del cable de pantalla, la cara de contactos del FFC ni qué dos faston pertenecen al microinterruptor. El protocolo previo del propio montaje enumera las comprobaciones, pero ninguna está ejecutada porque las piezas aún no se han medido.

**Solución:** mantener las cargas desconectadas hasta marcar cada conector por número de pin y comprobar continuidad/polaridad con las piezas sin tensión. Para la cámara, comprobar el cable FFC contra el pinout antes de insertarlo; introducir o retirar el FFC solo con la Pi apagada. Nunca llevar 5 V a los GPIO: la Pi utiliza señales de 3,3 V.

### F-10 - El BOM y las herramientas no cierran todos los crimpados

**Prioridad media-alta.** La crimpadora de punteras #28 no está acreditada para terminales de anillo, faston, Dupont o JST. Las fichas indican calibres/marcas desconocidos en varios kits. La fijación Dupont tiene baja fuerza de extracción, problemática en una caja suspendida. Un crimpado pobre en PE o en 230 V puede causar calentamiento o pérdida de tierra.

**Solución:** seleccionar herramientas específicas para cada familia de terminal, cable y sección. Hacer muestras, inspección visual y prueba de tracción conforme al fabricante/estándar; fijar y aliviar tensión en los conectores de señal. Comprar terminales con rango de cable y tensión/corriente verificables.

## 5. Esquema corregido de principio

El dibujo siguiente corrige la arquitectura de alimentación y agrega las protecciones que faltan. Es una solución de diseño para revisión; no es un plano de fabricación certificado. Los fusibles DC y el regulador de Pi se dimensionan después de medir cargas y escoger cables/conectores reales.

![Esquema de principio corregido](esquema-corregido.svg)

| Red/conector | Conexión auditada | Criterio |
|---|---|---|
| Entrada de red | Schuko-C13 a módulo de entrada con esquema y rating verificables | Fusible según componente y arranque de la fuente; desconexión y alivio mecánico documentados |
| Fuente LRS-50-5 | Pin 1 AC/L; 2 AC/N; 3 FG; 4 DC -V; 5 DC +V | No usar la numeración errónea de la ficha #14 |
| Tierra de protección | PE de la entrada a chasis y a FG, con bonding aprobado | Medir cada panel con ensayo PE adecuado; no abrir ni interrumpir PE |
| Troncal DC | Pin 5 +V a F0 DC y después a bus +5 V; pin 4 -V a bus GND | F0 antes del troncal; cable y fusible coordinados con el límite de la fuente |
| Pi 3B+ | Rama protegida; micro-USB mediante cable de baja impedancia y/o regulador local de 5,1 V | Medir en la Pi con carga alta; mantener cero avisos de subtensión |
| SumUp Solo | Rama protegida a una interfaz de alimentación documentada para su corriente | No usar el bloque USB-A desconocido como fuente de 2 A |
| Pantalla 7 pulgadas | Rama protegida a Power IN USB-C, HDMI de Pi por separado | Confirmar tipo y corriente del cable que trae la pantalla |
| ZE29A | J1-1 a +5 V, J1-2 a GND; pin 4 RX a Pi físico 8 TX; pin 3 TX a Pi físico 10 RX | UART 9600, 8N1, niveles de 3,3 V; común GND de señal |
| Cámara / datos | CSI de Pi a cámara con FFC de contacto y orientación confirmados; AR9271 a USB de Pi | Insertar FFC solo con la Pi apagada; revisar la versión A para usar su cinta de 200 mm |
| Pulsador | Pi físico 11 GPIO17 a un contacto y físico 9 GND al otro, solo en versión antigua | El LED queda desconectado. El diseño A elimina el pulsador |

## 6. Modelo analítico de la alimentación

Se ejecutó un cálculo reproducible, incluido en el ZIP. Es un modelo DC de potencia y caídas documentadas; no es SPICE ni mide una fuente, cable o carga real.

| Escenario de papel | Cargas usadas | Corriente total | Potencia a 5 V | Resultado frente a 10 A |
|---|---|---:|---:|---|
| Típico de la guía | Estimación conjunta del montaje antiguo | 2,3 A | 11,5 W | Pasa capacidad nominal; 23% |
| Pico de la guía | Estimación conjunta del montaje antiguo | 5,0 A | 25 W | Pasa capacidad nominal; 50% |
| Envolvente de diseño | Pi 2,5 A + Solo 2 A estimados + pantalla 2 A recomendados + ZE29A <0,5 A | <7,0 A | <35 W | Pasa nominal; 70%, pero no son medidas |

La capacidad de 50 W de la fuente no es el impedimento principal. Los límites detectados son la protección del cable común, el rating desconocido de conectores, la caída en la entrada micro-USB de la Pi, el OVP grueso de la fuente y la incertidumbre de los datos de carga. El escenario de 7 A está construido con ratings/recomendaciones de fuentes distintas; no representa una prueba de consumo del equipo.

| Prueba del modelo | Cálculo | Estado |
|---|---|---|
| Fuente contra demanda documental | <7 A frente a 10 A nominales | PASS analítico condicionado |
| Troncal de 0,75 mm2 | 5 A estimados de pico frente a 6 A declarados | PASS solo en régimen estimado; margen pequeño |
| Cortocircuito DC | 10,6-14,4 A de límite citado frente a 6 A del cable | FAIL: requiere F0/cable coordinados |
| Borne USB-A del Solo | 2 A estimados frente a 1,5 A de referencia BC 1.2 y sin rating del bloque | FAIL/no demostrado |
| Pi a carga alta | 4,76 V calculados en caso desfavorable a 2,5 A desde una WAGO a 5,20 V | FAIL de margen; medir y corregir caída |
| ZE29A a 5,20 V | 0,10 V de margen nominal hasta el máximo 5,30 V | FAIL de margen de diseño sin tolerancia/OVP secundaria |
| Protección de sobretensión | OVP LRS 5,9-7,3 V | FAIL como protección de cargas de 5 V |

## 7. Matriz resumida de los 31 componentes

| # | Componente | Resultado de auditoría |
|---:|---|---|
| 1 | Raspberry Pi 3B+ | Pide alimentación adecuada de 5 V/2,5 A; medir tensión directamente en la placa con carga |
| 2 | SanDisk High Endurance | No es parte del circuito; probar autenticidad y configurar almacenamiento para operación continua |
| 3 | Camera Module 3 | La integración CSI es válida en papel; comprobar versión/revisión y temperatura |
| 4 | Cable FFC 50 cm | Orientación de contactos no especificada; diseño A dice usar la cinta incluida de 200 mm |
| 5 | Pantalla 7 pulgadas | Consumo y rango del modelo exacto no publicados; cable USB de alimentación no identificado por extremos |
| 6 | Winsen ZE29A | Pinout y UART de 3,3 V verificados; 5 V +/-0,3 V, menos de 500 mA; J1 no identificado |
| 7 | Cable JST-XH | No se ha confirmado que encaje en J1; fijar color/pin por continuidad |
| 8 | Tubo de silicona | Mecánico/neumático; diámetro interior/exterior y material en contacto no demostrados |
| 9 | SumUp Solo | Corriente de entrada y uso térmico/desatendido sin confirmar; requiere interfaz 5 V con rating |
| 10 | Cable USB-A a USB-C | CC 56 kOhm y orientación del codo sin verificar; su rating no valida el borne #18 |
| 11 | Pulsador arcade | La ficha antigua lo cablea como dos contactos; el diseño A lo elimina |
| 12 | Adaptador AR9271 | Alimentado desde USB de Pi; fabricante/chip de la unidad comprada sin verificar |
| 13 | Alargo RP-SMA | Verificar macho/hembra y si el blindaje crea un enlace 0 V-carcasas |
| 14 | Mean Well LRS-50-5 | Fuente correcta por capacidad; README invierte pines; AC accesible; añadir protección y validar térmica |
| 15 | Módulo C14 | Polos, fusible y lámpara sin esquema confirmado; NO-GO hasta caracterizar o sustituir |
| 16 | Fusible T2,5A | Tipo/curva/capacidad de corte y portafusible del módulo deben comprobarse |
| 17 | Cable Schuko-C13 | El enchufe es reversible; verificar PE, corriente, alivio de tensión y retención |
| 18 | Borne USB-A a tornillo | Rating no publicado; no liberar para la carga del Solo estimada en 2 A |
| 19 | Latiguillo micro-USB | Polaridad y cable real sin verificar; cálculo de caída de tensión insuficiente a 2,5 A |
| 20 | WAGO 221-415 | Rating nominal sobrado; verificar autenticidad, sección, preparación y que cada rama tenga protección |
| 21 | Cable 2 x 0,75 mm2 | 6 A declarados; no sirve como troncal sin protección frente a la limitación de la fuente |
| 22 | H05VV-F 3G1,5 | Sección de red plausible; terminaciones, tierra y separación física pendientes |
| 23 | Ojales M4 | Confirmar rango real para 1,5 mm2 y herramienta de crimpado |
| 24 | Arandelas dentadas | Ayudan al contacto; no sustituyen una prueba de continuidad PE |
| 25 | Espárrago M4 | Tipo y método de soldadura no confirmados; eslabón crítico de bonding |
| 26 | Tornillería M3-M6 | Material, longitudes y par de apriete no se acreditan con el anuncio |
| 27 | Faston aislados | Ancho, sección admitida y crimpado no confirmados; escoger terminal para cable real |
| 28 | Crimpadora/punteras | Es para punteras; no acreditar para Faston, ojales, Dupont o JST |
| 29 | Cables Dupont | Sin especificación de cobre/calibre; retención débil y alivio de tensión pendiente |
| 30 | Separadores M2,5 | Nylon no garantiza aislamiento por sí solo; medir puentes de tornillo/carcasa/masa |
| 31 | Pasacables de goma | Seleccionar según grosor real de chapa y proteger también las ranuras no circulares |

La matriz detallada con conexión, hallazgo y acción está en el CSV incluido en el ZIP.

## 8. Pruebas obligatorias antes de liberar

### A. Cierre de diseño

1. Añadir al repo el diseño A elegido, su BOM y la definición mecánica/eléctrica vigente.
2. Corregir el pinout de la ficha LRS y regenerar las figuras desde una única fuente.
3. Sustituir o documentar la entrada C14. Cerrar ratings de cables, bornes, conectores y fusibles de las ramas.
4. Acordar el esquema PE y el estado intencional de 0 V respecto a PE.

### B. Comprobaciones sin tensión

1. Caracterizar el C14 con continuidad: pinout, polos, portafusibles, lámpara y continuidad PE.
2. Inspeccionar polaridad, posición del pin 1 y tipo de cada conector. Revisar cualquier cable que podría poner 5 V en GPIO.
3. Comprobar continuidad de +5 V/GND sin cargas y ausencia de cortocircuito entre ellos, AC, PE y carcasa conforme al diseño.
4. Verificar el bonding de paneles, cajón, fuente, caja interior y chasis. Ensayar PE con instrumento/corriente que exija la norma aplicable.

### C. Ensayos de baja tensión con fuente de laboratorio

1. Usar una fuente DC aislada con límite de corriente; conectar una sola rama cada vez y sin la entrada de 230 V.
2. Medir consumo de arranque y sostenido de Pi, Solo, pantalla y sensor; después probar simultáneamente con el peor caso.
3. Medir tensión/rizado en la fuente y en cada conector, incluida la Pi bajo CPU, cámara y Wi-Fi. La Pi no debe registrar throttling por subtensión.
4. Comprobar que el ZE29A permanece dentro de 4,7-5,3 V y su UART nunca presenta 5 V en los GPIO.
5. Verificar el reconocimiento y corriente de carga del Solo con su cable definitivo. Repetir conectando/moviendo levemente el cable de pantalla para descartar cortes.
6. Comprobar limitación de corriente y OVP secundaria en cada salida, sin someter cargas reales a una sobretensión destructiva.

### D. Liberación de red y ambiente

Un electricista cualificado debe revisar y ensayar aislamiento, continuidad de PE, corriente de fuga, barreras/holguras, fusibles, switch, alivio de tensión y calentamiento antes del primer enchufe. Con la carcasa cerrada, hacer prueba térmica estable con máxima carga y ambiente máximo previsto. Conservar mediciones, instrumentos, condiciones y resultado.

**Criterio de salida:** no cambiar a GO hasta que todas las puertas bloqueantes tengan evidencia de ensayo y el diseño de montaje coincida con el diseño A versionado.

## 9. Fuentes principales

### Archivos del repositorio auditado

- MONTAJE-GENERAL.md, especialmente estado, W1-W29, pruebas previas, pendientes y diferencias con diseño A.
- componentes/pendientes.md, decisiones y medidas pendientes de las 31 fichas.
- componentes/meanwell-lrs-50-5/datasheets/MEAN_WELL_LRS-50_DATA_SHEET.pdf, página 4 para el mapa de terminales.
- componentes/meanwell-lrs-50-5/README.md, tabla de terminales con discrepancia en la línea 74.
- componentes/winsen-ze29a/datasheets/ze29a-c2h5oh.pdf, páginas 3-4 para tensión, corriente, pines y UART.
- componentes/raspberry-pi-3b-plus/datasheets/RP-008338-DS-2-raspberry-pi-3-b-plus-product-brief.pdf, alimentación y seguridad del periférico.
- componentes/cable-2x0-75-rojo-negro-10m/README.md y componentes/latiguillo-micro-usb-22awg/README.md, asignación y cálculos de cable.
- componentes/borne-usb-a-hembra-tornillo/README.md y componentes/cable-usb-a-usb-c-90-30cm/README.md, límites y dudas de USB.

### Fuentes primarias consultadas

- [Mean Well, LRS-50 series data sheet](https://www.meanwell.com/Upload/PDF/LRS-50/LRS-50-SPEC.PDF)
- [Raspberry Pi, documentación de alimentación y hardware](https://www.raspberrypi.com/documentation/computers/raspberry-pi.html)
- [Raspberry Pi 3B+, product brief oficial](https://pip-assets.raspberrypi.com/categories/532-raspberry-pi-3-model-b/documents/RP-008338-DS-2-raspberry-pi-3-b-plus-product-brief.pdf)
- [Winsen, manual ZE29A-C2H5OH](https://www.winsen-sensor.com/d/files/manual/ze29a-c2h5oh.pdf)
- [USB-IF, requisitos BC 1.2 para Dedicated Charging Port](https://compliance.usb.org/index.asp?Format=Standard&UpdateFile=Battery+Charging)
- [USB-IF, especificación Type-C 2.5 release 202603](https://www.usb.org/documents?items_per_page=50&order=name_1&page=2&search=&sort=desc)
- [BOE, REBT e ITC-BT-19](https://boe.es/buscar/act.php?id=BOE-A-2002-18099&lang=es&p=20250403&tn=0)

## 10. Conclusión del auditor

La conexión lógica de los pines principales puede organizarse correctamente y la fuente tiene potencia nominal suficiente para los escenarios de papel. Eso no demuestra funcionamiento ni seguridad de la máquina. El estado actual es **NO-GO**: faltan protecciones DC coordinadas, una salida demostrada para el Solo, una decisión de diseño única, el esquema del módulo C14 y un ensayo real de PE y tensión bajo carga.

Este informe no sustituye una inspección de construcción ni una certificación eléctrica. Sirve como lista concreta de correcciones y ensayos para convertir el diseño documental en un prototipo que se pueda medir y revisar.
