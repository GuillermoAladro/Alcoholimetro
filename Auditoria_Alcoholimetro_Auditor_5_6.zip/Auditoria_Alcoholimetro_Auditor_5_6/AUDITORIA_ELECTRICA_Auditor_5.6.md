---
title: "AUDITORIA ELECTRICA COMPLETA DEL ALCOHOLIMETRO"
author: "Auditor 5.6"
date: "21 de octubre de 2026"
lang: es-ES
toc: true
toc-depth: 3
papersize: a4
geometry: margin=18mm
fontsize: 10pt
colorlinks: true
linkcolor: blue
urlcolor: blue
---

# Ficha del informe

| Campo | Valor |
|---|---|
| Auditor | Auditor 5.6 |
| Fecha | 21-10-2026 |
| Repositorio auditado | `GuillermoAladro/Alcoholimetro` |
| Rama | `main` |
| Commit base observado | `84be97669a9efec43e79b3dadc4af5e87458c41a` |
| Documento central | `MONTAJE-GENERAL.md` |
| Tipo de auditoria | Documental, electrica estatica y de integracion |
| Ensayo fisico realizado | Ninguno; no se dispuso del hardware |
| Estado del informe | Final para revision de diseno; pendiente de validacion fisica |

> **VEREDICTO: NO APTO PARA ENERGIZAR, NO APTO PARA INSTALAR EN UN BAR Y NO APTO PARA FABRICACION.**
>
> La arquitectura puede llegar a funcionar despues de una revision de diseno, pero el circuito descrito actualmente no permite afirmar que sea seguro ni repetible. No debe conectarse a 230 V con la revision actual.

# 1. Resumen ejecutivo

La fuente Mean Well LRS-50-5 tiene potencia suficiente para las cargas previstas. El pico conservador usado en esta auditoria es aproximadamente **6.00 A y 30.9 W** a 5.15 V, frente a 10 A y 50 W nominales. La capacidad total de la fuente no es el problema principal.

Los bloqueos estan en la entrada de red, la tierra de proteccion, la proteccion selectiva del rail de 5 V, los conectores USB, el margen de tension, la coexistencia de dos revisiones incompatibles y la ausencia de resultados de ensayo.

Los problemas que impiden energizar son:

1. Existen dos disenos incompatibles y no hay una revision unica liberada.
2. El modulo C14 generico no tiene esquema interno ni certificacion verificables.
3. El diseno antiguo no protege cada rama de 5 V.
4. La tierra depende de un unico esparrago y de una ejecucion sin validar.
5. El ajuste propuesto de 5.20 V no deja margen suficiente para todas las cargas.
6. La rama del SumUp Solo no esta cualificada electricamente.
7. La segregacion entre red y SELV no esta demostrada.
8. No existe firmware ni esquema de ingenieria en el arbol auditado.
9. La relacion entre 0 V y PE puede quedar definida accidentalmente por el RP-SMA.
10. No se ha realizado ninguna medicion con los componentes reales.

**Conclusion ejecutiva:** la topologia general es viable, pero antes de construir un prototipo energizado se debe crear una revision A-R1, sustituir la entrada C14 y la distribucion USB, disenar la proteccion de las cuatro ramas, cerrar la tierra de proteccion y preparar un plan de ensayos con criterios de aceptacion.

# 2. Alcance, metodologia y limites

## 2.1 Material revisado

Se inventario el arbol del repositorio y se revisaron:

- `README.md`, `LISTA-DE-COMPRA.md` y `MONTAJE-GENERAL.md`.
- Los cuatro esquemas de `montaje-general/` en SVG/PNG.
- `componentes/README.md` y `componentes/pendientes.md`.
- El resumen de anuncios de Amazon.
- Las fichas de los 31 componentes.
- Las referencias y copias locales criticas de Mean Well, Winsen, Raspberry Pi, USB, cableado, fusibles y tierra.

Todos los paths binarios fueron inventariados. No se afirma una inspeccion visual pagina por pagina de cada una de las aproximadamente 144 copias binarias del repositorio. Para los documentos no criticos se uso la ficha tecnica que los referencia y resume. Los documentos que sostienen el veredicto se contrastaron con fuente primaria.

## 2.2 Pruebas realizadas

Se realizaron:

- Revision de consistencia de las conexiones W1 a W29.
- Montaje virtual de la topologia.
- Balance de potencia y corriente.
- Calculo conservador de caidas de tension.
- Analisis de cortocircuito por rama.
- Analisis de fallo unico: perdida de PE, inversion Schuko, conector flojo y union accidental 0 V-PE.
- Comprobacion logica de UART y GPIO.
- Auditoria de componentes, terminales y herramientas.
- Revision de las ediciones normativas citadas en el diseno.

## 2.3 Pruebas no realizadas

No se realizaron por ausencia de hardware:

- Continuidad de tierra con corriente de ensayo.
- Rigidez dielectrica, aislamiento o corriente de fuga.
- Ensayo termico en caja cerrada.
- Medicion de rizado, overshoot o transitorios.
- Identificacion real del modulo C14.
- Medicion de la corriente de carga del SumUp Solo.
- Ensayo controlado de cortocircuito.
- Prueba funcional extremo a extremo con firmware.

Esta auditoria no es un certificado CE, un informe de laboratorio ni una autorizacion para trabajar con 230 V.

# 3. Estado real del repositorio

## 3.1 Contenido existente

En la raiz observada aparecen:

- `README.md`
- `LISTA-DE-COMPRA.md`
- `MONTAJE-GENERAL.md`
- `componentes/`
- `montaje-general/`

El `README.md` anuncia ademas `carcasa/`, `hardware/`, `firmware/` y `docs/`, pero no aparecen en el arbol auditado. Por tanto faltan como minimo:

- Esquema electrico controlado y netlist.
- Planos de fabricacion vigentes.
- Codigo del controlador e interfaz.
- Tests automaticos del ZE29A y de la integracion SumUp.
- Gestion documentada de errores de pago, sensor, red y alimentacion.
- Historial formal de revisiones.
- Resultados de ensayo.

No puede hacerse una validacion funcional extremo a extremo; solo puede auditarse la intencion del cableado.

## 3.2 Conflicto de revisiones

`MONTAJE-GENERAL.md` sigue principalmente el diseno del 19-20 de octubre de 2026, pero reconoce un diseno A posterior, de 21 de octubre, que:

- Cambia dimensiones y ubicacion de piezas.
- Mueve la fuente y el C14.
- Anade cuatro fusibles de rama.
- Elimina el pulsador.
- Cambia el cable de camara.
- Cambia la arquitectura Wi-Fi.
- Cambia la tierra y el circuito neumatico.

Los esquemas no se han regenerado completamente para ese diseno. No hay revision liberada ni lista de cambios cerrada.

**Decision de auditoria:** usar el diseno A como punto de partida por ser posterior y mejorar la compartimentacion/proteccion, pero crear una revision nueva y congelada, denominada **A-R1**, antes de fabricar.

# 4. Montaje virtual del circuito documentado

## 4.1 Entrada de red

```text
Toma Schuko
   |
Cordón Schuko-C13
   |
Modulo C14 generico + fusible T2,5A + interruptor iluminado
   | L / N
Mean Well LRS-50-5
   |
5 V DC
```

La asignacion de bornes de la LRS-50-5 esta correctamente reflejada:

| Borne | Funcion |
|---|---|
| 1 | AC/L |
| 2 | AC/N |
| 3 | FG / PE de la fuente |
| 4 | DC -V |
| 5 | DC +V |

El problema esta antes de la fuente: el esquema interno del modulo C14 concreto es desconocido.

## 4.2 Tierra de proteccion

```text
PE del C14
   |
Esparrago M4 soldado al cuerpo
   +-- FG de la LRS-50-5
   +-- panel frontal
   +-- caja interior
   +-- cajon
```

La intencion de unir todas las partes metalicas a PE es correcta. La ejecucion no esta validada: material de chapa, procedimiento de soldadura, par, herramienta de crimpado, seccion, numero de ojales y resistencia final siguen abiertos.

## 4.3 Distribucion de 5 V

```text
LRS-50-5 +V/-V
   |
WAGO +5 V y WAGO GND
   +-- Raspberry Pi por micro-USB
   +-- SumUp Solo por borne USB-A y cable A-C
   +-- pantalla por borne USB-A y USB-C
   +-- ZE29A por conector de cuatro vias
```

La topologia puede funcionar en condiciones normales, pero no esta protegida frente a un corto localizado porque el diseno antiguo no limita cada rama.

## 4.4 Senales

| Senal | Conexion | Evaluacion |
|---|---|---|
| TX de Pi | Pin fisico 8 / GPIO14 -> RX ZE29A, pin 4 | Correcta, pendiente de comprobar la placa real |
| RX de Pi | Pin fisico 10 / GPIO15 <- TX ZE29A, pin 3 | Correcta, 3.3 V TTL |
| Masa UART | Comun por la alimentacion | Necesaria y presente en concepto |
| Pulsador | Pin 11 / GPIO17 a pin 9 / GND | Correcta si se conserva el diseno antiguo |
| HDMI | Pi -> pantalla | Correcta en concepto |
| CSI | Pi -> camara | Correcta si el FFC tiene orientacion compatible |
| Wi-Fi | AR9271 en USB de la Pi | Correcta en concepto; producto/certificacion sin confirmar |

No se detecta un error logico en el cruce TX/RX. Si existe riesgo de conexion fisica equivocada por terminales Dupont individuales sin llave.

# 5. Simulacion electrica estatica

## 5.1 Hipotesis de carga

Las cifras no procedentes de fabricante se tratan como hipotesis de diseno, no como mediciones.

| Rama | Corriente tipica usada | Pico de diseno | Calidad del dato |
|---|---:|---:|---|
| Pi 3B+ + camara + AR9271 | 1.05 A | 2.50 A | El pico es la capacidad recomendada de alimentacion de la Pi |
| SumUp Solo | 0.80 A | 2.00 A | Estimacion del repositorio; no confirmada por SumUp |
| Pantalla | 0.50 A | 1.00 A | Estimacion; no hay datasheet exacto |
| ZE29A | 0.30 A | 0.50 A | Manual: menos de 500 mA |
| **Total** | **2.65 A** | **6.00 A** | Conservador |

## 5.2 Potencia de la fuente

A 5.15 V:

$$P_{pico} = 5.15\ V \times 6.00\ A = 30.9\ W$$

$$Margen = 50\ W - 30.9\ W = 19.1\ W$$

La utilizacion nominal calculada es 61.8 %.

**Resultado:** la LRS-50-5 pasa por capacidad nominal. Debe verificarse el derating termico dentro de la caja cerrada.

## 5.3 Margen de tension

Aplicando aproximadamente +/-2.4 % de margen conservador por regulacion y temperatura:

| Ajuste | Extremo bajo | Extremo alto | Evaluacion |
|---:|---:|---:|---|
| 5.10 V | 4.978 V | 5.222 V | Alto seguro para ZE29A/USB; margen de Pi reducido |
| 5.12 V | 4.997 V | 5.243 V | Compromiso posible con rama Pi de baja resistencia |
| 5.15 V | 5.026 V | 5.274 V | Puede superar 5.25 V |
| 5.20 V | 5.075 V | 5.325 V | Puede superar 5.3 V del ZE29A y margen USB |

**Resultado:** no se aprueba el ajuste de 5.20 V.

Tampoco basta con bajar la fuente. Si la rama de la Pi presenta resistencia alta, puede sufrir subtension. Debe medirse en el receptor y corregirse el camino de potencia.

## 5.4 Caidas de tension

Modelo:

$$V_{carga} = V_{fuente} - I \times R_{camino}$$

Los rangos incluyen cable, terminales, contactos y, en la Pi, el fusible de entrada. Son hipotesis conservadoras.

| Rama | Pico | R favorable | R desfavorable | V a 5.10 V favorable | V a 5.10 V desfavorable |
|---|---:|---:|---:|---:|---:|
| Pi | 2.5 A | 0.08 ohm | 0.20 ohm | 4.90 V | 4.60 V |
| Solo | 2.0 A | 0.10 ohm | 0.40 ohm | 4.90 V | 4.30 V |
| Pantalla | 1.0 A | 0.08 ohm | 0.30 ohm | 5.02 V | 4.80 V |
| ZE29A | 0.5 A | 0.03 ohm | 0.08 ohm | 5.085 V | 5.06 V |

Conclusiones:

- ZE29A: electricamente sencillo si el pinout es correcto.
- Pantalla: probablemente funcionara, pero el USB-C sensible al movimiento requiere retencion.
- Pi: necesita cable corto de cobre real y medicion bajo carga.
- Solo: mayor incertidumbre; un USB-A generico y cable fino pueden causar tension insuficiente y calentamiento.

## 5.5 Cortocircuito de rama

La fuente limita aproximadamente entre 10.6 y 14.4 A. Un receptaculo USB-A tipico de placa suele encontrarse en 1-1.5 A, aunque el modelo concreto no publica corriente.

En el peor caso, antes de limitar la fuente, un elemento de 1.5 A podria quedar expuesto a una corriente hasta **9.6 veces** mayor.

**Resultado:** fallo critico. La proteccion interna de la fuente no protege las ramas ni los conectores.

## 5.6 Resultado de pruebas virtuales

| Prueba | Resultado | Nota |
|---|---|---|
| Camino L/N hasta fuente | **NO EVALUABLE** | Depende del C14 real |
| Capacidad de la LRS-50-5 | **PASA** | Margen de unos 19 W |
| Ajuste a 5.20 V | **FALLA** | Puede superar limites |
| Rama Pi | **CONDICIONAL** | Baja resistencia y ensayo bajo carga |
| Rama Solo | **FALLA / NO DEMOSTRADA** | USB, cable y negociacion sin cualificar |
| Rama pantalla | **CONDICIONAL** | Consumo y conector exactos no documentados |
| Rama ZE29A | **PASA CONDICIONAL** | Conector y pinout fisicos pendientes |
| UART Pi-ZE29A | **PASA CONDICIONAL** | Logica correcta; arnes no apto para produccion |
| Proteccion de corto por rama | **FALLA** en diseno antiguo | Diseno A la propone, pero no esta integrado como revision final |
| Tierra | **NO PROBADA** | Bloqueo de seguridad |
| Termico | **NO PROBADO** | Bloqueo para uso publico |
| Funcional extremo a extremo | **IMPOSIBLE** | No hay firmware |

# 6. Hallazgos criticos y soluciones

## C-01 - No existe una revision unica

**Riesgo:** fabricar dos maquinas distintas bajo la misma documentacion, omitir fusibles o enrutar mal tierra, camara y red.

**Solucion:** crear y congelar A-R1; esquema, BOM, planos y cableado deben compartir revision, fecha, autor y estado. Regenerar las cuatro figuras.

**Criterio de cierre:** A-R1 aprobada y todas las conexiones W actualizadas.

## C-02 - C14 generico no aceptable

**Riesgo:** fase dentro con el interruptor en OFF, fusible en neutro, terminales vivos accesibles y componente sin trazabilidad.

**Solucion obligatoria:** sustituirlo por una entrada IEC de fabricante identificable con esquema publicado, corte bipolar, proteccion apta para alimentacion no polarizada, certificaciones, fijacion adecuada al grosor de chapa y cubierta trasera finger-safe.

No se acepta como solucion de produccion medir un modulo generico y usarlo si aparentemente funciona.

## C-03 - Falta proteccion selectiva de 5 V

**Riesgo:** calentamiento de cable, pistas o conectores antes de que actue la fuente.

**Solucion:** proteccion principal DC y proteccion por rama, seleccionada segun consumo real, seccion, conector e inrush. Preferencia por e-fuses con limitacion y diagnostico.

Puntos de partida para prototipo, sujetos a ensayo:

| Rama | Punto de partida | Condicion |
|---|---:|---|
| Pi | 2.5-3 A | Cable/conector aptos |
| Solo | 2-2.5 A | Tras medir y obtener confirmacion de SumUp |
| Pantalla | 1-1.5 A | Segun arranque real |
| ZE29A | 0.75-1 A | Manual: menos de 0.5 A |

Los 3 A / 3 A / 3 A / 2 A del diseno A no se aprueban sin coordinacion. Especialmente, 2 A para el ZE29A protege poco frente a un fallo de su cable.

## C-04 - Tierra no cerrada

**Riesgo:** perdida silenciosa de PE y chasis a 230 V tras un fallo.

**Solucion:** punto PE primario y marcado; barra o bloque de tierra o dos puntos validados; conductor independiente por parte; trenza flexible para elementos moviles; terminales y tornilleria trazables; herramienta correcta; pull test; metal limpio, proteccion anticorrosion y bloqueo mecanico.

**Criterio minimo:** resistencia desde PE de entrada a cada parte metalica menor o igual a 0.1 ohm con corriente de ensayo apropiada, antes y despues de ciclos mecanicos.

## C-05 - 5.20 V no aprobado

**Solucion:** ajuste inicial de banco en 5.10-5.12 V; medir en cada carga en vacio, tipico, pico, frio y caliente. No compensar un cable deficiente subiendo la fuente. Reducir resistencia o usar regulacion dedicada si la Pi cae.

Criterios:

- ZE29A siempre entre 4.7 y 5.3 V.
- USB no por encima de 5.25 V salvo especificacion expresa.
- Pi sin eventos de subtension y `vcgencmd get_throttled` en `0x0` bajo estres.
- Objetivo de prototipo en Pi: al menos 4.85 V sostenidos.

## C-06 - Rama del Solo sin cualificar

**Riesgo:** calentamiento, carga intermitente, degradacion de bateria, bloqueo y fallos de pago.

**Solucion:** autorizacion escrita de SumUp para quiosco/desatendido, montaje encerrado y alimentacion continua; usar cable/base/adaptador aprobados cuando sea posible; si se disena un puerto propio, modulo USB de alimentacion certificado con limitacion y proteccion termica; medir corriente, tension y temperatura durante pagos; no ocultar chip/PIN sin validacion comercial.

## C-07 - Red y SELV sin segregacion demostrada

**Solucion:** compartimento de red cerrado, cubiertas finger-safe, canalizacion separada, aislamiento para la tension mayor o barrera fisica, pasacables elegidos por el grosor real y alivio de traccion.

## C-08 - No hay implementacion funcional

**Solucion:** subir codigo, requisitos, maquina de estados, pruebas unitarias y simuladores de ZE29A/SumUp. Deben cubrir checksum, timeouts, reconexion, pagos duplicados, perdida de red y reinicios.

## C-09 - Clasificacion normativa abierta

La edicion internacional vigente localizada es **IEC 60335-2-82:2024**, no una supuesta edicion 2026. Cubre maquinas comerciales de servicio personal. IEC 60335-2-75:2024 cubre maquinas expendedoras de productos.

Este equipo parece encajar mejor como servicio personal, pero es una inferencia y debe confirmarla un laboratorio. El Reglamento (UE) 2023/1230 se aplica de forma general desde el **20 de enero de 2027**; la fecha de comercializacion determina el marco de maquinas, ademas de LVD, EMC, RED, RoHS y requisitos nacionales.

## C-10 - Union accidental 0 V-PE

**Solucion:** escoger y documentar SELV flotante o union controlada en un punto. Si se mantiene flotante, aislar el bulkhead RP-SMA y comprobar GND-PE. Si se une, hacerlo en un unico punto disenado, no por arandelas o tornillos incidentales.

## C-11 - Herramientas de crimpado insuficientes

La unica crimpadora comprada es para punteras. No es una solucion demostrada para ojales, faston ni terminales JST/Dupont.

**Solucion:** tres procesos separados:

1. Punteras con herramienta declarada para ferrules.
2. Ojales/faston preaislados con crimpadora de trinquete y matriz correcta.
3. Microterminales de barril abierto con herramienta especifica o arnes premontado.

Todos los terminales de seguridad deben superar inspeccion de corte y ensayo de traccion.

## C-12 - No existe estrategia de apagado seguro

La fuente se corta directamente y la Pi puede perder alimentacion durante una escritura o una transaccion.

**Solucion:** sistema de archivos de solo lectura, logs en RAM, persistencia transaccional, recuperacion tras reinicio y, si los requisitos lo justifican, modulo de hold-up o apagado supervisado.

# 7. Riesgos altos adicionales

## H-01 - Termico

Ensayo de 72 h con caja cerrada, maxima carga y ambiente representativo. Medir fuente, Pi, Solo, pantalla, sensor y mazos. Definir ventilacion y apagado por sobretemperatura.

## H-02 - Cableado y terminales genericos

Riesgo de CCA, seccion falsa, aislamiento de 50 V, faston incompatible y crimps deficientes. Sustituir piezas de seguridad por material trazable; medir resistencia/seccion y realizar pull tests.

## H-03 - Dupont de prototipo

Puede desplazarse hasta pines de 5 V o soltarse. Sustituir por arnes bloqueado, polarizado y con alivio de traccion.

## H-04 - FFC de camara

El cable de 50 cm puede tener orientacion incorrecta y no esta pensado para flexion repetida. El diseno A habla del cable oficial de 200 mm. Eliminar #4 si el oficial llega o especificar exactamente orientacion, paso, longitud, radio y fijacion.

## H-05 - Wi-Fi y radio

El AR9271 generico puede no llevar ese chip y puede carecer de declaracion de conformidad. Usar componente de fabricante conocido, DoC, antena aprobada, control de PIRE y watchdog de recuperacion.

## H-06 - Pago

Implementar idempotencia, reconciliacion, cancelacion, timeout y recuperacion de: cobro aprobado sin servicio, servicio sin cobro, perdida de red y reinicio. Nunca duplicar cobros al reanudar.

## H-07 - Sensor y neumatica

No se publican vida, deriva, calibracion ni humedad del ZE29A. Disenar boquilla desechable, prevencion de retorno, purga, gestion de condensado, prueba de cero, patron de control y calendario de calibracion. No presentarlo como etilometro evidencial sin homologacion.

## H-08 - Cortes de red

La microSD High Endurance no evita corrupcion. Usar raiz de solo lectura, logs en RAM, persistencia transaccional y pruebas de corte durante pago, escritura y sensor.

## H-09 - Contacto con liquidos

La maquina se instalara previsiblemente en un bar. Los elementos de usuario y las aberturas no tienen IP documentado. Un derrame puede alcanzar senales, 5 V o, en una mala segregacion, la zona de red.

**Solucion:** analisis de rutas de liquido, bandeja, drenaje, barreras, conectores sellados y exclusion fisica del compartimento de red.

## H-10 - Mantenimiento

El diseno no define como dejar la maquina realmente sin tension, como bloquear el acceso, ni que pruebas repetir despues de mantenimiento.

**Solucion:** procedimiento LOTO simplificado, desconexion fisica del C13, espera de descarga, verificacion de ausencia de tension y repeticion de PE/polaridad tras cada intervencion.

# 8. Arquitectura corregida A-R1

## 8.1 Red

```text
Schuko-C13 certificado
        |
Entrada IEC certificada, bipolar y documentada
        |
Compartimento cerrado de red
        |
Mean Well LRS-50-5 original con cubierta de bornes
```

Reglas:

- PE nunca se interrumpe ni se fusiona.
- L y N se tratan como activos por la reversibilidad Schuko.
- No usar el C14 generico actual.
- T2,5AH250V solo si curva, poder de corte e inrush real lo validan.
- Etiqueta: "Desconectar el cable antes de abrir".

## 8.2 Tierra

```text
PE de entrada
   | conductor primario dedicado
Barra/punto PE principal
   +-- FG fuente
   +-- carcasa
   +-- panel
   +-- cajon mediante trenza flexible
   +-- caja interior mediante trenza flexible
```

No comprimir cinco ojales en una unica pila. Marcar PE permanentemente y ensayar despues de cada intervencion.

## 8.3 Distribucion DC

```text
LRS-50-5 a 5.10-5.12 V iniciales
        |
Proteccion principal DC coordinada
        |
Estrella con e-fuse/fusible por rama
        +-- Pi
        +-- Solo
        +-- pantalla
        +-- ZE29A
```

- Troncal de cobre documentado, preferiblemente 1.5 mm2.
- PCB o bloque de distribucion con puntos de prueba e indicadores.
- Retorno individual a estrella.
- Proteccion contra inversion/transitorios segun rama.
- Etiquetado de ramales, calibre y fusible.

## 8.4 Pi

Cable corto de cobre real, 18-20 AWG de potencia preferible, con conector de calidad y sujecion. No alimentar por GPIO salvo revision especifica. Medir en la propia placa bajo estres.

## 8.5 Solo y pantalla

Eliminar breakouts USB-A genericos. Usar puertos de alimentacion con rating, proteccion y datasheet. El Solo debe usar una solucion aprobada o validada por escrito por SumUp. Retener mecanicamente el USB-C de la pantalla.

## 8.6 Senales

Arnes multipin con llave y bloqueo; separacion de 230 V; proteccion ESD para senales accesibles. Si se conserva pulsador, usar uno sellado, pull-up externo y debounce. El diseno A puede eliminarlo.

# 9. Plan de ensayos obligatorio

## 9.1 Puerta 0 - Documentacion

- A-R1 congelada.
- Esquema y BOM exactos.
- Planos/rutas de cable.
- Pares y herramientas.
- Software/versiones.
- Matriz de riesgos y requisitos.

**No avanzar si falla.**

## 9.2 Puerta 1 - Sin tension

1. Verificar referencias y certificados.
2. Inspeccionar crimps y pelado.
3. Medir continuidad de arneses.
4. Confirmar ausencia de corto L-N, L-PE y N-PE.
5. Medir PE a todas las partes; objetivo menor o igual a 0.1 ohm.
6. Confirmar exactamente cero o una union GND-PE, segun diseno.
7. Verificar proteccion de cada rama.
8. Comprobar polaridad USB, micro-USB y ZE29A.
9. Verificar orientacion FFC.
10. Inspeccionar segregacion, pasacables y strain relief.

## 9.3 Puerta 2 - Fuente sola

Solo personal cualificado:

1. Fuente encerrada y sin cargas.
2. Ajuste inicial 5.10-5.12 V.
3. Carga electronica de 0 a 6 A.
4. Medir regulacion, rizado y overshoot.
5. Ensayar corto controlado y recuperacion.
6. Confirmar temperatura y proteccion contra contacto.

## 9.4 Puerta 3 - Ramas

| Rama | Ensayo minimo |
|---|---|
| Pi | Arranques, estres CPU/USB/camara, tension en placa, `get_throttled=0x0` |
| Solo | Corriente, temperatura, pagos, bateria, desconexion/reconexion |
| Pantalla | Encendidos, imagen, movimiento de cable, temperatura |
| ZE29A | Calentamiento, UART, checksum, estados, soplido y recuperacion |

## 9.5 Puerta 4 - Sistema completo

- 100 ciclos de encendido/apagado.
- Arranque simultaneo.
- Pago durante camara/Wi-Fi/sensor.
- Perdida de red en cada estado.
- Corte durante pago y escritura.
- Sensor/pantalla/Wi-Fi desconectados.
- Verificacion termica de cables y conectores.

## 9.6 Puerta 5 - Endurance y ambiente

- 72 h continuas en caja cerrada.
- Ambiente maximo previsto.
- Ciclos de cajon y vibracion.
- Derrames/condensacion en el analisis de riesgos.
- Tirones de cables y conectores.
- Repeticion del ensayo PE.

## 9.7 Puerta 6 - Conformidad

Laboratorio competente para seguridad electrica, EMC, RED, RoHS, evaluacion de riesgos, marcado, manual y expediente tecnico.

# 10. Auditoria de los 31 componentes

| # | Componente | Estado | Accion |
|---:|---|---|---|
| 1 | Raspberry Pi 3B+ | Condicional | Validar alimentacion, temperatura y suministro |
| 2 | SanDisk High Endurance | Condicional | Canal fiable, raiz RO y pruebas de corte |
| 3 | Camera Module 3 | Condicional | Revisar montaje, autofocus y termica |
| 4 | FFC 50 cm | No aprobado por defecto | Diseno A usa 200 mm oficial; especificar orientacion si se mantiene |
| 5 | Pantalla 7 in | Condicional alto | Falta datasheet exacto; medir consumo, EDID, termica y retencion |
| 6 | ZE29A | Condicional | Conector, pinout, calibracion, deriva, higiene y termica |
| 7 | JST-XH | Condicional | Medir paso; no confiar en colores; arnes validado |
| 8 | Tubo silicona | Condicional | ID/OD, material, condensacion, limpieza y recambio |
| 9 | SumUp Solo | Condicional critico | Permiso escrito, alimentacion aprobada y uso desatendido |
| 10 | Cable USB A-C | No aprobado | Calibre, CC, datos y corriente sin cualificar |
| 11 | Pulsador arcade | Eliminar en diseno A | Si sigue, modelo sellado apto para baja senal |
| 12 | AR9271 | No aprobado para produccion | Chip, fabricante, CE/RED, firmware y recuperacion |
| 13 | RP-SMA | Condicional | Masa, sellado, par, perdida y antena aprobada |
| 14 | LRS-50-5 | Aprobable con condiciones | Original, cubierta, ventilacion, ajuste y ensayo |
| 15 | C14 generico | **Rechazado** | Entrada certificada bipolar y documentada |
| 16 | T2,5A generico | Condicional critico | T2,5AH250V de fabricante y curva conocidos |
| 17 | Schuko-C13 | Condicional | 3G1,0 preferible; certificacion y PE comprobado |
| 18 | USB-A a tornillo | **Rechazado para produccion** | Distribucion USB cualificada y protegida |
| 19 | Micro-USB pigtail | No aprobado sin medir | Resistencia, polaridad, cobre, temperatura y retencion |
| 20 | WAGO 221 | Condicional | Genuinas, fijadas y tras proteccion |
| 21 | 0.75 mm2 rojo/negro | Rechazado si CCA/50 V | Cobre con tension/temperatura documentadas o barrera |
| 22 | H05VV-F 3G1,5 | Condicional | HAR, cobre, seccion y terminal correcto |
| 23 | Ojales M4 genericos | Rechazados para PE de produccion | Trazables y pull test |
| 24 | Arandelas dentadas | Condicional | Material, metal limpio, par y recambio tras desmontar |
| 25 | Esparrago M4 | Condicional critico | Proceso de soldadura, muestras destructivas y redundancia |
| 26 | Tornilleria generica | Condicional | Seguridad con trazabilidad; controlar longitud/galling |
| 27 | Faston genericos | Rechazados para red | Referencias trazables, geometria y crimpado validado |
| 28 | Crimpadora punteras | Insuficiente | Anadir preaislados y microterminales |
| 29 | Dupont ELEGOO | Rechazado para produccion | Conector con llave y bloqueo |
| 30 | Separadores nailon | Condicional | Medir, evitar puente metalico y controlar par/humedad |
| 31 | Pasacables | Condicional | Elegir por grosor, temperatura y forma; anadir strain relief |

# 11. Cambios obligatorios en la BOM

1. Entrada IEC certificada, bipolar y documentada.
2. Cubiertas de entrada y bornes de fuente.
3. Barra PE y trenzas flexibles.
4. Proteccion principal DC y cuatro protecciones de rama.
5. Portafusibles/e-fuses exactos.
6. Distribucion USB de potencia certificada.
7. Cable de cobre con tension nominal documentada.
8. Ojales y faston trazables.
9. Crimpadora de preaislados.
10. Crimpadora de microterminales o arneses premontados.
11. Conectores de senal bloqueados.
12. Barreras, canaleta, cubiertas y alivios de traccion.
13. Instrumentacion/fixtures de produccion.
14. Etiquetas de PE, tension, fusibles y desconexion.

La lista actual no debe comprarse como un conjunto cerrado de produccion.

# 12. Matriz de liberacion

| Condicion | Estado | Prototipo energizado | Uso publico |
|---|---|---|---|
| A-R1 unica | No | Obligatoria | Obligatoria |
| C14 bipolar certificado | No | Obligatorio | Obligatorio |
| Proteccion por rama | No integrada | Obligatoria | Obligatoria |
| PE ensayada | No | Obligatoria | Obligatoria |
| Tension por rama | No | Obligatoria | Obligatoria |
| USB Solo cualificado | No | Obligatorio | Obligatorio |
| Compartimento de red | No demostrado | Obligatorio | Obligatorio |
| Firmware/tests | No | Obligatorios | Obligatorios |
| Ensayo termico | No | Muy recomendado | Obligatorio |
| Seguridad/EMC/RED | No | Banco controlado: posterior | Obligatorio |
| Autorizacion SumUp | No | Para pagos reales | Obligatoria |
| Calibracion/higiene | No | Para pruebas orientativas | Obligatoria |

# 13. Decision final

## 13.1 Respuesta a "funciona el circuito"

- **La fuente tiene capacidad:** si.
- **El pinout logico Pi-ZE29A es coherente:** si, condicionado a la placa real.
- **La distribucion podria alimentar las cargas en condiciones favorables:** probablemente.
- **Puede garantizarse que funcione con las piezas compradas:** no.
- **Puede garantizarse un cortocircuito seguro:** no.
- **Puede garantizarse la proteccion del chasis:** no, hasta ensayo fisico.
- **Puede conectarse a 230 V con la revision actual:** no.

```text
DISENO ACTUAL: RECHAZADO PARA ENERGIZACION

SIGUIENTE ESTADO POSIBLE:
"Apto para construir un prototipo sin tension"
cuando exista A-R1 y se sustituyan los componentes rechazados.

ESTADO POSTERIOR:
"Apto para energizacion de banco por personal cualificado"
solo tras superar las Puertas 0 y 1.

USO PUBLICO:
solo tras superar las Puertas 2 a 6.
```

La prioridad no es comprar las 31 lineas y probar suerte. Es cerrar A-R1, sustituir C14 y distribucion USB, disenar proteccion DC y PE, y construir despues un unico prototipo instrumentado.

# 14. Registro de acciones prioritarias

| Prioridad | Accion | Evidencia de cierre |
|---:|---|---|
| 1 | Congelar A-R1 | Esquema, BOM y planos firmados |
| 2 | Sustituir C14 | Datasheet, DoC y esquema de fabricante |
| 3 | Disenar fusibles/e-fuses | Calculo y ensayo de ramas |
| 4 | Redisenar PE | Plano y ensayo menor o igual a 0.1 ohm |
| 5 | Sustituir USB generico | Rating y ensayo termico/carga |
| 6 | Validar tension de Pi | Medidas y `get_throttled=0x0` |
| 7 | Separar red/SELV | Inspeccion y planos |
| 8 | Subir firmware/tests | CI, tests y simuladores |
| 9 | Validar SumUp | Confirmacion escrita y pruebas |
| 10 | Plan de conformidad | Matriz normativa y laboratorio |

# 15. Fuentes principales y documentos del repositorio

## 15.1 Repositorio

- `README.md`
- `LISTA-DE-COMPRA.md`
- `MONTAJE-GENERAL.md`
- `componentes/README.md`
- `componentes/pendientes.md`
- `montaje-general/anuncios-amazon-21-10-2026.md`
- `montaje-general/1-alimentacion-y-tierra.svg`
- `montaje-general/2-pi-puertos-y-senales.svg`
- `montaje-general/3-gpio-40-pines.svg`
- `montaje-general/4-donde-va-cada-pieza.svg`
- Las fichas y directorios de datasheets de los 31 componentes.

## 15.2 Fuentes externas criticas

- Mean Well LRS-50: <https://www.meanwell.com/Upload/PDF/LRS-50/LRS-50-SPEC.PDF>
- Winsen ZE29A: <https://www.winsen-sensor.com/d/files/manual/ze29a-c2h5oh.pdf>
- Raspberry Pi 3B+: <https://pip-assets.raspberrypi.com/categories/532-raspberry-pi-3-model-b/documents/RP-008338-DS-2-raspberry-pi-3-b-plus-product-brief.pdf>
- Raspberry Pi Camera Module 3: <https://pip-assets.raspberrypi.com/categories/786-raspberry-pi-camera-module-3/documents/RP-008151-DS-1-camera-module-3-product-brief.pdf>
- IEC 60335-2-82:2024: <https://webstore.iec.ch/en/publication/102014>
- IEC 60335-2-75:2024: <https://webstore.iec.ch/en/publication/80073>
- Reglamento (UE) 2023/1230: <https://eur-lex.europa.eu/eli/reg/2023/1230/oj>
- SumUp Terminal Payments: <https://developer.sumup.com/terminal-payments>

---

**Firmado:** Auditor 5.6  
**Fecha:** 21-10-2026  
**Estado:** auditoria documental y simulacion estatica; pendiente de ensayos fisicos.
