"""Modelo reproducible, exclusivamente de CC, del montaje Alcoholimetro.

No representa la respuesta transitoria de la fuente, la curva de los fusibles,
las resistencias reales de contacto ni un ensayo de seguridad a 230 V.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT / "Alcoholimetro"
COPPER_OHM_MM2_PER_M = 0.01724  # referencia de cálculo a 20 C


def loop_resistance(length_one_way_m: float, section_mm2: float) -> float:
    return 2 * length_one_way_m * COPPER_OHM_MM2_PER_M / section_mm2


def solve(source_v: float, loads_a: dict[str, float],
          contact_loop_ohm: dict[str, float] | None = None) -> dict:
    """Fuente ideal y cargas de corriente constante; longitudes son hipótesis."""
    contact_loop_ohm = contact_loop_ohm or {}
    total_a = sum(loads_a.values())
    trunk_r = loop_resistance(0.30, 0.75)
    bus_v = source_v - total_a * trunk_r
    wire = {
        "Pi": loop_resistance(0.15, 0.326),  # 22 AWG, 15 cm ida
        "Solo": loop_resistance(0.30, 0.75),
        "Pantalla": loop_resistance(0.30, 0.75),
        "ZE29A": loop_resistance(0.15, 0.326),
    }
    endpoints = {
        name: round(bus_v - current * (wire[name] + contact_loop_ohm.get(name, 0)), 3)
        for name, current in loads_a.items()
    }
    return {
        "source_v": source_v,
        "total_a": round(total_a, 3),
        "source_rating_a": 10.0,
        "trunk_r_ohm": round(trunk_r, 5),
        "trunk_current_above_repo_6a_assumption": total_a > 6.0,
        "bus_v": round(bus_v, 3),
        "wire_loop_ohm": {k: round(v, 5) for k, v in wire.items()},
        "contact_loop_ohm": contact_loop_ohm,
        "endpoint_v": endpoints,
        "sensor_4p7_to_5p3_model_only": 4.7 <= endpoints["ZE29A"] <= 5.3,
    }


def main() -> None:
    document = (REPO / "MONTAJE-GENERAL.md").read_text(encoding="utf-8")
    refs = sorted({int(n) for n in re.findall(r"\| W(\d+) \|", document)})
    assert refs == list(range(1, 30)), refs

    # Corrientes de diseño: 2,5 A de suministro recomendados para Pi 3B+;
    # <0,5 A especificados para ZE29A (se usa 0,5 A conservador);
    # 2 A Solo y 0,5 A pantalla son hipótesis del repositorio, no certificados.
    design_loads = {"Pi": 2.5, "Solo": 2.0, "Pantalla": 0.5, "ZE29A": 0.5}
    nominal = solve(5.10, design_loads)
    poor_contact = solve(5.10, design_loads, {"Pi": 0.10})
    hot_screen = solve(5.10, {**design_loads, "Pantalla": 1.0})
    high_setpoint = solve(5.20, design_loads)

    # Fallo resistivo en paralelo a las cargas típicas declaradas en la ficha.
    fault_resistance_ohm = 1.0
    normal_typical_a = 2.3
    fault_a = 5.2 / fault_resistance_ohm
    total_fault_a = normal_typical_a + fault_a
    fault = {
        "source_v": 5.2,
        "resistance_ohm": fault_resistance_ohm,
        "fault_current_a_idealized": round(fault_a, 2),
        "fault_heat_w_idealized": round(5.2**2 / fault_resistance_ohm, 2),
        "normal_typical_a_repo": normal_typical_a,
        "total_a_idealized": round(total_fault_a, 2),
        "above_repo_trunk_6a_assumption": total_fault_a > 6.0,
        "below_psu_ocp_min_10p6a": total_fault_a < 10.6,
        "qualification": "Ejemplo de fallo, no simulación dinámica ni ensayo de fusibles",
    }

    results = {
        "repository_commit": "84be97669a9efec43e79b3dadc4af5e87458c41a",
        "wires_present": refs,
        "method": "Modelo algebraico de CC con fuente ideal y cargas de corriente constante; hipótesis de longitudes, corriente y contacto explícitas",
        "cases": {
            "nominal_5p10v": nominal,
            "pi_extra_contact_0p10ohm": poor_contact,
            "screen_1a_assumption": hot_screen,
            "old_5p20v_setpoint": high_setpoint,
            "resistive_fault_1ohm": fault,
        },
        "assertions": {
            "all_W1_to_W29_documented": len(refs) == 29,
            "nominal_total_below_psu_10a": nominal["total_a"] < 10.0,
            "nominal_pi_voltage_above_4p75_example_gate": nominal["endpoint_v"]["Pi"] >= 4.75,
            "poor_contact_pi_below_4p75_example_gate": poor_contact["endpoint_v"]["Pi"] < 4.75,
            "fault_bypasses_psu_ocp_while_exceeding_repo_cable_assumption": fault["above_repo_trunk_6a_assumption"] and fault["below_psu_ocp_min_10p6a"],
            "four_A_fuses_sum_above_psu_rating": 3 + 3 + 3 + 2 > 10,
        },
        "unmodeled": ["red 230 V", "PE", "respuesta de C14", "derating térmico", "tiempo/corriente de fusibles", "corriente real de Solo/pantalla", "rizado/transitorios", "caída real de conectores", "función de sensor/cámara/pago"],
    }
    assert all(results["assertions"].values())
    target = ROOT / "resultados_modelo_circuito.json"
    target.write_text(json.dumps(results, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps(results, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
