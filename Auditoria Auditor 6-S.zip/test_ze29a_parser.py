"""Prueba reproducible del ejemplo UART ZE29A documentado en el repositorio.

No necesita hardware ni dependencias externas. Extrae las funciones originales del
bloque Python en componentes/winsen-ze29a/README.md y las prueba con un puerto
serie simulado. La implementación robusta propuesta se prueba con los mismos
casos. No altera el repositorio.
"""

from __future__ import annotations

import argparse
import ast
import hashlib
import json
import subprocess
import time
from pathlib import Path


DEFAULT_REPO = Path(__file__).resolve().parent / "Alcoholimetro"
DEFAULT_OUTPUT = Path(__file__).resolve().parent / "test_ze29a_results.json"


def load_original(readme: Path) -> tuple[dict, str]:
    markdown = readme.read_text(encoding="utf-8")
    heading = markdown.index("### Código de ejemplo")
    begin = markdown.index("```python\n", heading) + len("```python\n")
    end = markdown.index("\n```", begin)
    source = markdown[begin:end]
    syntax = ast.parse(source)
    selected = []
    for node in syntax.body:
        if isinstance(node, ast.Assign) and any(
            isinstance(target, ast.Tuple)
            and [item.id for item in target.elts if isinstance(item, ast.Name)]
            == ["START", "ADDR"]
            for target in node.targets
        ):
            selected.append(node)
        if isinstance(node, ast.FunctionDef) and node.name in {
            "checksum", "make", "read_frame"
        }:
            selected.append(node)
    namespace = {"time": time}
    exec(compile(ast.Module(body=selected, type_ignores=[]), str(readme), "exec"), namespace)
    assert {"checksum", "make", "read_frame"} <= namespace.keys()
    return namespace, hashlib.sha256(source.encode("utf-8")).hexdigest()


class MockSerial:
    """Puerto simulado; read(n) puede devolver menos de n bytes."""

    def __init__(self, data: bytes, max_chunk: int | None = None):
        self.pending = bytearray(data)
        self.max_chunk = max_chunk

    def read(self, count: int) -> bytes:
        if self.max_chunk is not None:
            count = min(count, self.max_chunk)
        result = bytes(self.pending[:count])
        del self.pending[:count]
        return result


def read_frame_robust(ser: MockSerial, checksum, timeout: float = 0.02,
                      expected_cmd: int | None = None) -> bytes | None:
    """Lee hasta el plazo; reexamina los posibles comienzos tras una trama mala."""

    deadline = time.monotonic() + timeout
    window = bytearray()
    while time.monotonic() < deadline:
        received = ser.read(1)
        if not received:
            continue
        window.extend(received)
        while len(window) >= 9:
            candidate = bytes(window[:9])
            if (candidate[0] == 0xFF
                    and checksum(candidate) == candidate[8]
                    and (expected_cmd is None or candidate[1] == expected_cmd)):
                return candidate
            del window[0]
            while window and window[0] != 0xFF:
                del window[0]
    return None


def git_commit(repo: Path) -> str | None:
    process = subprocess.run(
        ["git", "-c", "core.longpaths=true", "rev-parse", "HEAD"],
        cwd=repo, capture_output=True, text=True, check=False,
    )
    return process.stdout.strip() if process.returncode == 0 else None


def run(repo: Path) -> dict:
    readme = repo / "componentes" / "winsen-ze29a" / "README.md"
    original, source_sha = load_original(readme)
    checksum = original["checksum"]
    make = original["make"]
    read_frame = original["read_frame"]
    frame = bytes.fromhex("FF 85 31 00 00 00 00 00 4A")

    vectors = {
        "estado_0x85": (make(0x85), bytes.fromhex("FF 01 85 00 00 00 00 00 7A")),
        "precalentar_0x87": (make(0x87, 0x32), bytes.fromhex("FF 01 87 32 00 00 00 00 46")),
        "soplido_5s_0x89": (make(0x89, 5), bytes.fromhex("FF 01 89 05 00 00 00 00 71")),
    }
    vector_results = {name: actual == expected for name, (actual, expected) in vectors.items()}
    assert all(vector_results.values())

    normal = read_frame(MockSerial(bytes.fromhex("00 7E") + frame), 0.02)
    assert normal == frame
    corrupt = bytearray(frame)
    corrupt[-1] ^= 1
    rejected = read_frame(MockSerial(corrupt), 0.02)
    assert rejected is None

    # PySerial puede devolver menos de los 8 bytes pedidos si vence su timeout.
    partial_original = read_frame(MockSerial(frame, max_chunk=4), 0.02)
    partial_corrected = read_frame_robust(MockSerial(frame, max_chunk=4), checksum)
    assert partial_original is None and partial_corrected == frame

    # Un falso inicio precede a una trama válida. El código original consume
    # parte de la trama buena al validar la mala y después ya no la reconoce.
    prefixed = bytes.fromhex("FF 00") + frame
    prefix_original = read_frame(MockSerial(prefixed), 0.02)
    prefix_corrected = read_frame_robust(MockSerial(prefixed), checksum)
    assert prefix_original is None and prefix_corrected == frame

    other_command = bytes.fromhex("FF 88 04 00 00 00 00 00 74")
    selected = read_frame_robust(
        MockSerial(other_command + frame), checksum, expected_cmd=0x85
    )
    assert selected == frame
    incomplete = read_frame_robust(MockSerial(frame[:5]), checksum)
    assert incomplete is None

    return {
        "repo_commit": git_commit(repo),
        "source": str(readme),
        "source_python_block_sha256": source_sha,
        "execution": "simulated serial stream; no physical components or mains voltage",
        "reference_vectors": vector_results,
        "normal_with_leading_noise": normal == frame,
        "bad_checksum_rejected": rejected is None,
        "defect_partial_read_reproduced": partial_original is None,
        "fix_partial_read_passed": partial_corrected == frame,
        "defect_false_ff_prefix_reproduced": prefix_original is None,
        "fix_false_ff_prefix_passed": prefix_corrected == frame,
        "fix_expected_command_filter_passed": selected == frame,
        "fix_incomplete_frame_rejected": incomplete is None,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=DEFAULT_REPO)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()
    result = run(args.repo.resolve())
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=True, indent=2))


if __name__ == "__main__":
    main()
