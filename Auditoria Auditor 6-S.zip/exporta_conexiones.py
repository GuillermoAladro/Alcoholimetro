"""Extrae sin alterar las 29 filas W del documento de montaje versionado."""
import csv
from pathlib import Path

root = Path(__file__).resolve().parent
source = root / "Alcoholimetro" / "MONTAJE-GENERAL.md"
target = root / "conexiones_W1-W29_documentadas.csv"
rows = []
for line in source.read_text(encoding="utf-8").splitlines():
    if not line.startswith("| W"):
        continue
    cells = [cell.strip() for cell in line.strip().strip("|").split("|")]
    if cells[0][1:].isdigit():
        assert len(cells) == 5, cells[0]
        rows.append(cells)
assert [int(r[0][1:]) for r in rows] == list(range(1, 30))
with target.open("w", encoding="utf-8-sig", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["Ref", "De", "A", "Cable o medio", "Nota original"])
    writer.writerows(rows)
print(f"{len(rows)} conexiones: {target}")
