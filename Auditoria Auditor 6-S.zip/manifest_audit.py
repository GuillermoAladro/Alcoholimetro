"""Inventory and validate every versioned blob in Alcoholimetro HEAD."""

from __future__ import annotations

import csv
import hashlib
import io
import json
import subprocess
import zipfile
from collections import Counter
from pathlib import Path
from xml.etree import ElementTree

import pymupdf
from PIL import Image


ROOT = Path(__file__).parent / "Alcoholimetro"
OUT = Path(__file__).parent


def git_bytes(path: str) -> bytes:
    return subprocess.check_output(
        ["git", "-c", "core.longpaths=true", "show", f"HEAD:{path}"], cwd=ROOT
    )


def main() -> None:
    raw = subprocess.check_output(
        ["git", "ls-tree", "-rl", "-z", "HEAD"], cwd=ROOT
    )
    rows = []
    for line in raw.split(b"\0"):
        if not line:
            continue
        metadata, name = line.split(b"\t", 1)
        _, kind, blob_sha, size = metadata.decode("ascii").split()
        path = name.decode("utf-8")
        data = git_bytes(path)
        ext = Path(path).suffix.lower()
        row = {
            "path": path,
            "git_blob_sha1": blob_sha,
            "size_bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest(),
            "type": ext,
            "status": "OK",
            "details": "",
        }
        assert kind == "blob" and len(data) == int(size)
        try:
            if ext in {".md", ".sh", ".svg", ".dxf"}:
                s = data.decode("utf-8")
                row["details"] = f"UTF-8; {len(s.splitlines())} lines"
                if ext == ".svg":
                    root = ElementTree.fromstring(data)
                    row["details"] += f"; XML root {root.tag}"
                if ext == ".dxf":
                    if "SECTION" not in s or "EOF" not in s:
                        raise ValueError("DXF SECTION/EOF missing")
            elif ext == ".pdf":
                document = pymupdf.open(stream=data, filetype="pdf")
                text_lengths = [len(page.get_text()) for page in document]
                row["details"] = (
                    f"PDF; {len(document)} pages; {sum(text_lengths)} extracted chars; "
                    f"{sum(not n for n in text_lengths)} textless pages"
                )
                document.close()
            elif ext == ".png":
                with Image.open(io.BytesIO(data)) as image:
                    image.verify()
                with Image.open(io.BytesIO(data)) as image:
                    row["details"] = f"PNG; {image.width}x{image.height}; {image.mode}"
            elif ext in {".zip", ".xlsx"}:
                with zipfile.ZipFile(io.BytesIO(data)) as archive:
                    bad = archive.testzip()
                    if bad is not None:
                        raise ValueError(f"ZIP CRC failure: {bad}")
                    row["details"] = f"ZIP CRC OK; {len(archive.namelist())} entries"
                if ext == ".xlsx":
                    from openpyxl import load_workbook

                    wb = load_workbook(io.BytesIO(data), read_only=True, data_only=False)
                    row["details"] += "; sheets " + ", ".join(wb.sheetnames)
                    wb.close()
            else:
                row["status"] = "UNKNOWN_TYPE"
        except Exception as exc:
            row["status"] = "ERROR"
            row["details"] = f"{type(exc).__name__}: {exc}"
        rows.append(row)

    fields = ["path", "git_blob_sha1", "size_bytes", "sha256", "type", "status", "details"]
    with (OUT / "inventario_archivos.csv").open("w", encoding="utf-8-sig", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    summary = {
        "commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
        "files": len(rows),
        "bytes": sum(int(r["size_bytes"]) for r in rows),
        "types": dict(Counter(r["type"] for r in rows)),
        "status": dict(Counter(r["status"] for r in rows)),
        "errors": [r for r in rows if r["status"] != "OK"],
    }
    # Design inputs named by the repo as external to this Git tree.
    design_inputs = [
        "decisiones-diseno.md",
        "diseno-cajon-A.md",
        "cajon/specs.py",
        "Lista_de_piezas.xlsx",
        "carcasa_chapa.py",
        "caja_interior.py",
    ]
    all_markdown = "\n".join(
        git_bytes(r["path"]).decode("utf-8") for r in rows if r["type"] == ".md"
    )
    versioned = {r["path"] for r in rows}
    summary["cited_design_inputs_absent_from_git"] = [
        candidate
        for candidate in design_inputs
        if candidate in all_markdown and candidate not in versioned
    ]
    (OUT / "resumen_inventario.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
