# Auditoría eléctrica integral - Alcoholímetro

**Auditor 6-S | 21 de octubre de 2026 | Revisión del commit `84be97669a9efec43e79b3dadc4af5e87458c41a`**

## Dictamen ejecutivo

**Estado: NO APTO PARA DAR TENSIÓN DE RED NI PARA AFIRMAR QUE EL EQUIPO FUNCIONA.** El repositorio describe un circuito, pero reconoce que nada se ha montado ni medido. No se dispone de los componentes, del esquema vigente completo del «diseño A» ni de firmware del sistema. Se ha construido una representación virtual de las 29 conexiones W1-W29 y una propuesta de distribución corregida; las pruebas de continuidad lógica, cálculo de cargas y simulación de tramas son documentales. Ninguna constituye una prueba física de aislamiento, tierra, corriente, temperatura, carga USB, funcionamiento de la Pi o medición de alcohol. [R1-R3]

Tres bloqueos dominan la decisión: la ficha de la fuente permuta físicamente 230 V y 5 V en su tabla de bornes; el tramo de 5 V de la fuente a las WAGO no tiene protección adecuada frente a un fallo que puede quedar por debajo del umbral de la fuente; y el módulo C14 no tiene un esquema interno verificado. El documento de montaje usa el pinout correcto de la fuente, pero un operario que consulte la ficha individual podría cablear la red a una salida de 5 V. [R2-R4]

**Alcance de «todos los archivos».** Se han leído y validado automáticamente los 234 blobs del commit (198.526.533 bytes): 69 Markdown, 150 PDF, 4 ZIP, 4 PNG, 4 SVG, 1 DXF, 1 script y 1 XLSX. Los PDF contienen 1.541 páginas; los 54 PDF presentes dentro de los ZIP, otras 2.212. Se extrajo el texto disponible y se comprobaron los ZIP por CRC, las imágenes por decodificación, SVG como XML y XLSX como libro. La inspección humana detallada se centró en el cableado y en las hojas técnicas eléctricas pertinentes; no se afirma una lectura manual minuciosa de las 3.753 páginas. El CSV adjunto registra ruta, SHA-256, tipo, tamaño y resultado de cada archivo. [R1]

## 1. Base y montaje virtual

La guía versionada `MONTAJE-GENERAL.md` enumera W1-W29. W1-W10 cubren entrada de 230 V y PE; W11-W18, distribución de 5 V; W19-W28, UART, GPIO, HDMI, CSI, USB, RF y tubo; W29, red inalámbrica. El CSV adjunto transcribe las 29 filas originales sin resolver sus dudas. La asignación **confirmada visualmente en la página 4 del plano de Mean Well** es 1 AC/L, 2 AC/N, 3 FG, 4 DC -V, 5 DC +V. La guía la emplea bien. La conexión UART también coincide con Winsen: Pi pin físico 8/GPIO14 TX a ZE29A pin 4/RX; ZE29A pin 3/TX a Pi pin físico 10/GPIO15 RX; masas comunes y lógica de 3,3 V. El sensor recibe alimentación por pin 1 y retorno por pin 2. [R2-R6]

El esquema vectorial adjunto muestra una **arquitectura propuesta y condicionada**: entrada IEC de clase I con interruptor bipolar y protección de red documentados; PE distribuido a fuente y metal accesible; protección de CC cerca de +V antes del troncal; bus y cuatro ramas protegidas según la corriente y el elemento más débil; UART cruzada. No es un plano de fabricación: faltan referencias exactas, dimensiones, curvas y medidas para fijar calibres y terminales. La elección de diseño A se marca como provisional porque su documento íntegro no está versionado. [R2]

## 2. Hallazgos críticos

### C1. Pinout peligroso y contradictorio de la fuente

`componentes/meanwell-lrs-50-5/README.md` afirma en varias secciones que los bornes 1/2 son -V/+V y los 4/5 son AC/L y AC/N. El plano oficial de la misma fuente muestra exactamente lo contrario: 1 L, 2 N, 3 FG, 4 -V, 5 +V. `MONTAJE-GENERAL.md` sí coincide con Mean Well. Otras fichas propagan la geometría errónea al decir que +V está junto a FG: realmente FG queda entre N y -V. **Acción:** corregir ficha, notas derivadas y dibujos; marcar la versión errónea como no utilizable; identificar los bornes por serigrafía del ejemplar antes de cualquier cable. Un plano contradictorio bloquea la construcción. [R2-R4]

### C2. Fallo en el troncal de 5 V sin despeje garantizado

W11/W12 son 0,75 mm² y la propia documentación les atribuye 6 A. La LRS-50-5 suministra 10 A nominales y su protección de sobrecarga figura a 110-150 % de potencia, equivalente aproximadamente a 11-15 A a 5 V. Los cuatro portafusibles del diseño A se sitúan después de las WAGO; no protegen fuente-WAGO. En un **ejemplo idealizado** con 5,2 V, una fuga resistiva de 1 Ω absorbe 5,2 A y disipa 27 W. Sumada a 2,3 A de carga habitual citada en la ficha, resultan 7,5 A: sobre el supuesto de 6 A del cable y bajo el comienzo calculado de la protección de la fuente. La resistencia de fuente y cable reduciría algo el valor, pero no elimina la falta de coordinación demostrada. **Acción:** rediseñar el troncal con sección, aislamiento, temperatura y recorrido validados; proteger +V tan cerca de la salida como sea viable con dispositivo nominal y poder de corte CC apropiados, dimensionado respecto del cable; luego proteger cada rama. Comprobar curvas de tiempo-corriente y fallos de alta y baja impedancia. [R2-R4]

### C3. Entrada C14 indeterminada y Schuko reversible

El anuncio del módulo no permite identificar polos, lámpara ni fusible; el montaje plantea dos cableados incompatibles. Con un interruptor de un polo y enchufe Schuko reversible, el corte puede quedar en el neutro. Un fusible solo en un conductor presenta la misma incertidumbre de polaridad. **Acción:** fijar un módulo IEC C14 clase I con esquema y características documentadas, corte bipolar y solución de protección adecuada para ambos conductores; comprobar recorte, faston, temperatura y corriente de irrupción de la fuente antes de aceptar una referencia. El SCHURTER DD11 de dos polos es ejemplo de especificación, no sustitución mecánica aprobada ni compra verificada. PE nunca lleva fusible ni interruptor. El cableado de 230 V y su prueba inicial deben ser revisados por un profesional competente. [R2,R7]

### C4. Falta el diseño vigente completo

La guía es del montaje de 20-10 y declara otro «diseño A» firmado el 21-10. Ese diseño cambia medidas, tierra del cajón, cuatro portafusibles, elimina el pulsador, cambia el FFC, la ruta Wi-Fi y el conducto de soplido. `diseno-cajon-A.md`, `cajon/specs.py` y otros ficheros que cita no están en el commit. Las figuras siguen el esquema antiguo. **Acción:** versionar una única revisión maestra de esquema, lista de materiales y plano mecánico; reconciliar W1, W6-W18, W21-W24, W26, W28 y W29 antes de fabricar. [R1,R2]

## 3. Hallazgos altos y medios

### A1. Consigna de 5,20 V sin margen demostrado

El manual Winsen especifica 5,0 ±0,3 V en el ZE29A, es decir 4,7-5,3 V, y menos de 500 mA. A 5,20 V sin carga quedan solo 0,10 V hasta su límite superior. La fuente tiene regulación y rizado; el documento también advierte que el rizado puede aumentar a carga baja. La Pi 3B+ se recomienda con fuente de 5,1 V y 2,5 A. **Acción:** partir de aproximadamente 5,10 V, medir en la fuente y en los conectores con cargas mínimas, máximas, durante arranque y en caliente; ajustar sobre mediciones reales sin exceder ninguno de los límites. Esta consigna inicial no es una aprobación. [R2-R6]

### A2. USB Solo y pantalla sin intensidad ni protocolo confirmados

Los 2 A de Solo y 0,5 A de pantalla son estimaciones, no límites certificados de las piezas concretas. La corriente admisible del borne USB-A a tornillo no consta; un cortocircuito D+/D- puede anunciar un cargador BC1.2, pero no demuestra que el Solo lo acepte ni que borne, cable y contacto admitan la corriente. El cable de pantalla podría ser C-C, y el cable acodado del Solo aún no está identificado. **Acción:** obtener clasificación de cada conector, PCB y cable, medir corriente continua y de arranque con los equipos reales, y emplear puerto o módulo de alimentación USB adecuado. No elegir fusibles de 3 A frente a un conector no calificado para esa corriente. [R2,R8]

### A3. Los fusibles del diseño A no están dimensionados

El resumen de diseño A asigna 3 A Pi, 3 A Solo, 3 A pantalla y 2 A sensor. La suma de nominales (11 A) supera la salida nominal de 10 A y no garantiza selectividad ni protección del troncal. Un sensor de menos de 0,5 A no queda automáticamente protegido por un fusible de 2 A; además, portafusibles y fusibles requieren clasificación CC y curva conocida. **Acción:** escoger protección por rama a partir del menor límite entre cable, contacto, conector y carga, más corriente de arranque medida; documentar tolerancias y tiempo de despeje. [R2,R4,R5]

### A4. Tierra de protección y referencia de -V indefinidas

No hay espárrago, crimps, continuidad PE, ensayo dieléctrico ni medición de fuga. El pasamuros RP-SMA puede hacer contacto con la chapa a PE y unir por coaxial/USB la masa de la Pi y -V al chasis; HDMI puede abrir otra ruta. Por tanto, «-V flota» es solo un supuesto previo al montaje. **Acción:** diseñar un punto de PE fiable con puentes flexibles al cajón, medir cada metal accesible, comprobar PE con conexiones finales instaladas y decidir explícitamente la unión o aislamiento de la referencia de 5 V. No usar muelles o tornillos de fijación como único camino PE. [R2,R9]

### A5. Punteras en WAGO 221 y conectores sin comprobar

El documento pide punteras en WAGO 221; WAGO declara sus rangos para cobre desnudo y no una aprobación universal de punteras. También faltan paso exacto del conector ZE29A, color por posición, pinout real de latiguillo micro-USB, cara del FFC y fuerza de retención de USB-C. El SVG 1 colorea el sensor como si pin 1 fuese rojo y pin 2 negro, pese a que el texto dice que el color real es desconocido. **Acción:** usar conductor flexible compatible preparado según fabricante o validar la puntera concreta; inspeccionar continuidad y polaridad de cada arnés antes de energizar. Tratar colores del dibujo como intención, no dato del producto. [R2,R5,R10]

### M1. Límite térmico y conducto de soplido

El sensor solo tiene operación declarada entre 10 y 40 °C. La fuente reduce su potencia admisible a alta temperatura; en el plano A va en una «caja de red» y el sensor cambia de ubicación. No hay cálculo térmico ni ensayo en carcasa cerrada. W28 antiguo es un tubo directo; el manual Winsen exige gestionar correctamente presión, orificios y entrada de muestra. **Acción:** diseñar la barrera y ruta neumática de A con el manual, medir temperatura en el sensor durante el peor uso previsto y validar medición/contaminación; la comprobación eléctrica no acredita exactitud de alcohol. [R2,R5]

### M2. Ruta Wi-Fi contradictoria y firmware ausente

El documento antiguo pone Pi y Solo en el router del local y la figura indica `dtoverlay=disable-wifi`; el diseño A quiere que Solo se conecte a un AP de la Pi mientras AR9271 sale a Internet. Sin segundo radio activo o capacidad AP+estación verificada, enrutamiento y software, esa ruta no está demostrada. README anuncia `firmware/` y `hardware/`, pero no existen en el commit. La activación por cámara de A tampoco está implementada. **Acción:** definir radios, interfaces, AP/NAT, reconexión y secuencia de pago; crear firmware y pruebas integradas antes de declarar funcional el aparato. [R1,R2,R11]

## 4. Pruebas ejecutadas y resultados

**Inventario:** 234/234 blobs procesados sin error; PDF abiertos y extraídos página a página, 4 ZIP con CRC correcto, 54 PDF internos legibles. Es prueba de cobertura documental, no de veracidad de todos los datos. [R1]

**Modelo de CC:** se validó que W1-W29 existen en la guía. Se calculó con fuente ideal de 5,10 V, 0,30 m de troncal 0,75 mm² por conductor, rama Pi de 0,15 m 22 AWG por conductor, resistividad de cobre a 20 °C y cargas Pi 2,5 A, Solo 2,0 A, pantalla 0,5 A y ZE29A 0,5 A. Las tres últimas son hipótesis conservadoras o estimaciones del proyecto, salvo el máximo del sensor; las longitudes son ilustrativas. Total 5,5 A, por debajo de los 10 A nominales. Resultado algebraico sin resistencia de contacto: bus 5,024 V; Pi 4,984 V; Solo 4,997 V; pantalla 5,017 V; sensor 5,016 V. Con 0,10 Ω añadidos al lazo de contacto de la Pi, su extremo cae a 4,734 V. El modelo muestra sensibilidad; no demuestra que el circuito real tenga esos valores ni que la Pi arranque a 4,734 V. [R4-R6]

**Fallo resistivo:** la hipótesis 1 Ω a 5,2 V produce 5,2 A adicionales y ~27 W localizados, total idealizado 7,5 A con 2,3 A habituales. Es un caso de fallo que no queda cubierto por los fusibles de rama posteriores a WAGO. No se simuló la dinámica del limitador, el tiempo de fusible ni la respuesta térmica. [R2,R4]

**UART:** tres vectores de petición del manual Winsen, checksum y rechazo de trama dañada pasan en un flujo serie simulado. Se reprodujeron dos defectos del ejemplo Python del README del sensor: `serial.read(8)` puede devolver lectura parcial y perder una trama válida; un prefijo corrupto `FF 00` puede consumir parte de la trama siguiente. Una propuesta de recepción con búfer deslizante supera ambos casos en la simulación. Además, el ejemplo indexa `f` después de que `ask` pueda devolver `None`. El script adjunto ejecuta los casos y guarda el resultado; no existe firmware desplegable. [R5,R12]

**No ejecutado:** continuidad PE, aislamiento entre red/SELV, polaridad de piezas, corriente USB, osciloscopio/rizado, caída de tensión real, temperatura, prueba de fusibles, UART con sensor, cámara, pantalla, red, cobro y medición. Sin esos ensayos no hay aprobación de circuito. [R2]

## 5. Plan de corrección y criterios de cierre

1. **Congelar revisión:** obtener y versionar diseño A íntegro o declarar vigente la versión antigua; publicar esquema eléctrico único con revisión, BOM, pinout y cambios W. Corregir de inmediato pinout Mean Well y referencias derivadas. Bloqueo hasta cerrar.
2. **Red/PE:** seleccionar entrada IEC y protecciones con documentación de fabricante, dos polos de corte, características adecuadas de fusibles e irrupción; fijar construcción de PE, terminales, distancias y retención mecánica. Un profesional competente revisa diseño y montaje y ejecuta las pruebas de seguridad aplicables antes de la primera energización de red.
3. **Distribución CC:** dimensionar troncal para corriente máxima y entorno; instalar protección CC a la salida de +V que ampare ese tramo; dimensionar las cuatro ramas según el componente de menor corriente admisible y su arranque. Mantener negativos de retorno dimensionados y separados de PE salvo unión deliberada.
4. **Conectores:** conseguir datos/medidas de USB Solo/pantalla, ZE29A J1, micro-USB, FFC y WAGO; verificar continuidad, orientación, polaridad y tracción. Sustituir elementos sin clasificación suficiente.
5. **Banco de 5 V sin red:** emplear fuente de laboratorio limitada en corriente y cargas ficticias graduadas. Registrar para vacío, nominal, pico y falla controlada tensión en fuente y cada conector, corriente por rama, respuesta de protección y temperatura. Ajustar consigna para mantener ZE29A entre 4,7 y 5,3 V en todos los escenarios medidos y alimentación de Pi según su especificación. Ensayar primero fallos con limitación de energía.
6. **Validación final:** con piezas reales, verificar continuidad PE a todo metal accesible, aislamiento, fuga y protección; después medir en caja cerrada y máxima temperatura prevista. A continuación probar sensor, cámara, pantalla, Wi-Fi y transacción con firmware real. Guardar actas, instrumentos, calibración, resultados y revisión de esquema.

**Criterio de dictamen futuro:** solo «apto» si hay esquema único sin contradicciones, clasificaciones de todos los componentes críticos, ensayos de seguridad y alimentación con valores medidos, y prueba funcional completa reproducible. «Pasa el modelo de carga nominal» no equivale a ese criterio.

## 6. Fuentes y trazabilidad

[R1] Repositorio `GuillermoAladro/Alcoholimetro`, commit `84be97669a9efec43e79b3dadc4af5e87458c41a`: https://github.com/GuillermoAladro/Alcoholimetro/tree/84be97669a9efec43e79b3dadc4af5e87458c41a . Inventario y hashes adjuntos.

[R2] `MONTAJE-GENERAL.md`, especialmente líneas 5-11, 35-41, 49-100, 140-194 y 231-258: https://github.com/GuillermoAladro/Alcoholimetro/blob/84be97669a9efec43e79b3dadc4af5e87458c41a/MONTAJE-GENERAL.md .

[R3] `componentes/meanwell-lrs-50-5/README.md`, líneas 74, 113 y 191: https://github.com/GuillermoAladro/Alcoholimetro/blob/84be97669a9efec43e79b3dadc4af5e87458c41a/componentes/meanwell-lrs-50-5/README.md .

[R4] Mean Well, LRS-50-SPEC, 2025-04-07, tabla eléctrica pp. 1-2 y pinout p. 4: https://www.meanwellaustralia.com.au/sites/default/files/2025-05/MEAN%20WELL%20LRS-50%20DATA%20SHEET.pdf . Copia exacta en el repositorio: `componentes/meanwell-lrs-50-5/datasheets/MEAN_WELL_LRS-50_DATA_SHEET.pdf`.

[R5] Winsen, ZE29A-C2H5OH Manual V1.1, pp. 3-6 y 10, y ficha del fabricante: https://www.winsen-sensor.com/sensors/alcohol-sensor/ze29a-c2h5oh.html . Copia en `componentes/winsen-ze29a/datasheets/ze29a-c2h5oh.pdf`.

[R6] Raspberry Pi, documentación de alimentación Pi 3B+ y producto: https://www.raspberrypi.com/documentation/computers/raspberry-pi.html .

[R7] SCHURTER DD11, esquema y variantes de referencia técnica: https://www.schurter.com/en/pdf/english/typ_dd11.pdf .

[R8] Fichas locales de `componentes/sumup-solo/`, `componentes/borne-usb-a-hembra-tornillo/`, `componentes/pantalla-geeekpi-7-hdmi/` y `componentes/cable-usb-a-usb-c-90-30cm/` en [R1]; la corriente de los modelos comprados sigue sin confirmar.

[R9] Fichas locales de `componentes/alargo-antena-rp-sma-30cm/` y `componentes/separadores-nylon-m2-5/` en [R1].

[R10] WAGO, nota oficial sobre punteras en conectores: https://www.wago.com/global/industries/building-technology/electrical-installers/helpful-tips/ferrules .

[R11] Raspberry Pi, conexión de Camera Module 3 y FFC: https://www.raspberrypi.com/documentation/accessories/camera.html . Documentación Wi-Fi y figura 2 del repositorio en [R1].

[R12] `componentes/winsen-ze29a/README.md`, bloque Python líneas 232-276: https://github.com/GuillermoAladro/Alcoholimetro/blob/84be97669a9efec43e79b3dadc4af5e87458c41a/componentes/winsen-ze29a/README.md .

## Archivos adjuntos en el ZIP

- `Auditoria_Auditor_6-S.pdf`: informe de lectura e impresión.
- `Auditoria_Auditor_6-S.md`: fuente editable del informe.
- `esquema_propuesto_condicionado.svg`: arquitectura eléctrica revisada; requiere cierre de diseño.
- `conexiones_W1-W29_documentadas.csv` y `exporta_conexiones.py`: transcripción reproducible de la guía.
- `inventario_archivos.csv`, `resumen_inventario.json` y `manifest_audit.py`: cobertura reproducible de los 234 archivos.
- `modelo_circuito.py` y `resultados_modelo_circuito.json`: cálculo reproducible de CC.
- `test_ze29a_parser.py` y `test_ze29a_results.json`: reproducción de defectos del ejemplo serie.
- `LEEME.txt`: instrucciones de reproducción y límites.
- `SHA256SUMS.txt`: comprobación de integridad de los archivos incluidos.
