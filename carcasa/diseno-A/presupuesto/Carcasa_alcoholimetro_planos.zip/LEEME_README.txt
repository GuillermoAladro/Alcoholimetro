CARCASA DEL ALCOHOLIMETRO (diseño A) - PLANOS PARA PRESUPUESTO / DRAWINGS FOR QUOTATION
Guillermo Aladro Abad

ES
- Medidas generales: 220 x 100 x 443 mm.
- 44 piezas planas de acero DC01 cortadas por láser: 37 de 1,5 mm y 7 de 3 mm. Sin plegados.
- Unión por soldadura por puntos en varios conjuntos (carcasa, tapa, cajón de pajitas y cajón de componentes),
  con algunos espárragos M4 soldados (ver las notas de cada pieza en Lista_piezas_chapa.xlsx).
- Acabado: precio en bruto y, aparte, con pintura en polvo.
- Cantidades: 1 prototipo y precio por unidad para 10, 50 y 100.
- Entrega en Madrid.

EN
- Overall size: 220 x 100 x 443 mm.
- 44 flat laser-cut parts in DC01 cold-rolled steel: 37 x 1.5 mm and 7 x 3 mm. No bending.
- Joined by spot welding into several sub-assemblies (body, lid, two drawers), with some weld-on M4 studs
  (see the notes of each part in Lista_piezas_chapa.xlsx).
- Finish: price raw, and separately with powder coating.
- Quantities: 1 prototype, and unit price for 10, 50 and 100.
- Delivery to Madrid, Spain.

Contenido / Contents
- DXF_corte/        DXF de corte de cada pieza (capa CORTE) / cutting DXF per part
- STEP_piezas/      STEP de cada pieza / STEP per part
- Conjunto_A.step   la máquina montada; la electrónica va solo como referencia / full assembly, electronics for reference only
- vista-exterior.png
- Lista_piezas_chapa.xlsx
