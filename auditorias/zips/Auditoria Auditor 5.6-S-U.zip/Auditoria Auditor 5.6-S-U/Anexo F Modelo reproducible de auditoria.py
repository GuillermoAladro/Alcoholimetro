from __future__ import annotations

import csv
import hashlib
import json
from dataclasses import asdict, dataclass
from pathlib import Path


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "analysis" / "generated"
OUT.mkdir(parents=True, exist_ok=True)


@dataclass(frozen=True)
class Load:
    name: str
    current_typ_a: float
    current_peak_a: float
    v_min: float
    v_max: float
    r_nom_ohm: float
    r_worst_ohm: float
    basis: str


loads = [
    Load(
        "Raspberry Pi 3B+ y periféricos",
        1.20,
        2.50,
        4.75,
        5.25,
        0.056,
        0.200,
        "Ficha local: 5 V/2,5 A. R de bucle incluye latiguillo 22 AWG de 15 cm y contactos estimados.",
    ),
    Load(
        "SumUp Solo",
        0.50,
        2.00,
        4.75,
        5.25,
        0.114,
        0.279,
        "Corrientes y ventana USB son hipótesis de diseño; 0,279 Ω reproduce el peor caso local calculado para 30 cm, 28 AWG y contactos.",
    ),
    Load(
        "Pantalla HDMI 7 pulgadas",
        0.50,
        1.00,
        4.75,
        5.25,
        0.220,
        0.500,
        "Consumo y resistencia del cable son hipótesis; la ficha exacta no está disponible.",
    ),
    Load(
        "ZE29A",
        0.10,
        0.50,
        4.70,
        5.30,
        0.046,
        0.080,
        "Manual V1.1: 5 V ±0,3 V y corriente inferior a 500 mA.",
    ),
]


scenarios = [
    {
        "id": "S01",
        "name": "Documento original, típico",
        "source_v": 5.20,
        "current": "typ",
        "resistance": "nom",
        "purpose": "Comprueba el punto de ajuste propuesto con carga típica.",
    },
    {
        "id": "S02",
        "name": "Documento original, extremo alto sin carga",
        "source_v": 5.32,
        "current": "zero",
        "resistance": "nom",
        "purpose": "Reproduce la envolvente superior documentada; contrasta sobretensión.",
    },
    {
        "id": "S03",
        "name": "Corrección 5,12 V, pico y cable nominal",
        "source_v": 5.12,
        "current": "peak",
        "resistance": "nom",
        "purpose": "Evalúa el rediseño con picos simultáneos y rutas nominales.",
    },
    {
        "id": "S04",
        "name": "Corrección 5,12 V, fuente baja y pico",
        "source_v": 5.04,
        "current": "peak",
        "resistance": "nom",
        "purpose": "Margen inferior conservador del raíl corregido.",
    },
    {
        "id": "S05",
        "name": "Corrección 5,12 V, cableado degradado",
        "source_v": 5.12,
        "current": "peak",
        "resistance": "worst",
        "purpose": "Muestra sensibilidad a cables y contactos no caracterizados.",
    },
]


rows: list[dict[str, object]] = []
for scenario in scenarios:
    for load in loads:
        if scenario["current"] == "typ":
            current = load.current_typ_a
        elif scenario["current"] == "peak":
            current = load.current_peak_a
        else:
            current = 0.0
        resistance = load.r_worst_ohm if scenario["resistance"] == "worst" else load.r_nom_ohm
        drop = current * resistance
        endpoint = scenario["source_v"] - drop
        result = "PASA_CÁLCULO" if load.v_min <= endpoint <= load.v_max else "FALLA_CÁLCULO"
        rows.append(
            {
                "escenario": scenario["id"],
                "descripcion": scenario["name"],
                "carga": load.name,
                "tension_fuente_v": f"{scenario['source_v']:.3f}",
                "corriente_a": f"{current:.3f}",
                "resistencia_bucle_ohm": f"{resistance:.3f}",
                "caida_v": f"{drop:.3f}",
                "tension_en_carga_v": f"{endpoint:.3f}",
                "limite_min_v": f"{load.v_min:.3f}",
                "limite_max_v": f"{load.v_max:.3f}",
                "resultado": result,
                "nota": scenario["purpose"],
            }
        )

with (OUT / "escenarios_tension.csv").open("w", encoding="utf-8-sig", newline="") as handle:
    writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)


topology_tests = [
    ("T01", "Bornes LRS-50-5", "PASS_DOCUMENTAL", "1=L, 2=N, 3=FG, 4=-V y 5=+V coinciden con el datasheet."),
    ("T02", "Topología interna del C14", "FALLO_BLOQUEANTE", "Los cuatro terminales no identifican si el interruptor es SPST+lámpara o DPST."),
    ("T03", "Corte seguro con Schuko reversible", "FALLO_BLOQUEANTE", "No se demuestra corte bipolar ni protección simétrica."),
    ("T04", "Continuidad PE", "PENDIENTE_FÍSICO", "La intención es directa, pero espárrago, crimpados, soldadura y resistencia no están ensayados."),
    ("T05", "Distribución +5 V y GND", "PASS_DOCUMENTAL", "Las dos WAGO forman barras separadas y la tabla W11-W18 es legible."),
    ("T06", "Protección selectiva de las cuatro ramas", "FALLO_BLOQUEANTE", "No existe en el diseño antiguo y los valores del diseño A no protegen necesariamente los conectores."),
    ("T07", "Troncal LRS a distribución", "FALLO_BLOQUEANTE", "0,75 mm²/6 A queda antes de fusibles frente a una OCP posible de 14,4 A."),
    ("T08", "Cruce UART", "PASS_DOCUMENTAL", "Pi TXD físico 8 a ZE29A RX; ZE29A TX a Pi RXD físico 10."),
    ("T09", "Nivel UART", "PASS_DOCUMENTAL", "Ambos lados se documentan a 3,3 V TTL y 9600 8N1."),
    ("T10", "Pulsador GPIO17", "PASS_DOCUMENTAL_ANTIGUO", "Pines físicos 11 y 9 son coherentes; el diseño A elimina el pulsador."),
    ("T11", "Aislamiento DC- respecto a PE", "INDETERMINADO", "RP-SMA, HDMI o USB pueden crear una unión accidental."),
    ("T12", "Carga del SumUp Solo", "INDETERMINADO", "No se valida BC1.2, resistencia CC, intensidad del breakout ni perfil de carga."),
    ("T13", "FFC de cámara", "INDETERMINADO", "No se confirma la orientación de contactos ni la integridad a 50 cm."),
    ("T14", "Presupuesto de potencia", "PASS_CÁLCULO_CONDICIONAL", "Picos asumidos: 6,0 A y 30,7 W a 5,12 V, por debajo de 10 A/50 W."),
    ("T15", "Ajuste de 5,20 V", "FALLO_MARGEN", "La envolvente superior documentada puede superar los 5,3 V del ZE29A."),
    ("T16", "Revisión de diseño única", "FALLO_BLOQUEANTE", "Conviven un esquema antiguo y diseño A sin liberación ni BOM común."),
    ("T17", "Térmica de recinto", "PENDIENTE_FÍSICO", "No hay layout congelado ni ensayo cerrado en ambiente desfavorable."),
    ("T18", "Firmware y prueba extremo a extremo", "NO_EJECUTABLE", "El commit no contiene firmware, harness ni banco de pruebas."),
    ("T19", "Neumática de muestra", "INDETERMINADO", "Diámetro, accesorios, condensación y caudal de 10 L/min no están cerrados."),
    ("T20", "Funcionamiento del sistema completo", "NO_DEMOSTRADO", "Sin prototipo, instrumentos, firmware ni transacción/soplido reales."),
]
with (OUT / "pruebas_topologia.csv").open("w", encoding="utf-8-sig", newline="") as handle:
    writer = csv.writer(handle)
    writer.writerow(["id", "prueba", "resultado", "evidencia"])
    writer.writerows(topology_tests)


wiring = [
    ("R01", "Red 230 V", "C14 certificado de doble polo", "H05V-K o cable de equipo trazable; sección según norma", "Fusibles HBC dentro del conjunto documentado", "No reutilizar un módulo genérico sin esquema"),
    ("R02", "C14 salida L/N", "LRS-50-5 bornes 1/2", "1,5 mm², marrón/azul, terminales y herramienta compatibles", "Corte bipolar", "Compartimento de red y cubierta de bornes"),
    ("R03", "PE de entrada", "Punto PE primario dedicado", "Verde-amarillo; sección según norma de producto", "Nunca fusible ni interruptor", "Más largo que L/N; unión mecánica permanente"),
    ("R04", "Punto PE primario", "Barra PE", "Verde-amarillo trazable", "N/A", "Sin cinco ojales apilados"),
    ("R05", "Barra PE", "FG LRS y cada metal accesible", "Ramales independientes; flexible para piezas móviles", "N/A", "Ensayo 10-25 A y <=0,1 ohm"),
    ("R06", "LRS +V/-V", "Bloque de distribución fijo", "1,5 mm² mínimo o dimensionado >14,4 A", "Supervisor/eFuse central con OVP 5,45-5,5 V", "Ajustar inicialmente a 5,10-5,15 V"),
    ("R07", "Bloque +5 V", "Raspberry Pi", "Latiguillo 22 AWG real, corto, con alivio", "T2,5 A si supera inrush, o eFuse 2,6-3,0 A", "Cerrar tras medir arranque, caída y temperatura"),
    ("R08", "Bloque +5 V", "SumUp Solo", "Módulo/cable de carga certificado", "Máximo 1,5 A mientras exista USB-A/BC1.2 genérico", "Si requiere más, sustituir toda la ruta y validar con SumUp"),
    ("R09", "Bloque +5 V", "Pantalla", "Cable USB documentado y fijado", "1,0-1,25 A provisional", "Ajustar al inrush y rating medidos"),
    ("R10", "Bloque +5 V", "ZE29A pines 1/2", "Mazo polarizado por posición, no por color", "0,75-1,0 A provisional", "Verificar J1, polaridad, pulso y corriente"),
    ("R11", "Pi pin 8", "ZE29A pin 4 RX", "Par señal/GND con conector polarizado", "Protección ESD/serie tras ensayo", "UART 3,3 V, 9600 8N1"),
    ("R12", "ZE29A pin 3 TX", "Pi pin 10", "Par señal/GND con conector polarizado", "Protección ESD/serie tras ensayo", "No usar Dupont suelto en producción"),
    ("R13", "Pi HDMI", "Pantalla HDMI", "Cable sujeto y separado de red", "N/A", "Comprobar masa-chasis durante decisión DC-/PE"),
    ("R14", "Pi CSI", "Camera Module 3", "FFC oficial/correcto y longitud mínima viable", "N/A", "Contactos/orientación y retención verificados"),
    ("R15", "Pi USB", "AR9271", "USB fijado", "Limitación propia de rama Pi", "Aislar bulkhead RP-SMA si DC- debe flotar"),
]
with (OUT / "cableado_corregido.csv").open("w", encoding="utf-8-sig", newline="") as handle:
    writer = csv.writer(handle)
    writer.writerow(["id", "origen", "destino", "conductor", "proteccion", "criterio"])
    writer.writerows(wiring)


typical_current = sum(load.current_typ_a for load in loads)
peak_current = sum(load.current_peak_a for load in loads)
summary = {
    "audit_commit": "84be97669a9efec43e79b3dadc4af5e87458c41a",
    "verdict": "NO APTO PARA ENERGIZAR",
    "test_nature": "Revisión documental, cálculo de red resistiva y análisis de fallos; no ensayo físico.",
    "loads": [asdict(load) for load in loads],
    "total_typical_a": round(typical_current, 3),
    "total_peak_a": round(peak_current, 3),
    "total_peak_w_at_5_12_v": round(peak_current * 5.12, 3),
    "psu_rating_a": 10.0,
    "psu_rating_w": 50.0,
    "peak_capacity_margin_percent": round((1 - peak_current / 10.0) * 100, 1),
    "topology_counts": {
        key: sum(1 for _, _, result, _ in topology_tests if result.startswith(key))
        for key in ["PASS", "FALLO", "PENDIENTE", "INDETERMINADO", "NO_"]
    },
    "caveat": "Los resultados dependen de resistencias y corrientes asumidas; deben sustituirse por medidas de cada lote y prototipo.",
}
(OUT / "resumen_calculos.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")


manifest = []
for path in sorted(OUT.glob("*")):
    data = path.read_bytes()
    manifest.append({"archivo": path.name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
with (OUT / "manifesto_calculos.csv").open("w", encoding="utf-8-sig", newline="") as handle:
    writer = csv.DictWriter(handle, fieldnames=["archivo", "bytes", "sha256"])
    writer.writeheader()
    writer.writerows(manifest)

print(json.dumps(summary, ensure_ascii=True, indent=2))
