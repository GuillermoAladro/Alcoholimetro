# Auditoría de potencia y seguridad eléctrica

## Veredicto

**NO APTO PARA ENERGIZAR NI PARA CONSTRUIR TAL COMO ESTÁ DOCUMENTADO.** La topología básica (230 Vca -> LRS-50-5 -> distribución de 5 V) es viable, pero el esquema no es ejecutable de forma inequívoca y conserva varios fallos de seguridad. El propio documento lo declara "esquema de papel" y reconoce que no se ha montado ni medido (`MONTAJE-GENERAL.md`, líneas 3-9). No es posible afirmar que el circuito funciona físicamente sin disponer de los componentes, construir un prototipo y efectuar ensayos instrumentales.

El resultado documental y de cálculo es **aprobado con rediseño obligatorio**. Deben cerrarse antes de comprar o cablear, como mínimo, el módulo C14, la protección del troncal de 5 V, la distribución de tierra, la protección contra sobretensión de las cargas y el recinto de red.

## Alcance y evidencia revisada

- Commit auditado: `84be97669a9efec43e79b3dadc4af5e87458c41a`.
- Se revisaron `MONTAJE-GENERAL.md`, la lista de compra y las fichas de los componentes relacionados con red, fuente, distribución, conductores, terminaciones, tierra y pasos de cable.
- Se extrajo y examinó el texto de **75 PDF pertinentes, 445 páginas y 841.626 caracteres**: fuentes Mean Well, C14 de referencia, fusibles, H05VV-F, cordón C13, cable de 0,75 mm², WAGO, faston, ojales, arandelas, espárragos, crimpado, ITC-BT-19, ITC-BT-36, EN 50106/IET y la vista previa de IEC 60335-2-82. Cuatro PDF que `pypdf` no pudo abrir por cifrado o longitud de ruta se recuperaron con PyMuPDF; no quedó ningún PDF de esta selección sin extracción.
- Los PDF de producto son en muchos casos **referencias comparables**, no fichas del artículo de Amazon elegido. No prueban que la pieza comprada tenga la misma construcción o certificación.
- No se dispuso de hardware, polímetro, comprobador de tierra, megóhmetro, carga electrónica, osciloscopio ni cámara térmica. Por tanto, los ensayos físicos figuran como **pendientes**, no como aprobados.

## Modelo eléctrico reconstruido

Cadena prevista:

1. Schuko-C13 -> entrada C14 con fusible e interruptor.
2. Dos conductores activos -> bornes 1 AC/L y 2 AC/N de la Mean Well LRS-50-5; PE -> chasis -> borne 3 FG.
3. Bornes 5 +V y 4 -V -> dos WAGO 221-415.
4. Cuatro ramas de 5 V: Raspberry Pi, SumUp Solo, pantalla y ZE29A.

Los bornes de la LRS están bien identificados en el datasheet local: 1 AC/L, 2 AC/N, 3 FG, 4 -V y 5 +V (`MONTAJE-GENERAL.md`, líneas 164-168). La fuente entrega 5 V / 10 A / 50 W, consume 0,56 A típicos a 230 V a plena carga, tiene un arranque en frío de 45 A, OCP al 110-150 % con modo hiccup y OVP a 5,9-7,3 V (`MEAN_WELL_LRS-50_DATA_SHEET.pdf`, página 2; extracción, líneas 67-150).

## Hallazgos críticos

### C1 El módulo C14 no tiene un esquema ni certificación verificables

**Evidencia.** El anuncio declara un interruptor luminoso de cuatro terminales, pero eso puede ser un SPST más lámpara o un DPST. Los dos dibujos del vendedor se contradicen y dos reseñas afirman que son erróneos. Tampoco están confirmados el polo con fusible, el tamaño del cartucho, el grosor de faston ni la fijación. El esquema W2-W5 depende de esos datos (`MONTAJE-GENERAL.md`, líneas 48-66 y 138-147; `componentes/modulo-c14-fusible-interruptor/README.md`, líneas 30-37).

**Riesgo.** Cablear como bipolar una unidad SPST+lámpara puede llevar el neutro por la lámpara, dejar terminales activos de forma inesperada o mantener la luz permanentemente encendida. Con Schuko reversible, un fusible de un solo polo puede acabar en el conductor que actúa como neutro; un fallo del otro conductor al chasis dependería solo de la protección del local. El pico de 45 A tampoco está calificado para el interruptor genérico.

**Solución.** No emplear el módulo B08Z6FCR5Z en una máquina sin vigilancia. Sustituirlo por una entrada de fabricante identificable, con ficha, certificado comprobable, portafusibles 5x20 inaccesible mientras el C13 esté conectado, conmutación bipolar y capacidad de inrush documentada. La solución más robusta para Schuko es cortar simultáneamente ambos conductores activos y protegerlos de forma simétrica mediante un dispositivo de dos polos o dos fusibles en un conjunto previsto para ello. Usar T2,5 A, 250 V, cerámico HBC, IEC 60127-2, 1.500 A de poder de corte, de fabricante trazable; no un cartucho genérico sin ficha. Si se mantiene cualquier módulo, primero debe dibujarse su esquema real por continuidad y ensayarse fuera de tensión.

**Estado:** bloqueo de construcción.

### C2 El troncal de 0,75 mm² no queda protegido ni siquiera en el diseño A

**Evidencia.** W11 y W12 usan 0,75 mm². La ficha del propio proyecto le asigna 6 A, mientras la LRS puede entregar 10,6-14,4 A antes de entrar en hiccup (`MONTAJE-GENERAL.md`, línea 72; `componentes/cable-2x0-75-rojo-negro-10m/README.md`, líneas 383-387). El diseño A añade fusibles **después** de las WAGO, pero el tramo LRS->WAGO permanece sin protección. La frase de la línea 240 de `MONTAJE-GENERAL.md` según la cual el aviso deja de valer es, por tanto, incorrecta.

**Riesgo.** Un corto en el troncal, en la entrada de la WAGO o antes de los fusibles de rama puede someter un cable de 6 A a hasta 14,4 A. No se conoce el ciclo de trabajo del hiccup ni la temperatura resultante. Las protecciones de rama no actúan sobre ese fallo.

**Solución.** Cambiar ambos troncales +V y -V a cobre flexible documentado de **1,5 mm² como mínimo**, con aislamiento adecuado y corriente admisible superior a 14,4 A en el recinto real; confirmar que cabe en la LRS y la WAGO. Alternativa: un bloque de distribución/eFuse certificado conectado con conductor dimensionado a 10 A. No usar un fusible central de 6 A sin validar el pico total, porque la carga estimada del sistema está cerca de 5-5,5 A.

**Estado:** bloqueo de construcción.

### C3 Las protecciones de rama del diseño A están sobredimensionadas y ni siquiera están en la BOM

**Evidencia.** El diseño A propone Pi 3 A, Solo 3 A, pantalla 3 A y sensor 2 A (`MONTAJE-GENERAL.md`, líneas 231-248). La suma de calibres es 11 A frente a una fuente de 10 A. El ZE29A consume menos de 500 mA; un fusible de 2 A protege mal su ramal. Para la pantalla no hay consumo oficial y la referencia de 0,5 A es de otro modelo; su fabricante recomienda fuente de 5 V/2 A. El Solo no publica corriente de carga. Los portafusibles añadidos no aparecen entre los 31 componentes ni tienen referencia, curva, poder de corte o caída de tensión.

**Riesgo.** Un fusible protege el conductor/conector, no la carga de forma abstracta. Un calibre de 3 A no protege un borne USB-A cuya corriente real se estima en 1-1,5 A, y un fusible de 2 A puede dejar calentar el cable/conector del sensor. La caída de un portafusibles desconocido puede además provocar subtensión en la Pi.

**Solución.** Congelar la BOM después de medir cada carga. Valores provisionales para prototipo, sujetos a ensayo de arranque y temperatura: Pi 3,0 A o eFuse de 2,6-3,0 A; Solo 2,0-2,5 A solo si SumUp/cable/conector lo soportan; pantalla 1,0-2,0 A según medida; ZE29A 0,75 A. Preferir eFuses con límite de corriente, corto, OVP y medida de corriente. Colocar la protección en el extremo de origen de cada positivo, antes del cable. La suma de corrientes continuas medida debe quedar por debajo de 8 A para conservar margen térmico de fuente.

**Estado:** bloqueo de liberación del diseño A.

### C4 La protección contra sobretensión de 5 V no protege las cargas USB

**Evidencia.** La OVP de la LRS actúa entre 5,9 y 7,3 V. El ZE29A admite 4,7-5,3 V y las cargas USB/Pi se diseñan aproximadamente para 5 V. El ajuste propuesto de 5,20 V puede alcanzar teóricamente unos 5,32 V al sumar regulación de línea, carga y temperatura (`componentes/meanwell-lrs-50-5/README.md`, líneas 35-40, 61-63 y 177-186).

**Riesgo.** La OVP de la LRS evita que la propia fuente siga subiendo indefinidamente, pero puede permitir una tensión destructiva para Pi, pantalla, Solo o ZE29A antes de desconectar. Los fusibles no protegen contra sobretensión.

**Solución.** Ajustar inicialmente a **5,10-5,15 V**, con todas las cargas conectadas y en caliente; medir también en el conector de cada carga. Añadir un supervisor/eFuse de 5 V con corte por sobretensión en torno a 5,45-5,5 V y respuesta documentada, central o por rama. Verificar que su caída no causa subtensión en la Pi. Sellar o bloquear el trimmer tras el ajuste, dejando registro del valor.

**Estado:** bloqueo de seguridad de las cargas.

### C5 Las partes de red quedan sin un recinto de seguridad definido

**Evidencia.** La posición/orientación de la LRS, WAGO, C14 y bornes no está cerrada (`MONTAJE-GENERAL.md`, líneas 198-220). La LRS es una fuente metálica perforada con bornes expuestos; el C14 genérico deja faston y puentes a 230 V. El manual Mean Well exige no obstruir ventilación, respetar orientación/derating y mantener 10-15 cm frente a una fuente de calor (`Enclosed_Power_Supply_Installation_Manual.pdf`, página 1). No hay plano de barreras, distancias, tapa de bornes ni ensayo de dedo de prueba.

**Riesgo.** Acceso a partes activas al abrir cajón/panel, desprendimiento de un faston hacia el circuito SELV, contacto de cables de 5 V con el borne L situado junto a FG/+V, y entrada de líquidos desde el entorno de bar. La máquina prevista funciona sin vigilancia.

**Solución.** Crear un compartimento de red metálico puesto a PE, cerrado con herramienta, con cubierta aislante sobre bornes y faston, fijaciones que no puedan perforar la fuente y separación física entre red y SELV. Los pasos deben tener pasacables/perfil de borde documentado y alivio de tracción. Ningún cable de 5 V debe compartir brida o recorrido con L/N. Validar accesibilidad con sonda y el ensayo de derrame/humedad de la norma de producto. La alternativa preferible es una fuente externa certificada de 5 V y entrada interna exclusivamente SELV, con conector DC dimensionado para 10 A.

**Estado:** bloqueo de seguridad eléctrica.

### C6 La red de tierra depende de un único espárrago y de cinco ojales apilados

**Evidencia.** El montaje antiguo apila el PE de entrada y cuatro enlaces sobre un M4x20 (`MONTAJE-GENERAL.md`, líneas 48-69; `componentes/terminales-ojal-m4/README.md`, líneas 251-261). La propia ficha lo identifica como punto único de fallo. El material del espárrago, el método de soldadura, el espesor de chapa, la capacidad de par, los ojales y las arandelas de Amazon no están documentados. La crimpadora comprada es para punteras y no está demostrada para ojales o faston.

**Riesgo.** Aflojar un ojal para mantenimiento puede degradar los demás; un crimpado o soldadura defectuoso deja la máquina funcionando pero sin protección. Pintura, corrosión galvánica, vibración y flexión del cajón aumentan la resistencia. Las arandelas dentadas no sustituyen la medida de continuidad.

**Solución.** Usar un punto de PE de entrada dedicado, soldado/certificado y no destinado a otra función; desde él alimentar una barra o bloque PE aprobado, con una conexión individual por pieza metálica. Metal desnudo limpio, materiales compatibles, tuerca de bloqueo, par documentado, marca testigo y protección anticorrosión posterior sin aislar el contacto. Usar herramienta de crimpado específica y terminales trazables. El PE debe ser más largo que L/N y quedar sujeto. Para cajón/caja móvil, usar trenza o conductor ultraflexible dimensionado para movimiento repetido, no confiar en muelles o bisagras.

**Estado:** bloqueo de puesta a tierra.

## Hallazgos altos y medios

### H1 El supuesto de que -V flota no está demostrado

El texto declara -V flotante, pero el jack RP-SMA de panel une la malla del coaxial al techo puesto a PE (`MONTAJE-GENERAL.md`, líneas 72-74 y 193-195). A través del adaptador USB, la carcasa USB y la masa de la Pi puede aparecer un enlace DC-/PE; HDMI puede crear otro. Debe medirse continuidad DC--chasis con el equipo completamente montado y con cada periférico conectado por separado. Decidir explícitamente entre SELV flotante y PELV unido en un solo punto. Evitar enlaces múltiples accidentales; si se desea aislamiento, usar bulkhead RF aislado y revisar USB/HDMI.

### H2 5,20 V tiene margen insuficiente

La recomendación correcta es 5,10-5,15 V y verificar la Pi bajo carga. Cálculo de cobre: un latiguillo de 22 AWG de 15 cm presenta aproximadamente 0,016 ohm de bucle y unos 40 mV a 2,5 A, antes de conectores. Un ramal de 0,75 mm² con 0,6 m de bucle presenta unos 0,016 ohm y 47 mV a 3 A. La mayor incertidumbre son conectores, cable CCA y contactos de tornillo, no el cobre ideal.

### H3 El cable de 5 V comprado puede ser CCA y no tiene tensión de aislamiento demostrada

Debe rechazarse si no identifica cobre, sección, temperatura y tensión. Medir el rollo de 10 m por método de cuatro hilos según su ficha. Cerca de red, usar cable con vaina/tensión documentada o barrera. El negro de 5 V debe etiquetarse para que no se confunda con fase.

### H4 WAGO correcta eléctricamente pero mal especificada en el montaje

La 221-415 admite conductor flexible de 0,14-4 mm², 32 A, 450 V, T85 y pelado de 11 mm (`WAGO_221-415_hoja-de-datos-zh.pdf`, páginas 2 y 7). La ficha muestra conductor **pelado**, no confirma punteras. No poner puntera salvo confirmación de WAGO para esa combinación. Fijar las dos WAGO en soporte 221-500/505, separadas, rotuladas y sin posibilidad de golpear el chasis.

### H5 Terminaciones y herramienta no compatibles de forma demostrada

El kit de faston no da material, tensión, temperatura, sección ni grosor de lengüeta. Para 1,5 mm², los terminales azules suelen ser los apropiados; 4,8/6,3 mm y 0,5/0,8 mm deben coincidir exactamente. La crimpadora autoajustable de punteras no se presume válida para faston u ojales. Usar crimpadora de trinquete para terminal preaislado y hacer cinco pruebas de tracción por combinación/lote. Como criterio de prevalidación de 1,5 mm², ninguna muestra por debajo de 133 N; confirmar el valor final con la norma/terminal elegidos.

### H6 La sección de PE está tratada con una norma de instalación que no decide el aparato

ITC-BT-19 §2.3 da, para instalaciones fijas, SPE=S cuando S<16 mm², con mínimos de 2,5 mm² si el PE separado tiene protección mecánica y 4 mm² si no la tiene (`ITC-BT-19.pdf`, página 6; extracción, líneas 178-208). La propia ITC no es la norma de producto de esta máquina. Debe resolverlo la edición vigente de EN 60335-1 y la parte 2 aplicable. Para prototipo conservador, usar PE interno verde/amarillo de 2,5 mm² donde los terminales lo permitan y conductores de enlace/movimiento específicamente documentados; no declarar conformidad solo por esa decisión.

### H7 La LRS no lista protección térmica

La fuente declara -30 a +70 °C con derating, pero no OTP. El montaje "tumbado" puede no ser la orientación de referencia. Se debe reservar ventilación, medir el interior cerrado y limitar carga según la curva. El consumo máximo de diseño citado (26 W, aproximadamente 5 A a 5,2 V) usa alrededor del 52 % de la fuente; es un margen razonable solo si la temperatura y la ventilación se confirman.

### H8 La selección del T2,5 A es plausible pero no valida el módulo

A plena carga la LRS declara 0,56 A a 230 V; el T2,5 A trabaja al 22 % nominal. El SPT 2,5 A de referencia declara 11,7 A²s y 1.500 A a 250 V; otra familia usada por el repo declara unos 22 A²s. El arranque de 45 A necesita su duración/I²t real para cerrar el cálculo. Debe hacerse una prueba de 100-1.000 encendidos en frío/caliente y verificar que interruptor y fuseholder no se degradan. La selección del fusible no compensa un módulo C14 sin ficha.

### H9 El diseño antiguo y el diseño A no pueden coexistir

El documento de montaje sigue el diseño de 20-10, mientras el diseño A posterior mueve red y electrónica al cajón, añade fusibles, elimina pulsador y cambia recorridos (`MONTAJE-GENERAL.md`, líneas 231-248). Hay que elegir una única revisión y rehacer esquema, BOM, lista de cables, plano de disposición y protocolo. No construir mezclando ambos.

## Arquitectura corregida recomendada

### Opción preferente

Fuente externa certificada de 5 V, 50-60 W, con salida SELV y conector DC bloqueable de al menos 10 A. Dentro de la máquina solo entran 5 V. Elimina C14, faston de red, LRS abierta y gran parte de la puesta a tierra de protección interna. Debe verificarse autenticidad, certificado, temperatura, corriente, OVP y conector. Si la fuente es Clase II, la unión del chasis a PE deja de ser protección contra red y debe replantearse como EMC/ESD.

### Opción conservando la LRS

1. Entrada C14 certificada, fijada con tornillos, doble polo, fusible HBC trazable y esquema publicado.
2. Compartimento de red con tapa y cubierta de bornes; PE dedicado y barra de tierra.
3. L/N/PE de cobre flexible documentado, terminaciones de marca, sujeción secundaria y separación de SELV.
4. LRS montada según dibujo, tornillos de penetración máxima respetada, FG unido a PE, ventilación libre.
5. Troncales de 1,5 mm² mínimo a bloque de distribución fijo.
6. Supervisor/eFuse de OVP 5,45-5,5 V y protección de corto.
7. Cuatro protecciones de rama dimensionadas por medida y por límite del conector.
8. 5,10-5,15 V final en caliente y validación de caída en cada carga.
9. Decisión documentada sobre DC-/PE, incluida la antena de panel y HDMI.

## Plan de ensayo obligatorio

### Puerta 0 Documentación

- Elegir revisión mecánica única y emitir esquema con referencias de bornes, colores, secciones, terminales, fusibles y pares.
- Congelar fabricantes/modelos; verificar certificados por número, no por logotipo.
- Incorporar a la BOM los portafusibles/eFuses, soportes WAGO, cubiertas y barra PE.
- Cerrar la norma de producto vigente con laboratorio o asesor; la vista previa de IEC 60335-2-82 incluye las máquinas de servicio personal pero excluye las expendedoras. La clasificación exacta del alcoholímetro de pago debe decidirse formalmente.

### Puerta 1 Sin tensión

- Inspección 100 % de aislamiento, radios, bordes, separación, fijación y accesibilidad.
- Cartografiar C14/interruptor/fusible por continuidad antes de conectar.
- Comprobar todas las polaridades y continuidad de +5/GND, USB y PE.
- Cinco crimpados de muestra por terminal/lote/herramienta; inspección de corte y tracción.
- Ensayo PE desde el contacto de tierra de entrada a **cada** metal accesible: al menos 10 A, fuente <=12 V, R <=0,1 ohm descontando puntas. Repetir con el cajón en todo su recorrido y después de ciclos mecánicos.
- Medida de aislamiento entre L+N unidos, PE y SELV con procedimiento de laboratorio, componentes sensibles aislados y límites de la norma aplicable. No improvisar un hipot.

### Puerta 2 Fuente y distribución con carga artificial

- Primer encendido por técnico cualificado, con protección diferencial de 30 mA, límite de corriente y parada de emergencia; tapas puestas.
- LRS sola: ajustar 5,10-5,15 V, comprobar ondulación y arranque.
- Carga electrónica escalonada 0/1/5/8/10 A y transitorios. Registrar bornes de fuente y extremos de ramas.
- Cortocircuitar de forma controlada cada salida de eFuse/fusible de baja tensión; comprobar desconexión selectiva sin calentar cables. No provocar fallos en 230 V fuera de laboratorio.
- Ensayar inversión/pérdida de contacto solo en banco SELV.

### Puerta 3 Equipo completo

- Conectar una carga real cada vez; medir corriente de reposo, arranque y pico.
- Verificar `vcgencmd get_throttled = 0x0`, tensión en pines de Pi y reinicios durante cámara/Wi-Fi.
- Continuidad DC--chasis con cada cable y periférico añadido para detectar uniones accidentales.
- Ocho horas cerrado a carga máxima y ambiente desfavorable; registrar C14, faston, fuseholder, LRS, WAGO, cables, USB y aire interno. Respetar derating y límites de cada pieza.
- Ciclar alimentación, cajón y cableado; repetir PE y aislamiento después.

### Puerta 4 Laboratorio

- Corriente de fuga/touch current, rigidez dieléctrica, continuidad PE de rutina, calentamiento, operación anormal, acceso a partes activas, derrames/humedad, resistencia al fuego y EMC según edición vigente.
- Ensayo con PE interrumpido y otros fallos únicos solo por laboratorio competente.

## Matriz de resultados

| Comprobación | Resultado actual | Motivo |
|---|---|---|
| Coherencia topológica 230 V -> 5 V | Parcial | Fuente y bornes correctos; C14 ambiguo |
| Capacidad de la LRS | Pasa por cálculo | Pico previsto 5-5,5 A frente a 10 A, pendiente medir |
| Protección del troncal | Falla | 0,75 mm²/6 A frente a OCP de hasta 14,4 A |
| Protección por rama | Falla | Calibres no justificados y piezas ausentes |
| Margen de tensión | Falla | 5,20 V puede superar límites; OVP demasiado alta |
| Tierra de protección | Falla pendiente de rediseño | Espárrago/ojales/crimpado/soldadura no verificados |
| Aislamiento y acceso | Falla documental | Sin compartimento ni distancias cerradas |
| Térmica | No ensayada | LRS sin OTP y orientación/ventilación abiertas |
| Funcionamiento físico | No ensayado | No hay prototipo ni instrumentos |

## Conclusión para la auditoría general

El circuito **puede convertirse en un diseño funcional**, pero el esquema actual no demuestra que funcione ni que sea seguro. No se debe comprar/cortar/cablear siguiendo W2-W18 hasta implantar C1-C6. La corrección mínima es: C14 certificado y bipolar, compartimento de red, barra PE, troncales de 1,5 mm², protección real por rama y OVP de 5 V, ajuste a 5,10-5,15 V y un plan de prueba instrumental. Hasta superar las cuatro puertas de ensayo, el estado debe registrarse como **diseño no liberado, no energizar**.
