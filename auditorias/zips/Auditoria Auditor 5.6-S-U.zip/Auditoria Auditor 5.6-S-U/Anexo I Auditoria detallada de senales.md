# Auditoría de señales, periféricos y compatibilidad HW/SW

**Repositorio auditado:** `GuillermoAladro/Alcoholimetro`  
**Commit fijado:** `84be97669a9efec43e79b3dadc4af5e87458c41a`  
**Fecha:** 21-10-2026  
**Alcance de esta subauditoría:** Raspberry Pi 3B+, Winsen ZE29A, pantalla GeeekPi, Camera Module 3 y FFC, AR9271, pulsador y SumUp Solo. Alimentación de baja tensión, niveles lógicos, GPIO/UART, USB, HDMI, CSI, consumo y compatibilidad de software.

## 1. Dictamen

El conexionado de señales de la versión de `MONTAJE-GENERAL.md` es **coherente en papel**: la UART está cruzada correctamente y trabaja a 3,3 V, el pulsador no inyecta 5 V, HDMI/CSI/USB se asignan a interfaces compatibles y el presupuesto agregado no rebasa la capacidad nominal de la fuente. Esto no basta para aprobar el sistema.

**Estado de auditoría: NO APTO PARA MONTAJE FINAL NI PARA AFIRMAR QUE FUNCIONA.** Puede pasar a prototipo de banco después de corregir los bloqueantes siguientes:

1. No hay un diseño vigente único. El documento principal sigue el diseño del 20-10, pero describe un diseño A posterior que cambia fusibles, pulsador, cámara y red (`MONTAJE-GENERAL.md:5-7, 231-248`). Los documentos fuente de ese diseño A no están en Git.
2. El propio documento declara que nada se ha montado ni medido (`MONTAJE-GENERAL.md:5`). No se dispone de los componentes, osciloscopio, carga electrónica ni acceso físico. Por tanto no se ha validado polaridad, consumo, temperatura, integridad CSI, RF, exactitud del sensor ni comportamiento de carga del Solo.
3. En los 234 ficheros del commit no existe el `firmware/` prometido por `README.md:25-27`; el único fichero de código es un script de descarga. No es posible arrancar ni ensayar la aplicación, la máquina de estados, la gestión de errores, KMS, Picamera2, red o Cloud API.
4. El diseño A contradice la configuración de radio: la documentación desactiva el Wi‑Fi interno (`dtoverlay=disable-wifi`; `componentes/adaptador-wifi-ar9271/README.md:3,46` y figura 2), mientras el diseño A exige que la Pi sea punto de acceso del Solo y reserve el AR9271 para la salida (`MONTAJE-GENERAL.md:243`). Así escrito, solo queda un radio y falta el que debe crear el AP.
5. La rama del Solo es experimental: no se conoce su corriente real, el borne USB-A no tiene corriente nominal, el puente BC 1.2 solo autoriza al dispositivo hasta 1,5 A y el manual citado por el repositorio solo autoriza cable/cargador aprobados. El supuesto pico de 2 A no está respaldado (`componentes/sumup-solo/README.md:75-76,132-145`; `componentes/borne-usb-a-hembra-tornillo/README.md:31-34`).
6. Los fusibles del diseño A (3 A para Solo y pantalla; 2 A para sensor) no protegen adecuadamente los eslabones débiles documentados: USB-A genérico de 1–1,5 A habitual, placas comparables de 0,1–0,5 A y ZE29A de menos de 0,5 A (`MONTAJE-GENERAL.md:240`; `componentes/borne-usb-a-hembra-tornillo/README.md:31-34,73-76,94-107`).
7. Ajustar todo el raíl a 5,20 V deja solo 0,10 V hasta el máximo de 5,30 V del ZE29A. No hay captura de sobreimpulso, tolerancia, rizado ni tensión en bornes. El ajuste debe partir de 5,10 V y solo subir si la medida en la Pi obliga, manteniendo el sensor siempre entre 4,70 y 5,30 V, incluidos transitorios.

La conclusión correcta no es “el circuito funciona”, sino: **el netlist básico es plausible, pero el conjunto sigue sin demostrar y tiene bloqueantes de arquitectura, protección y producto**.

## 2. Qué se verificó y qué significa

### 2.1 Evidencia revisada

Se revisaron completos `MONTAJE-GENERAL.md` y las fichas Markdown de todos los componentes de este alcance. También se extrajo o leyó la evidencia binaria relevante:

- Raspberry Pi: product brief RP-008338 (5 V/2,5 A, 0–50 °C, pág. 3), esquema reducido RP-008339, PCN RP-003337 (nuevo PMIC y firmware desde septiembre de 2021, págs. 4-5) y el DXF mecánico (211.198 líneas; geometría, no prueba eléctrica).
- ZE29A: manual `ze29a-c2h5oh.pdf`, en especial págs. 3-4: 5 V ±0,3 V, menos de 500 mA, UART TTL 3,3 V, 9600 8N1 y pinout 1 Vin, 2 GND, 3 TX, 4 RX.
- Pantalla: white paper oficial KMS RP-004341. No existe datasheet del producto GeeekPi comprado; los PDF de Displaytech y Touch Display 2 son referencias de productos distintos y no transfieren sus límites al módulo comprado.
- Cámara: brief RP-008151, esquema RP-008969, PCN 42 y 43, plano del cable oficial RP-008146, las 19 partidas de la BOM XLSX y los dos STEP del ZIP. La BOM confirma un conector J1 FFC de contacto inferior; el brief confirma cable incluido de 200 mm y 15 × 1 mm.
- FFC: plano oficial de 200 mm y fichas de conectores/cables de referencia. No hay una ficha del cable Amazon de 50 cm; su topología de contactos y resistencia siguen siendo datos de recepción.
- Wi‑Fi: datasheet AR9271 mediante extracción alternativa (USB 2.0, alimentaciones internas y tabla de consumo del chip, págs. 11-15 y 144) y hoja TPE-N150USB (módulo de referencia: 300–310 mA TX, 280 mA RX). No es una ficha del dongle genérico comprado.
- Pulsador: BCM2835 Peripherals y hojas de interruptores/ESD de referencia. Tampoco son la ficha del pulsador arcade comprado.
- SumUp: declaraciones CE, certificados y ficha comercial local. Ninguno publica límite de corriente de entrada, perfil de carga o temperatura durante carga.
- USB: se abrieron los ZIP locales de BC 1.2, USB 2.0 y USB Type-C R2.5. BC 1.2 fija `RDCP_DAT ≤ 200 Ω` y permite al dispositivo 1,5 A; Type-C R2.5 exige 56 kΩ ±5 % en el plug C del cable legado A→C (pág. 45).

Las fuentes actuales oficiales de Raspberry Pi confirman que en Pi 3 el primario por defecto es mini-UART y el PL011 está en Bluetooth; `dtoverlay=disable-bt` más `systemctl disable hciuart` hace primario al PL011, y todos los UART son exclusivamente de 3,3 V: [configuración UART oficial](https://www.raspberrypi.com/documentation/computers/configuration.html). La documentación oficial de cámara confirma que Pi 4 y anteriores usan el cable Standard-Standard de 15 pines y que los contactos miran fuera de la pestaña y hacia la placa en el extremo de cámara: [documentación de cámara](https://www.raspberrypi.com/documentation/accessories/camera.html).

### 2.2 Comprobaciones reproducibles ejecutadas

Se ejecutó `work/analysis/audit_signals_checks.py`. Es un control estático del netlist transcrito, no SPICE ni prueba física. Resultado:

```text
netlist_static_checks: PASS (pinout/crossing/domain only)
ze29a_unique_frames: 21
ze29a_valid_checksum_frames: 20
ze29a_invalid_checksum_frames:
  FF 01 87 32 00 00 00 00 48 -> calculado 46, recibido 48
```

La única trama inválida es precisamente la del foro que la ficha marca como errónea; la trama de arranque correcta acaba en `46`. Esto comprueba la aritmética documental, no la respuesta de un ZE29A real.

## 3. Netlist auditado

| Interfaz | Conexión documentada | Dictamen estático |
|---|---|---|
| Alimentación Pi | WAGO +5 V/GND → micro-USB Pi | Compatible en principio; polaridad del latiguillo y caída sin verificar |
| Alimentación ZE29A | +5 V → pin 1; GND → pin 2 | Pinout correcto; 5,20 V demasiado cerca de 5,30 V máximo |
| UART Pi→ZE | Pi físico 8, GPIO14/TXD → ZE pin 4/RX | Correcto, 3,3 V directo, sin conversor |
| UART ZE→Pi | ZE pin 3/TX → Pi físico 10, GPIO15/RXD | Correcto, 3,3 V directo, sin conversor |
| Pulsador | Pi físico 11/GPIO17 → contacto → físico 9/GND | Correcto si se identifica el par del microinterruptor; LED desconectado |
| Pantalla | HDMI Pi→pantalla; pantalla alimentada por rama propia USB-C | Correcto. Prohibir el USB Pi↔pantalla porque crearía una segunda alimentación |
| Cámara | CSI Pi↔FFC 15 pines↔Camera Module 3 | Compatible. El tipo/orientación/longitud del FFC comprado no está demostrado |
| AR9271 | USB 2.0 directo a la Pi | Compatible; consumo de referencia muy inferior a 1,2 A total disponible en USB |
| Solo | Solo recibe solo 5 V por USB-C; control por HTTPS/Cloud API | Conceptualmente correcto; ruta de potencia sin calificar y no hay software en Git |

No aparece ninguna unión deliberada de 5 V a un GPIO. Los pines UART se cruzan correctamente y los dos equipos comparten referencia a través de la WAGO GND. El mayor riesgo del GPIO no es el esquema, sino el arnés: conectores Dupont sueltos o un alojamiento desplazado pueden situar 5 V sobre una entrada de 3,3 V. La Pi no es tolerante a 5 V (`componentes/raspberry-pi-3b-plus/README.md:49-57`).

## 4. Hallazgos por subsistema

### 4.1 Raspberry Pi 3B+

**Compatible, con condiciones.** El brief oficial da 5 V/2,5 A por micro-USB, cuatro USB 2.0 y 0–50 °C. La documentación oficial da 1,2 A agregados para periféricos USB y unos 500 mA de consumo típico de placa desnuda. El AR9271 de referencia consume alrededor de 0,31 A, por lo que no agota el presupuesto USB.

Condiciones de aprobación:

- comprobar el latiguillo micro-USB por continuidad; rojo/negro no constituye prueba de polaridad;
- medir 5 V en pines físicos 4 y 6 bajo el pico simultáneo, no solo en la fuente;
- exigir `vcgencmd get_throttled = 0x0` después del ensayo, y conservar el log de eventos;
- identificar Rev 1.3/1.4 y usar firmware posterior a septiembre de 2021;
- mantener el aire interno por debajo de 40 °C, pues Solo y el módulo Wi‑Fi de referencia son más restrictivos que el límite de 50 °C de la Pi;
- sustituir los Dupont 1×1 por una interfaz polarizada: HAT/placa de bornes fijada con separadores, IDC de 40 pines con breakout o PCB de interfaz con conectores enclavados.

### 4.2 UART y ZE29A

**La interfaz eléctrica es válida.** Ambos extremos declaran UART a 3,3 V. El pinout y cruce de `W19/W20` son correctos (`MONTAJE-GENERAL.md:85-86`; `componentes/winsen-ze29a/README.md:169-172`). No debe instalarse un conversor de 5 V.

Faltan estas salvaguardas:

- antes de conectar la Pi, medir el TX del módulo respecto a su GND: reposo dentro de 0–3,3 V; si supera 3,6 V, parar y usar adaptación de nivel;
- confirmar posición, paso y llave del J1. El manual no dice JST-XH; el cable se asigna por posición, nunca por color;
- configurar `/dev/serial0` para PL011: desactivar consola serie, añadir `dtoverlay=disable-bt`, deshabilitar `hciuart`, dejar `enable_uart=1` de forma explícita y verificar que `/dev/serial0` resuelve a `ttyAMA0`;
- enrutar TX/RX junto a su retorno y lejos de 230 V, la fuente y el FFC; a 9600 baudios, 150 mm no presenta un problema teórico de longitud;
- tratar timeout, checksum erróneo o estado imposible como fallo, jamás como “0 alcohol”; exigir dos resultados coherentes antes de mostrar/cobrar.

El manual no garantiza el estado tras encendido. La secuencia segura es consulta `0x85`, transición `0x87→0x32` solo si procede, sondeo de estado y lectura `0x86`. Una trama de nueve bytes a 9600 8N1 dura aproximadamente 9,375 ms, así que sondear cada 0,5 s deja margen amplio.

**La medida no está validada.** El módulo devuelve un entero en mg/100 mL. El divisor 220 para obtener mg/L no está en el manual; el divisor 200 también es plausible según la equivalencia española (`componentes/winsen-ze29a/README.md:290-298`). Su exactitud declarada de ±0,050 mg/L por debajo de 0,400 mg/L equivale a ±20 % alrededor de 0,25 mg/L. No se puede presentar como medición legal ni aprobar su exactitud sin comparación con patrón trazable.

### 4.3 Pantalla GeeekPi

**HDMI es compatible; la alimentación no está calificada.** El producto parece EP-0170, pero no hay identificación concluyente ni datasheet del ASIN. El consumo de 0,5 A y el máximo 5,25 V proceden de pantallas distintas (`componentes/pantalla-geeekpi-7-hdmi/README.md:30,43-50`). 52Pi únicamente recomienda 5 V/2 A.

Debe aplicarse:

- rama de alimentación independiente; no conectar el cable USB entre pantalla y Pi (`README` de pantalla, líneas 51 y 173);
- confirmar que el cable incluido es A→C y que el conector no se interrumpe al moverlo;
- registrar EDID y modos; con KMS usar `video=HDMI-A-1:1024x600M@60D` en la única línea de `cmdline.txt`, no las opciones antiguas `hdmi_group`, `hdmi_mode`, `hdmi_cvt` o `hdmi_force_hotplug`;
- ensayar encendido automático, persistencia de brillo y recuperación de corte. Los mandos quedarán inaccesibles tras cerrar la caja;
- medir corriente de arranque y estabilizada antes de elegir fusible. El margen provisional de 1 A es una hipótesis de diseño, no una especificación.

HDMI añade un camino de masa/blindaje en paralelo al retorno de alimentación. Con el sistema apagado se debe mapear continuidad entre blindaje HDMI, GND de 5 V, masa de pantalla y chasis; con el sistema encendido, medir la diferencia antes de insertar el HDMI. Un retorno de potencia roto no puede descargar corriente por el blindaje HDMI.

### 4.4 Camera Module 3 y FFC

**Camera Module 3 es compatible con la Pi 3B+ por CSI de 15 pines y con el software actual `rpicam-*`/libcamera/Picamera2.** No se debe usar el stack legado. En Pi 3 la vista previa GPU debe quedar por debajo de 2048 píxeles por lado; la captura final puede usar más resolución (`componentes/raspberry-pi-camera-module-3/README.md:94-103`).

El diseño A, que usa el cable oficial de 200 mm, es eléctricamente preferible. El brief especifica ese cable y un conector de 15 × 1 mm. El cable de 50 cm es 2,5 veces más largo, no tiene ficha propia ni máximo oficial de CSI. Con las dimensiones del conductor oficial, el cálculo del repositorio da unos 0,575 Ω de bucle de alimentación y 0,144 V de caída a la corriente estimada de 250 mA (`componentes/cable-ffc-camara-50cm/README.md:239-256`). En 200 mm la caída resistiva sería aproximadamente el 40 %.

Reglas de montaje:

- usar primero el cable oficial de 200 mm como referencia funcional;
- para cualquier sustituto, 15 conductores, 16,0 mm de ancho, paso 1,0 mm y continuidad 1→1 hasta 15→15;
- contactos hacia HDMI en la Pi y hacia la placa en la cámara; comparar visual y eléctricamente con el cable oficial;
- no aceptar una ruta que exija media torsión; no energizar si se invierte el orden;
- radio de curva conservador ≥10 mm, alivio de tracción a 2–3 cm de cada ZIF y separación de red/fuente;
- si se mantiene 50 cm, 24 h de captura/vista previa en la ruta final, sin desapariciones `imx708`, errores ni calentamiento anómalo.

Los PCN 42/43 declaran que no hay cambio eléctrico, pero sí efectos de software para quien use OTP/EEPROM. Como las unidades posteriores a abril de 2026 no se distinguen físicamente, debe actualizarse kernel/firmware/libcamera y probar cada lote.

### 4.5 Adaptador Wi‑Fi AR9271 y topología de red

**La interfaz USB y el consumo son compatibles.** El chip usa USB 2.0 y solo 2,4 GHz. Un módulo de referencia declara 300–310 mA TX y 280 mA RX (`componentes/adaptador-wifi-ar9271/README.md:52-70`), por debajo del agregado USB de 1,2 A de la Pi 3B+.

No se sabe si la unidad genérica lleva AR9271. La recepción debe incluir:

```text
lsusb
lsusb -t
dmesg
iw list
```

Se acepta solo si el ID lo reclama `ath9k_htc`, carga `ath9k_htc/htc_9271-1.4.0.fw` y el modo requerido aparece en `iw list`. El paquete recomendado es `firmware-ath9k-htc`, no confiar únicamente en el fallback 1.3 de `firmware-atheros` (`componentes/adaptador-wifi-ar9271/README.md:29-33,109-120`).

**Corrección obligatoria de red:**

- Opción más simple: conservar el diseño antiguo. AR9271 como estación hacia el router; Solo usa su propio Wi‑Fi o SIM. No se necesita AP local.
- Diseño A con Ethernet disponible: AR9271 externo como AP para el Solo y Ethernet como uplink de la Pi.
- Diseño A sin Ethernet: dos radios independientes. Uno crea el AP y otro hace de estación; preferiblemente el uplink admite 5 GHz. El AR9271 no.
- Usar `wlan0` interno como AP y AR9271 como uplink solo es aceptable si se elimina `disable-wifi` y una prueba RF dentro de la chapa demuestra margen suficiente. No debe presumirse.

No se debe confiar en un único AR9271 virtualizado simultáneamente como AP y cliente, y menos si AP y uplink necesitan canales diferentes, sin una prueba específica de concurrencia del hardware/driver.

El jack RP-SMA de panel puede unir, a través de la malla y el dongle USB, GND de la Pi con el chasis/PE (`componentes/alargo-antena-rp-sma-30cm/README.md:257-261`). Eso contradice un `DC−` “flotante” y puede crear un segundo punto de unión. Hay que medirlo en la unidad real y elegir una de dos arquitecturas documentadas: bulkhead aislado y SELV flotante, o unión intencionada de 0 V a PE en un punto de potencia adecuado y eliminación/gestión de caminos paralelos. El coaxial no debe convertirse accidentalmente en conductor de equipotencialidad.

### 4.6 Pulsador

La conexión GPIO17→contacto→GND es válida y no colisiona con UART. Los dos terminales LED deben quedar aislados. Sin embargo, el pull-up interno de 50–65 kΩ solo hace circular 50,8–66 µA, muy por debajo de cargas mínimas de referencia de muchos microinterruptores (`componentes/pulsador-arcade-30mm/README.md:35-39,135-159`). Además, una fuga por líquido resulta muy significativa.

Si se conserva el pulsador, se recomienda en el extremo Pi:

- pull-up externo de 2,2 kΩ a 3,3 V;
- 220 Ω en serie con GPIO17;
- 100 nF del nodo GPIO a GND;
- antirrebote de 50 ms en software;
- botón sellado con IP documentada para producción.

Con esos valores, contacto cerrado ≈1,36 mA y GPIO bajo ≈0,30 V, por debajo del VIL máximo de 0,9 V. La constante de apertura es ≈0,22 ms; 50 ms de software domina el rebote. El diseño A elimina el pulsador, por lo que no debe comprarse ni cablearse antes de congelar el diseño.

### 4.7 SumUp Solo y su alimentación USB-C

La comunicación por Cloud API no requiere cable con la Pi y es compatible con Linux/HTTPS. La documentación oficial actual recomienda mantener el Solo enchufado para Cloud API: [SumUp Cloud API](https://developer.sumup.com/terminal-payments/cloud-api). Pero el manual citado por el repositorio prohíbe más de 12 h y usarlo durante carga (`componentes/sumup-solo/README.md:31,132-147`). SumUp también mantiene documentación contradictoria sobre operación tipo quiosco/desatendida. Debe obtenerse una respuesta escrita para el uso exacto, el montaje encerrado y la fuente propia.

Para que la ruta propuesta pueda considerarse USB A→C válida:

- `Rp = 56 kΩ ±5 %`, es decir 53,2–58,8 kΩ, entre CC y VBUS en el plug C;
- continuidad VBUS/GND y D+/D− de extremo a extremo; no sirve un cable “solo carga”;
- puente D+/D− en la fuente de ≤200 Ω; el hilo directo es válido eléctricamente;
- el puente no demuestra que el Solo use BC 1.2 y, aunque lo use, BC 1.2 permite 1,5 A, no el supuesto pico de 2 A;
- medir tensión/corriente/inrush/temperatura durante carga completa con analizador USB.

El peor caso calculado por la ficha para 30 cm, 28 AWG, 2 A y máximos de contacto es una caída de 0,558 V. Con raíl de 5,15 V llegarían unos 4,59 V al Solo. Con 24 AWG, unos 4,76 V. Como SumUp no publica su mínimo, un pico de 2 A no puede aprobarse por cálculo. Si la corriente real supera 1,5 A, se rechaza el borne USB-A genérico y se usa un camino de potencia con rating documentado, protección y autorización de SumUp; no se “arregla” poniendo un fusible de 3 A delante del mismo conector.

## 5. Presupuesto de corriente y tensión

### 5.1 Consumo

Escenario de diseño conservador, separando hechos de estimaciones:

| Rama | Corriente usada en cálculo | Calidad del dato |
|---|---:|---|
| Pi completa, incluidos cámara y AR9271 | 2,50 A | Capacidad de fuente recomendada para Pi, no consumo medido |
| ZE29A | 0,50 A | Máximo documentado `<500 mA` |
| Pantalla | 1,00 A | Margen de diseño; producto sin dato |
| Solo | 2,00 A | Estimación sin respaldo del proyecto |
| **Total** | **6,00 A** | Envolvente provisional |

A 5,15 V son 30,9 W: quedan 4 A de margen frente a 10 A y 19,1 W frente a 50 W. La fuente no es el cuello de botella; lo son bornes, cables, conectores y protecciones. Un “nominal” mezclando datos típicos y estimaciones da 2,46 A/12,67 W, pero no debe usarse para dimensionar ni aceptar el producto.

### 5.2 Ajuste de tensión

Propuesta de banco:

1. empezar a 5,10 V medidos en WAGO sin carga;
2. medir mínimo/máximo y rizado en ZE pin 1–2, Pi pines 4–6, USB-C de pantalla y USB-C de Solo con todas las cargas activas;
3. aceptar ZE únicamente entre 4,70 y 5,30 V, incluidos arranque, cambio de carga y corte/reconexión;
4. exigir ≥4,75 V en Pi bajo pico como margen conservador y `get_throttled=0x0`; si falla, reducir caída en cable/conector antes de subir el raíl;
5. no superar 5,15 V sin capturas que demuestren margen de sensor y pantalla.

El tramo micro-USB 22 AWG de 15 cm presenta solo unos 39 mV teóricos a 2,5 A; las pérdidas dominantes serán contactos y el fusible reseteable de la Pi, que deben medirse.

### 5.3 Protección provisional por rama

Los valores finales requieren corriente de arranque real y curva tiempo-corriente. Para prototipo, no para liberar producción:

| Rama | Protección inicial razonable | Condición |
|---|---|---|
| Pi | e-fuse o fusible lento 2,5 A | comprobar arranque/estrés; no usar 3 A por rutina |
| ZE29A | 0,75–1 A | confirmar pulso de electroválvula/bomba; carga documentada <0,5 A |
| Pantalla | 1–1,25 A | ajustar al inrush medido y al rating real del conector |
| Solo | máximo 1,5 A si se conserva USB-A/BC1.2 | si requiere más, sustituir toda la ruta por una calificada |

Cada protección debe situarse al inicio de la rama positiva. Una protección de 3 A no hace seguro un USB-A de rating desconocido.

## 6. Arquitectura corregida recomendada

1. Congelar diseño A solo después de reescribir `MONTAJE-GENERAL.md` y figuras como plano “as-built”. Mantener su cable de cámara de 200 mm y la protección por rama, pero cambiar valores según medida.
2. Raíl de 5,10 V inicial. Distribución en estrella con retorno dedicado por rama y puntos de prueba etiquetados.
3. Pi por micro-USB corto y verificado. No alimentar nada más desde GPIO ni USB salvo el dongle AR9271.
4. PCB/interfaz fija entre GPIO y arnés: UART cruzada, terminal GND inequívoco, 330 Ω–1 kΩ serie opcionales en UART, red 2,2 kΩ/220 Ω/100 nF para el pulsador si existe, y conectores polarizados. Las resistencias no convierten un GPIO en tolerante a 5 V.
5. ZE29A con conector que coincida físicamente, pinout marcado y cableado por posición. Separar su ruta de señales de red/fuente.
6. Cámara con el cable oficial de 200 mm siempre que alcance. Si no, usar 30 cm antes que 50 cm; 50 cm solo tras el soak CSI.
7. Pantalla con HDMI y potencia independiente; ningún USB de alimentación entre Pi y pantalla.
8. Solo: preferir su arquitectura de carga autorizada. Si SumUp acepta una fuente propia, usar un módulo de carga/USB con rating, limitación y térmica documentados; el breakout genérico es solo para banco hasta demostrarlo.
9. Red: diseño antiguo con ambos equipos independientes, o dos interfaces físicas para AP/uplink. Nunca `disable-wifi` y AP interno simultáneamente.
10. Definir por escrito la política GND–PE y verificar todos los caminos por RP-SMA, HDMI, USB shield, tornillos y chasis.

## 7. Plan de pruebas de aceptación

### Fase 0 — congelación documental

- elegir diseño antiguo o A;
- emitir esquema eléctrico, netlist, pinout de arneses, BOM con fabricante/MPN/rating y tabla de fusibles;
- añadir software versionado, imagen de Raspberry Pi OS, configuración de boot, servicios y pruebas automatizadas;
- cerrar todas las entradas `⚠` que pueden cambiar cableado.

**Aceptación:** una única revisión firmada; ningún cable depende de color o fotografía de tienda.

### Fase 1 — recepción e inspección sin tensión

- Pi: revisión de PCB; latiguillo micro-USB, polaridad y resistencia;
- ZE: identidad, paso/llave/pin 1 de J1 y continuidad del arnés;
- pantalla: modelo impreso, puertos, tipo de cable, firmeza de USB-C;
- cámara/FFC: 15 pines, paso 1 mm, orientación y 15 continuidades 1→1;
- AR9271: marca, CE/DoC, conector RP-SMA y ausencia de juego;
- pulsador: localizar el único par que cierra; aislar LED;
- A→C: 53,2–58,8 kΩ CC–VBUS, datos presentes, sin cortos, polaridad;
- breakout USB: VBUS/GND correctos, D+/D− puente ≤200 Ω, rating documental o clasificación provisional de banco;
- mapear continuidad de GND a chasis antes/después de antena, HDMI y fijaciones.

**Aceptación:** cero inversión, cero 5 V sobre GPIO, cero conductor FFC cruzado y decisión explícita de masa/chasis.

### Fase 2 — ramas individuales con fuente de laboratorio

Alimentar primero cada rama a 5,10 V, con límite de corriente y protección. Medir tensión en carga, corriente, inrush y temperatura a 15, 30 y 60 min. Repetir al máximo brillo, cámara activa, Wi‑Fi TX y Solo cargando.

**Aceptación provisional:** sin olor, decoloración, reinicio ni conector por encima de un incremento térmico de 20 °C; límites de tensión cumplidos. La temperatura interna debe permanecer por debajo de 40 °C porque ese es el límite común más restrictivo documentado.

### Fase 3 — Pi y UART

1. Hacer loopback de GPIO14/15 y transmitir al menos 100.000 tramas con patrón y checksum, sin error.
2. Verificar `/dev/serial0 -> ttyAMA0`, sin consola serie ni `hciuart`.
3. Con sensor desconectado, medir ambos hilos UART: nunca >3,3 V.
4. Conectar ZE con corriente limitada, consultar `0x85`, verificar longitud/cabecera/checksum y ejecutar transiciones documentadas.
5. Ejecutar 1.000 consultas de estado; registrar timeout, basura, checksum y estado. Todo error debe bloquear la prueba, no generar un valor cero.
6. Ensayar reinicio, pérdida de UART y sensor desconectado.

**Aceptación:** 0 errores en banco; recuperación controlada; ningún cobro/resultado ante fallo. La exactitud de alcohol requiere después patrón trazable y queda fuera de este banco digital.

### Fase 4 — cámara y pantalla

- cámara: cable oficial de 200 mm, `rpicam-hello --list-cameras`, foto a resolución completa, autofocus y 24 h de capturas; después repetir con cable alternativo si es imprescindible;
- pantalla: leer EDID, fijar 1024×600 KMS, 20 arranques en frío y 20 cortes/reconexiones, brillo máximo y cable inmovilizado;
- prueba de backfeed: alimentar solo un equipo cada vez y comprobar que no aparece una alimentación indebida en el otro.

**Aceptación:** cero pérdida de cámara/error CSI, cero pantalla negra/parpadeo, encendido autónomo determinista y sin backfeed.

### Fase 5 — Wi‑Fi y SumUp

- comprobar ID, driver, firmware, dominio `ES`, AP/estación según arquitectura y RSSI con caja cerrada;
- 72 h de tráfico continuo y llamadas HTTPS, capturando `dmesg` para `USB disconnect`, `Chip reset failed`, `Target is unresponsive` y `Failed to wakeup`;
- cortar WAN/AP y demostrar recuperación sin acceso manual al dongle;
- Solo: comparar cargador original y rama propuesta con analizador USB; carga completa con/sin puente D+/D−, pico, tensión, temperatura de conectores y batería, sueño de 2 h, despertar por checkout y reinicio físico;
- probar Cloud API primero con Virtual Solo/sandbox y después con el terminal real; la simulación no valida carga, NFC ni radio.

**Aceptación:** 72 h sin desconexión no recuperada, recuperación automática demostrada, corriente dentro del rating de toda la ruta y autorización escrita de SumUp para el caso real.

### Fase 6 — sistema completo y fallos

- ensayo simultáneo 72 h: cámara, pantalla máxima, UART, Wi‑Fi TX y Solo cargando;
- registro continuo de cuatro tensiones, corrientes de rama, aire interno, CPU y batería del Solo si la API lo expone;
- escalones y brownout, 50 arranques completos y extracción/reconexión de cada periférico con alimentación apagada;
- ensayo de apertura/corto de cada rama mediante jig/carga electrónica, no cortocircuitando componentes. Debe abrir solo su protección y conservar las otras ramas;
- preconformidad ESD/EFT/EMI por laboratorio, en especial pulsador, USB, FFC y radio.

**Aceptación:** sin subtensión Pi, rail ZE dentro de 4,70–5,30 V, ninguna rama supera rating/térmica, recuperación determinista y logs sin errores persistentes.

## 8. Lo que no se puede certificar sin componentes

Esta auditoría no puede confirmar:

- que los colores del latiguillo micro-USB o JST correspondan a polaridad/pinout;
- que J1 sea JST-XH, que el FFC sea de caras opuestas o que el dongle sea AR9271;
- corriente/inrush reales de pantalla y Solo, rating del breakout, caída de contactos y actuación de fusibles;
- sobreimpulso/rizado de 5 V, `get_throttled`, temperatura de caja y backfeed por HDMI/USB;
- señal CSI a 50 cm, autofocus, arranque de pantalla, RF a través de la chapa o estabilidad USB 72 h;
- carga continua del Solo, política de garantía, uso desatendido, NFC y Cloud API real;
- estados de arranque, temporización, precisión, calibración, deriva o vida útil del ZE29A;
- continuidad real entre DC−, blindajes, RP-SMA, fijaciones, chasis y PE;
- seguridad funcional, EMC, RED, metrología o conformidad de producto.

## 9. Conclusión final de esta subauditoría

El proyecto tiene una base documental inusualmente amplia, pero mezcla especificaciones del producto real con productos análogos y conserva demasiadas hipótesis como si fueran conexiones finales. La UART ZE29A y las interfaces Pi–pantalla–cámara–Wi‑Fi son técnicamente viables. Los principales obstáculos no son la potencia total ni el pinout, sino la ausencia de una revisión única, la alimentación no calificada del Solo, fusibles sobredimensionados respecto al eslabón débil, la contradicción de radios del diseño A, el arnés Dupont y la falta absoluta de evidencia física/software.

Tras aplicar la arquitectura corregida y superar las seis fases de prueba, el sistema podría pasar de “plausible en papel” a “prototipo funcional verificado”. Antes de eso, cualquier afirmación de que el circuito funciona sería técnicamente falsa.
