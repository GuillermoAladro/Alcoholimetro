"""Reproducible static checks for the documented low-voltage wiring.

This is not a hardware simulation.  It verifies the netlist transcribed from
MONTAJE-GENERAL.md and recalculates protocol/electrical arithmetic used by the
audit report.
"""

from __future__ import annotations

import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1] / "repo"


NETS = {
    "+5V": {"Pi.microUSB.VBUS", "Solo.USBC.VBUS", "Display.USBC.VBUS", "ZE29A.1.VIN"},
    "GND": {"Pi.microUSB.GND", "Solo.USBC.GND", "Display.USBC.GND", "ZE29A.2.GND", "Button.B"},
    "UART_PI_TO_ZE": {"Pi.pin8.GPIO14.TX", "ZE29A.4.RX"},
    "UART_ZE_TO_PI": {"ZE29A.3.TX", "Pi.pin10.GPIO15.RX"},
    "BUTTON": {"Pi.pin11.GPIO17.IN", "Button.A"},
    "USB_DCP": {"SoloCable.D+", "SoloCable.D-"},
}


def assert_netlist() -> None:
    assert "Pi.pin8.GPIO14.TX" in NETS["UART_PI_TO_ZE"]
    assert "ZE29A.4.RX" in NETS["UART_PI_TO_ZE"]
    assert "ZE29A.3.TX" in NETS["UART_ZE_TO_PI"]
    assert "Pi.pin10.GPIO15.RX" in NETS["UART_ZE_TO_PI"]
    assert "Pi.pin11.GPIO17.IN" in NETS["BUTTON"]
    assert "Button.B" in NETS["GND"]
    gpio_endpoints = {endpoint for endpoints in NETS.values() for endpoint in endpoints if "GPIO" in endpoint}
    assert not (gpio_endpoints & NETS["+5V"])
    print("netlist_static_checks: PASS (pinout/crossing/domain only)")


def check_ze29a_frames() -> None:
    text = (ROOT / "componentes/winsen-ze29a/README.md").read_text(encoding="utf-8")
    matches = re.findall(r"(?<![0-9A-F])(?:[0-9A-F]{2} ){8}[0-9A-F]{2}(?![0-9A-F])", text)
    frames = list(dict.fromkeys(matches))
    invalid = []
    for source in frames:
        values = [int(value, 16) for value in source.split()]
        calculated = (-sum(values[1:8])) & 0xFF
        if calculated != values[8]:
            invalid.append((source, calculated, values[8]))
    print(f"ze29a_unique_frames: {len(frames)}")
    print(f"ze29a_valid_checksum_frames: {len(frames) - len(invalid)}")
    print(f"ze29a_invalid_checksum_frames: {invalid}")
    assert invalid == [("FF 01 87 32 00 00 00 00 48", 0x46, 0x48)]


def calculations() -> None:
    peak_loads = {
        "Pi branch design allowance": 2.5,
        "ZE29A documented maximum": 0.5,
        "display design estimate": 1.0,
        "Solo unverified estimate": 2.0,
    }
    rail = 5.15
    total = sum(peak_loads.values())
    print(f"peak_assumption_A: {total:.2f}")
    print(f"peak_assumption_W_at_{rail:.2f}V: {total * rail:.2f}")
    print(f"10A_source_current_headroom: {(10 - total) / 10:.1%}")
    print(f"50W_source_power_headroom: {(50 - total * rail) / 50:.1%}")

    internal_low, internal_high = 3.3 / 65_000, 3.3 / 50_000
    external = 3.3 / (2_200 + 220)
    print(f"button_internal_pull_current_uA: {internal_low * 1e6:.1f}..{internal_high * 1e6:.1f}")
    print(f"button_2k2_pull_220_series_current_mA: {external * 1e3:.3f}")
    print(f"button_gpio_low_with_220_series_V: {external * 220:.3f}")
    print(f"button_2k2_100n_open_tau_ms: {2_200 * 100e-9 * 1e3:.3f}")

    print(f"uart_9600_bit_us: {1e6 / 9600:.2f}")
    print(f"uart_9_byte_8N1_frame_ms: {9 * 10 / 9600 * 1e3:.3f}")

    ffc_loop = 0.46 + 0.46 / 4
    print(f"ffc_50cm_estimated_loop_ohm: {ffc_loop:.3f}")
    print(f"ffc_50cm_estimated_drop_at_250mA_V: {ffc_loop * 0.25:.3f}")

    for label, resistance_per_metre in (("28AWG", 0.232), ("24AWG", 0.0909)):
        cable_drop = resistance_per_metre * 0.6 * 2.0
        contact_bound = 0.28
        print(
            f"solo_{label}_2A_drop_bound_V: {cable_drop + contact_bound:.3f}; "
            f"load_voltage_from_5.15V: {5.15 - cable_drop - contact_bound:.3f}"
        )


if __name__ == "__main__":
    assert_netlist()
    check_ze29a_frames()
    calculations()
