# Inventario y auditoría documental del montaje eléctrico

## Identificación de la revisión

- Repositorio: `GuillermoAladro/Alcoholimetro`.
- Rama examinada: `main`.
- Commit examinado: `84be97669a9efec43e79b3dadc4af5e87458c41a`.
- Fecha del commit: 2026-10-21 19:07:01 +02:00.
- Alcance de este subinforme: inventario, lectura de Markdown y texto, contraste del montaje general y revisión visual de las cuatro figuras. La validación detallada de cada PDF se reparte en otros frentes de la auditoría.

## 1 Inventario exhaustivo

El commit contiene 234 archivos rastreados y solo dos directorios en la raíz: `componentes/` y `montaje-general/`.

| Formato | Cantidad | Comprobación realizada |
|---|---:|---|
| PDF | 150 | Los 150 abren con Poppler; suman 1541 páginas. Tres emiten avisos estructurales no fatales, indicados abajo. |
| Markdown | 69 | Todos leídos y recorridos. No hay enlaces relativos Markdown rotos. |
| PNG | 4 | Las cuatro figuras se abrieron y revisaron visualmente. |
| SVG | 4 | Los cuatro SVG se leyeron como XML y se contrastaron visualmente con sus PNG. |
| ZIP | 4 | Los cuatro abren y sus directorios internos se enumeran sin error. |
| XLSX | 1 | Paquete OOXML válido, 11 entradas internas y una hoja. Es la BOM de referencia de la Camera Module 3, no la lista de piezas de la máquina. |
| DXF | 1 | DXF ASCII R12 legible; dibujo mecánico de la Raspberry Pi 3B+. |
| SH | 1 | Script de descarga de documentación de Raspberry Pi, legible. |

Desglose de los 69 Markdown:

- 3 documentos de raíz: `README.md`, `LISTA-DE-COMPRA.md` y `MONTAJE-GENERAL.md`.
- 62 documentos de componente: `README.md` y `enlaces.md` para cada una de las 31 piezas.
- 1 índice general de componentes, 1 lista de pendientes, 1 índice de documentos compartidos y 1 lectura de anuncios de Amazon.

Desglose de los cuatro ZIP:

- `BCv1.2_070312_0.zip`: 6 entradas, 4 PDF de Battery Charging 1.2 más directorios.
- `usb_20_20250603.zip`: 42 entradas, especificación USB 2.0 y ECN.
- `USB_Type-C_2.5_Release_202603.zip`: 14 entradas, especificación USB Type-C 2.5 y ECN.
- `RP-008154-DS-1-camera-module-3-step.zip`: 4 entradas; dos modelos STEP y dos metadatos de macOS.

Avisos PDF no fatales:

- `componentes/kit-faston-aislados/datasheets/2672036.pdf`: tabla de sugerencias de offset no válida.
- `componentes/sumup-solo/datasheets/BRI42258_TECH.pdf`: referencia cruzada reconstruida.
- `componentes/terminales-ojal-m4/datasheets/A700000006574165.pdf`: grupo de contenido opcional mal formado.

No hay archivos corruptos o que no se puedan abrir a nivel de contenedor. Los STEP incluidos dentro del ZIP son CAD binario y no se han renderizado en este subinforme. Los 150 PDF requieren lectura técnica por materias; el control de apertura no equivale a validar todas sus afirmaciones.

## 2 Ausencias e incoherencias de estructura

### 2.1 El README promete cuatro carpetas que no existen

El `README.md` afirma que hay `carcasa/`, `hardware/`, `firmware/` y `docs/` en sus líneas 24 a 27. Ninguna está en el árbol del commit. Tampoco existe un esquema ECAD, netlist, firmware, banco de pruebas o simulación eléctrica ejecutable. El estado declara “Fase actual: diseño de la carcasa” en la línea 31, pero el diseño de la carcasa tampoco está versionado aquí.

El mismo README promete un “microcontrolador de bajo coste” como alternativa a Raspberry Pi en la línea 15, pero la lista de compra y el montaje usan una Raspberry Pi 3B+. La arquitectura efectiva es la de la lista y el montaje, no la descripción inicial.

### 2.2 El documento de montaje depende de fuentes que no están en Git

`MONTAJE-GENERAL.md` cita una guía de montaje eléctrico, `decisiones-diseno.md`, `diseno-cajon-A.md`, `cajon/specs.py` y `Lista_de_piezas.xlsx`. Ninguno está en el repositorio. La propia lista de compra reconoce en la línea 9 que la hoja del diseño A no está en Git.

Esto impide comprobar que el montaje reproduce la fuente de diseño, saber qué diseño manda y reconstruir las decisiones de los días 19 a 21 de octubre. Git contiene una interpretación de documentos externos, no la fuente de verdad completa.

### 2.3 Dos diseños incompatibles y ninguna selección

Las líneas 5 y 7 de `MONTAJE-GENERAL.md` dicen expresamente que el circuito es de papel, nunca montado ni medido, y que sigue el diseño antiguo. Las líneas 231 a 248 describen un diseño A posterior que:

- mueve Pi, ZE29A, fuente, C14 y antena;
- sustituye el punto de tierra único por dos espárragos con un puente;
- añade cuatro portafusibles de rama;
- elimina el pulsador;
- cambia el FFC de cámara;
- cambia la red Wi-Fi y la neumática.

La línea 248 admite que el documento no se ha rehecho sobre el diseño A. La figura 4 lleva en su propio título que representa `decisiones-diseno.md` del 20-10-2026, no el diseño A del 21-10-2026. Por tanto, la figura 4 es deliberadamente obsoleta si el diseño posterior es el elegido.

## 3 Resultado del contraste del montaje

### 3.1 Lo que sí está internamente bien trazado

Para el diseño antiguo, la tabla W1 a W29 y las figuras 1 a 3 forman una netlist comprensible:

- la LRS-50-5 está numerada de forma consistente: 1 AC/L, 2 AC/N, 3 FG, 4 DC -V y 5 DC +V;
- las dos WAGO 221-415 distribuyen +5 V y GND con polo 1 como troncal y polos 2 a 5 como cargas;
- el UART cruza TX con RX: Pi pin físico 8 a ZE29A RX y ZE29A TX a Pi pin físico 10;
- el pulsador usa GPIO17 en pin físico 11 y GND en pin 9, con pull-up interno;
- la cámara va por CSI y la pantalla por HDMI;
- el único periférico alimentado desde USB de la Pi es el AR9271;
- la Pi y el SumUp Solo no llevan cable de datos entre sí en el diseño antiguo.

La figura 3 usa numeración física correcta y advierte del daño que causaría desplazar el alojamiento hacia los pines de 5 V. Los diagramas incluyen avisos visibles, lo que evita presentar varias suposiciones como hechos.

### 3.2 Conclusión de montaje

El circuito no puede declararse construible, seguro ni funcional todavía. Tiene al menos cuatro bloqueos de seguridad y varios bloqueos de integración. Montar literalmente la figura 1 antes de resolverlos sería usar una ilustración condicional como plano de fabricación.

## 4 Bloqueos de seguridad

### B1 Topología desconocida del módulo C14

`MONTAJE-GENERAL.md`, líneas 50 a 64 y 179, deja W2 a W5 condicionados a una medición pendiente. La ficha del C14, líneas 32 a 36, confirma que cuatro terminales con luz no implican interruptor bipolar, que el módulo no está certificado y que el faston probablemente sea 4,8 x 0,8 mm. Con Schuko reversible, un único fusible e interruptor puede quedar en el neutro.

Solución propuesta: no utilizar el módulo genérico como parte cerrada del diseño. Sustituirlo por una entrada certificada con corte bipolar y, preferiblemente, fusible bipolar, con esquema y terminales documentados. Si se conserva el módulo, hay que identificar cada terminal sin tensión, dibujar y versionar su esquema real, y bloquear el encendido hasta una revisión competente. La alternativa certificada es más robusta que sostener dos “casos” en el plano de producción.

### B2 Protección insuficiente del raíl de 5 V

La línea 72 de `MONTAJE-GENERAL.md` reconoce que la LRS puede entregar aproximadamente 10,6 a 14,4 A antes de limitar y que el cable de 0,75 mm2 está catalogado para 6 A. La ficha del borne USB, líneas 31 y 34, lo identifica como el eslabón débil: conectores de referencia de 1 a 1,5 A y breakouts comparables de 0,1 a 0,5 A, frente a una fuente de 10 A. Un cortocircuito local puede carbonizar pistas o cable antes de que actúe la fuente.

El diseño A añade fusibles de 3 A, 3 A, 3 A y 2 A, pero esos valores tampoco están justificados frente al elemento más débil. Un fusible de 3 A no protege necesariamente un conector USB-A de 1 a 1,5 A.

Solución propuesta: adoptar protección individual en las cuatro ramas, situada junto a la WAGO. Elegir cada valor después de medir corriente estable, arranque y carga, y mantenerlo por debajo de la corriente admisible del cable, borne, pistas y conector. Si no existe un valor que permita el pico de la carga y proteja el borne USB, eliminar el breakout y usar un módulo de distribución DC documentado o un convertidor/cargador por rama con limitación de corriente.

### B3 Tierra de protección sin especificación cerrada

La línea 54 del montaje deja 1,5 frente a 2,5 mm2 abierto. La ficha H05VV-F, líneas 33, 185, 189 y 190, explica que la referencia conservadora de ITC-BT-19 es 2,5 mm2 con protección mecánica o 4 mm2 sin ella para un PE fuera de la canalización, mientras que los ojales comprados solo aceptan 0,5 a 1,5 mm2. La norma de producto aplicable no está cerrada.

El espárrago único con cinco ojales es además un punto único de fallo. Las fichas de espárrago y ojal recomiendan limitar el apilado y medir, no asumir, la continuidad.

Solución propuesta: fijar primero la norma de producto y la sección de PE; después comprar cable, ojales y herramienta compatibles. Usar un bloque o varios puntos de tierra con un conductor principal independiente y enlaces a cada parte móvil. La conexión del PE de entrada debe ser la última que se suelte mecánicamente. Ensayar cada pieza accesible con 10 a 25 A y exigir <=0,1 ohmios, registrando el valor.

### B4 Herramientas de terminación ausentes

La ficha de la crimpadora, líneas 32, 33, 49 y 327, establece que la herramienta comprada es para punteras. No resuelve ojales, faston ni terminales abiertos Dupont/JST. Esos crimpados están en 230 V, PE y señales críticas. La lista de 31 componentes no incluye las herramientas adecuadas.

Solución propuesta: añadir una crimpadora de trinquete para terminal preaislado del rango real y una herramienta para microterminales abiertos, o usar mazos precrimpados de fabricante. Validar cada familia con muestras, inspección y ensayo de tracción antes de montar el equipo.

## 5 Bloqueos funcionales y de integración

### F1 Alimentación no validada del SumUp Solo

El diseño une D+ y D- en un breakout USB-A y usa un cable A-C genérico. Las líneas 75 y 187 de `MONTAJE-GENERAL.md` dicen que no se sabe si el Solo reconoce ese cargador ni qué corriente soporta el borne. La ficha del cable exige 56 kohmios en CC; la ficha del Solo indica que el manual pide cable y adaptador incluidos o autorizados.

Solución: usar el sistema de carga original o un cargador USB certificado y documentado por SumUp, con acceso técnico. Si se mantiene la rama propia, medir negociación, corriente, tensión en el Solo, temperatura del conector y carga continua antes de aprobarla. No puentear D+ y D- como regla universal sin confirmar el comportamiento del lector real.

### F2 Conector y colores del ZE29A sin confirmar

El pinout funcional 1 Vin, 2 GND, 3 TX y 4 RX está respaldado, pero el tipo y paso del J1 no. La ficha JST, líneas 32, 175, 198 y 275, explica que los colores no son estándar y falta herramienta para el extremo Dupont. La figura 1 dibuja rojo para 5 V y negro para GND al mismo tiempo que avisa de verificar color y posición; esa combinación visual puede inducir a cablear por color.

Solución: numerar el conector físico por la serigrafía, comprobar continuidad hilo a hilo y documentar una tabla color-posicion por lote. No dar tensión hasta comprobar polaridad y que TX en reposo ronda 3,3 V. Sustituir la indicación roja/negra de la figura por “posición 1/posición 2” hasta conocer el mazo real.

### F3 Vía neumática indefinida

La ficha del tubo, líneas 28 y 29, confirma que “6 mm” puede ser diámetro interior o exterior y que ni guía ni manual dan las cotas de racor. También documenta condensación, memoria de etanol e higiene. Sin boquilla desechable, trampa y drenaje, el sistema puede contaminar la siguiente lectura o el sensor.

Solución: definir la neumática como conjunto medido; tubo corto y con pendiente hacia la boquilla, barrera de saliva/condensado y consumible por usuario. Ensayar blanco tras muestras de alcohol y tiempos de recuperación. No limpiar el tubo con alcohol.

### F4 FFC de cámara no identificado

La ficha FFC, líneas 34 a 38, exige contactos en caras opuestas y advierte del daño de usar el tipo equivocado. El anuncio no confirma esa característica. La caja suspendida además somete un FFC estándar a micromovimientos.

Solución: comparar cada cable con el oficial de 200 mm antes de enchufarlo, verificar “una pestaña por cara”, sujetarlo a 2 o 3 cm de ambos ZIF y hacer 24 horas de captura en la ruta final. Si el cable trabaja con movimiento repetido, rediseñar la interconexión.

### F5 Unión accidental de 0 V con PE por la antena

La ficha RP-SMA, líneas 29 y 253 a 258, muestra que el jack de panel toca el techo puesto a PE y probablemente conecta la malla USB, y por ella el 0 V de la Pi, a tierra. Esto contradice la decisión abierta de dejar -V flotante en la línea 73 del montaje.

Solución: decidir expresamente si DC- se une a PE. Si debe flotar, aislar mecánica y eléctricamente el conector de panel. Si debe unirse, hacerlo en un único punto definido y comprobar corrientes de lazo, EMC y continuidad. Medir antes y después del montaje.

### F6 Geometría y longitudes aún no comprobadas

Las líneas 204 a 229 dejan sin decidir orientación de Pi, ZE29A, pantalla, WAGO, bornes USB, pulsador, antena, fuente y paso de cables. Dos longitudes críticas no están medidas: latiguillo de Pi de <=15 cm y cable del Solo de 30 cm. No existe el CAD de la carcasa en Git para comprobarlo.

Solución: no cortar ni crimpar cables hasta congelar un layout 3D y generar una tabla de longitudes con holgura, radio de curvatura, separación de red y alivio de tracción.

### F7 Térmica sin margen

Las fichas dan 0-50 °C para Pi y cámara, 10-40 °C para ZE29A y un umbral a evitar de 40 °C para el Solo. La figura 4 coloca la fuente cerca del Solo y la cámara. La recomendación histórica de activar ventilación a 40 °C no deja margen al Solo ni al sensor.

Solución: sensor de temperatura junto al ZE29A y otro junto al Solo, carga máxima y caja cerrada durante al menos 72 horas en ambiente de verano. Bloquear medición fuera de 10-40 °C y diseñar ventilación para mantener el Solo por debajo de un margen conservador, no justo en 40 °C.

### F8 Integración del pago y recinto metálico

La ficha del Solo señala que el contactless y el Wi-Fi quedan detrás de acero, que la ranura de chip queda tapada y que una operación que exija chip fallaría. El montaje abrevia además los endpoints de la API; la ficha completa exige la ruta con merchant y un cuerpo `total_amount` correcto.

Solución: marco no metálico alrededor del lector, acceso a chip y botón de recuperación, prueba con tarjetas y móviles variados, ensayo de Wi-Fi/celular con caja cerrada y flujo de API sandbox con reconciliación de reintentos.

## 6 Observaciones por figura

### Figura 1 Alimentación y tierra

La distribución y numeración coinciden con la tabla W1-W18, pero no debe utilizarse como plano de fabricación: dibuja un C14 genérico cuya topología no se conoce, un PE aún sin sección cerrada, ramas DC sin protección y colores del mazo ZE29A no confirmados. Debe rehacerse después de elegir el diseño, el módulo C14 y los fusibles.

### Figura 2 Puertos y señales

El mapeo de puertos es coherente para el diseño antiguo. Falta código versionado que implemente UART, botón, cámara, Wi-Fi y pagos. Las rutas de API son abreviadas y no son una especificación software completa. Si manda el diseño A, cambia el modo de red y desaparece el pulsador.

### Figura 3 GPIO de 40 pines

La numeración física y los cruces UART son correctos. La solución de alojamiento 2x3 sigue abierta; los cables Dupont individuales no tienen retención para una máquina sometida a vibración. Conviene usar conector polarizado o una placa adaptadora con alivio de tracción.

### Figura 4 Colocación

Es un alzado del diseño antiguo y no una implantación definitiva. Marca correctamente muchas incógnitas, pero no contiene cotas suficientes para fabricar ni validar longitudes. Es incompatible con el diseño A descrito en el mismo Markdown.

## 7 Secuencia de cierre recomendada

1. Versionar en Git los documentos fuente y declarar un único diseño vigente.
2. Rehacer BOM, W1-W29 y las cuatro figuras para ese diseño.
3. Sustituir o caracterizar el C14; cerrar PE, terminales y herramientas.
4. Diseñar protección DC por rama a partir del elemento más débil y de corrientes medidas.
5. Congelar layout y longitudes; revisar separación de 230 V, cubiertas y alivio de tracción.
6. Hacer pruebas sin tensión: continuidad, ausencia de cortos, polaridad, pinout y aislamiento.
7. Hacer ensayo de PE con corriente de prueba y registrar <=0,1 ohmios.
8. Encender solo la fuente con limitación/aislamiento adecuados; ajustar el valor final por tensión real en cada carga y límites del fabricante.
9. Probar cada rama por separado con fusible provisional y registrar corriente de arranque, régimen, caída y temperatura.
10. Integrar UART, cámara, pantalla y Wi-Fi; 24 a 72 horas de estrés y brownouts controlados.
11. Probar sensor con blanco y patrón, recuperación, condensación y temperatura.
12. Probar pagos en sandbox y después una transacción real controlada; verificar NFC, chip, Wi-Fi y acceso técnico con caja cerrada.
13. Someter la parte de red, tierra, aislamiento, fuga, EMC y producto final a revisión de electricista/laboratorio competente antes de uso público.

## 8 Veredicto documental

El repositorio contiene una investigación amplia y honesta sobre los componentes, y los diagramas 1 a 3 son útiles como explicación del concepto antiguo. No contiene todavía un diseño eléctrico liberado para producción. El propio texto registra todas las señales de ello: esquema de papel, piezas no medidas, diseño posterior no incorporado, documentos fuente ausentes, sin firmware y sin ensayos.

La decisión de auditoría debe ser **NO APTO PARA ENERGIZAR COMO SISTEMA COMPLETO** hasta cerrar B1-B4 y F1-F7. Después se puede pasar a prototipo instrumentado y a las pruebas de la sección 7. Sin componentes físicos no puede emitirse un “funciona”; solo puede confirmarse que una parte importante de la conectividad lógica está bien planteada y que los riesgos críticos ya están identificados en las propias fichas.

