# Auditoría eléctrica del alcoholímetro

**Auditor 6**

Revisión documental y modelos del circuito

## Dictamen y control de revisión

**Dictamen de la revisión actual: no aprobado para construir y energizar siguiendo indistintamente los documentos del repositorio.** La arquitectura de una fuente de 5 V con cuatro ramas puede alimentar el sistema, pero la documentación contiene una asignación de bornes peligrosa, dos montajes sin reconciliar y varias condiciones de fallo sin resolver. El modelo también encuentra escenarios razonables en los que la Raspberry Pi queda por debajo del criterio de tensión recomendado. [R01–R05, C01–C03]

**La propuesta R1 es viable en el modelo resistivo bajo los requisitos que se definen en este informe.** A una salida efectiva de 5,10 V, con el presupuesto de resistencias de R1 y cargas ideales de potencia constante que suman 30 W, se calculan 4,903 V en el raíl de la Pi, 4,866 V en el Solo, 4,956 V en la pantalla y 5,023 V en el ZE29A. Esto demuestra que existe un presupuesto eléctrico compatible con los criterios adoptados. No demuestra que los cables, conectores, fuente y protecciones actualmente previstos cumplan ese presupuesto. [C01]

El trabajo realizado es una reconstrucción documental del circuito, una revisión de sus interfaces y la ejecución de modelos numéricos de conectividad, distribución de corriente y caída de tensión. **No se ha montado, energizado ni medido un circuito físico.** Tampoco se ha simulado el comportamiento interno de los circuitos integrados, la fuente conmutada, la batería del Solo o la electrónica del sensor. No se emite una certificación reglamentaria ni una validación metrológica del alcoholímetro.

| Dato | Identificación |
|---|---|
| Proyecto | GuillermoAladro/Alcoholimetro |
| Fecha | 21 de octubre de 2026 |
| Revisión del informe | Auditoría eléctrica v1 |
| Firma de la auditoría | Auditor 6 |
| Commit auditado | 84be97669a9efec43e79b3dadc4af5e87458c41a |
| Documento de conexión principal | MONTAJE-GENERAL.md, conexiones W1 a W29 y apartado 6.3 |
| Base examinada | 234 archivos versionados y 58 entradas de los ZIP; inventario con hashes adjunto |
| Resultado computacional | 548 escenarios DC, 23 escenarios DC de fallo y 26 comprobaciones de conectividad y seis extremos de resistencia R1 |
| Verificación de los cálculos | Cinco verificaciones del modelo DC y seis comprobaciones de integración |
| Ensayos físicos ejecutados | Ninguno |

La entrega de esta auditoría añade una revisión y una propuesta. **R1 no sustituye automáticamente al diseño del repositorio ni convierte las correcciones en un montaje implementado.** Los cambios necesarios quedan identificados para poder revisar y construir una única versión.

## Alcance y método

La pregunta auditada es si el sistema eléctrico documentado puede alimentar y comunicar todos sus elementos, tanto en operación normal como ante fallos previsibles de integración. El análisis precede a la cualificación de las unidades compradas. Por ello se aceptan las especificaciones publicadas de los componentes identificados y se declaran expresamente las propiedades que faltan en los elementos genéricos.

El estudio previo cubrió el contenido textual disponible de los documentos del repositorio, los archivos contenidos en los ZIP y los planos relevantes. El inventario tiene 292 entradas. Incluye 204 PDF y 3753 páginas, con una copia duplicada de 36 páginas; son 203 PDF únicos. Se examinaron las figuras necesarias para interpretar bornes y conexiones, sin atribuir a esta lectura una verificación dimensional de cada dibujo. El inventario adjunto permite comprobar la identidad de las fuentes. [R01, C04]

Se utilizaron tres métodos complementarios:

1. **Conectividad.** Un grafo representa conductores, contactos de interruptor, fusibles y uniones de protección. Se abren conexiones y se invierte la orientación del Schuko. Este método encuentra caminos eléctricos; no calcula corrientes de defecto ni tiempos de desconexión.
2. **Red resistiva DC.** Se resuelven las leyes de Kirchhoff en los conductores positivos y retornos, con cargas de corriente constante y de potencia constante. Se incluyen el troncal compartido, los cuatro ramales, los contactos y F1 de la Pi. Las resistencias no medidas se exploran como hipótesis.
3. **Integración.** Se calculan presupuestos de potencia, margen de sobretensión, capacidad de apoyo, sensibilidad al arranque y balance térmico. Estos cálculos determinan requisitos de diseño; no sustituyen formas de onda o ensayos reales.

En este informe, **confirmado documentalmente** significa que el hecho está en las fuentes; **resultado del modelo** significa que deriva de sus ecuaciones e hipótesis; **condicional** identifica una propiedad de hardware aún no acreditada; y **pendiente físico** identifica una medición todavía no realizada. Una comprobación del programa marcada PASS sólo valida su cálculo o el resultado esperado del escenario. Los fallos del diseño conservan su propio veredicto en los archivos de resultados.

## Circuito reconstruido y variantes

El circuito común recibe 230 V por un C14, atraviesa la protección de entrada y el interruptor y alimenta la LRS-50-5. Su salida se reparte mediante dos WAGO a Pi, Solo, pantalla y ZE29A. La Pi suministra energía a su cámara, microSD y adaptador AR9271: esos consumos forman parte de la rama Pi. El sensor utiliza 5 V para alimentación y UART de 3,3 V para comunicación. La pantalla recibe alimentación independiente y vídeo HDMI. El Solo recibe alimentación USB y se comunica por red. [R01, R03, R06, R07]

![Topología reconstruida del circuito](figuras/topologia-base.png)

**Figura 1.** Topología funcional reconstruida. Los bloques son interfaces del sistema; no representan un esquema de componentes internos. En el diseño A se añaden cuatro fusibles de rama. El retorno HDMI y la posible unión RF con chasis impiden interpretar todas las masas como una estrella aislada.

| Aspecto | Base de los apartados 1 a 6.2 | Variante A del apartado 6.3 |
|---|---|---|
| Red y fuente | Zona superior fija | Caja de red en cajón extraíble |
| Tierra de carcasa | C14 a espárrago de carcasa | C14 a cajón y puente con faston hacia carcasa |
| Protección de ramas | No definida | Pi 3 A, Solo 3 A, pantalla 3 A y ZE 2 A |
| Activación | Pulsador GPIO17 | Detección por cámara, sin pulsador |
| Cámara | FFC de 50 cm | Cinta de 200 mm indicada en el documento |
| Wi-Fi | Pi y Solo al router | Solo al AP de Pi; salida a Internet por AR9271 |

El propio documento advierte que no se ha rehecho sobre A. Los archivos que se citan como origen de A, entre ellos `diseno-cajon-A.md` y `cajon/specs.py`, no están en el commit auditado. Se evalúan ambas variantes y no se mezclan sus decisiones. En particular, la ausencia de fusibles sólo se atribuye a la base, no a A. [R01, C04]

### Conexiones de red y protección

| Cable | Conexión reconstruida | Condición de aceptación |
|---|---|---|
| W1 | Schuko a C13 y entrada C14 | Cordón de tres conductores; PE independiente de interruptor y fusible |
| W2 | Polo físico protegido del C14 a entrada A del interruptor | Identificar polo y fusible mediante esquema del módulo y continuidad sin tensión |
| W3 | Segundo polo a entrada C, si el interruptor es bipolar | No inferir DPST sólo por cuatro terminales o por tener luz |
| W4 | Salida B del interruptor a borne 1 AC/L de la fuente | Usar la numeración del fabricante |
| W5 | Salida D a borne 2 AC/N; directo en variante unipolar | R1 exige apertura de ambos polos; C13 fuera para mantenimiento |
| W6 | PE del C14 a punto de protección principal | En R1 ese punto pertenece a la carcasa fija |
| W7 | Punto PE a borne 3 FG de la fuente | Conexión permanente, independiente de los retornos de 5 V |
| W8 | PE a panel frontal si no es continuidad soldada acreditada | Unión específica y comprobable |
| W9 | PE a caja interior suspendida en la base | Cable flexible con holgura; los muelles no sirven como PE |
| W10 | PE a cajón | No debe convertir al cajón en el único enlace PE de la carcasa |

Los polos de una clavija Schuko pueden intercambiar fase y neutro. Las etiquetas L y N de los bornes de la fuente siguen siendo las del fabricante, pero no convierten al polo físico del C14 en una fase garantizada. El modelo utiliza A y B para evitar esa confusión. [R01, C02]

### Conexiones de alimentación continua

| Cable | Conexión reconstruida | Condición de aceptación |
|---|---|---|
| W11 | Borne 5 +V a primer puerto de WAGO positiva | Dimensionar para corriente total y proteger el alimentador |
| W12 | Borne 4 −V a primer puerto de WAGO de retorno | Retorno continuo y de baja resistencia; no fusible aislado en GND |
| W13 | Segundo par de puertos WAGO a micro-USB de Pi | VBUS pin 1 y GND pin 5; latiguillo 22 AWG de hasta 15 cm según base |
| W14 | Tercer par WAGO a adaptador USB-A del Solo | Protección en positivo, polaridad y corriente del puerto verificadas |
| W15 | USB-A del adaptador a USB-C del Solo | Cable A a C conforme; identificación de carga y resistencia total acreditadas |
| W16 | Cuarto par WAGO a adaptador USB-A de pantalla | Alimentación independiente de Pi y protección de rama |
| W17 | USB-A a entrada de alimentación de pantalla | Confirmar extremos reales, pinout y consumo de esa pantalla |
| W18 | Quinto par WAGO a ZE29A, pin 1 Vin y pin 2 GND | Ventana oficial 4,7 a 5,3 V; conector identificado por función, no por color |

En A, los fusibles de 3/3/3/2 A se intercalan entre distribución y cargas. El documento no define una referencia, curva, resistencia en caliente o poder de corte de esos conjuntos. El modelo supone que van en el positivo y trata su resistencia como parámetro, no como característica acreditada. [R01, C01]

### Conexiones de señales y periféricos

| Cable | Conexión reconstruida | Resultado de la revisión |
|---|---|---|
| W19 | Pi pin físico 8, TX GPIO14, a ZE pin 4 RX | Cruce correcto; falta protección de estados de alimentación parcial |
| W20 | ZE pin 3 TX a Pi pin físico 10, RX GPIO15 | Cruce correcto; ambos lados son UART de 3,3 V en operación |
| W21 | Contacto de pulsador a Pi pin 11 GPIO17 | Sólo base; habilitar pull-up y antirrebote |
| W22 | Otro contacto de pulsador a Pi pin 9 GND | Sólo base; LED del pulsador no conectado |
| W23 | HDMI Pi a HDMI pantalla | Vídeo correcto conceptualmente; también puede unir retornos |
| W24 | CSI de Pi a Camera Module 3 | Confirmar orientación y longitud elegida; conectar sin alimentación |
| W25 | USB Pi a AR9271 | Su consumo pertenece a Pi; no sumar otra rama de 5 V |
| W26 | RF AR9271 a pasamuros y antena | El cuerpo puede tocar PE; medir si RF está unido a USB GND |
| W27 | microSD en Pi | Depende de alimentación estable y política de apagado |
| W28 | Boquilla y neumática a ZE29A | No es conexión eléctrica; requiere validación de flujo y condensación |
| W29 | Red de Pi y Solo y servicio de pago | No es enlace USB de datos; requiere software y conectividad operativos |

La UART tiene referencia de masa a través de W13, W18 y WAGO. No se ha identificado una ausencia de GND común en funcionamiento normal. La cuestión es la caída de ese retorno y qué ocurre cuando se abre o cuando sólo una placa está alimentada. [R01, R06, C01, C02]

## Hallazgos y correcciones

### A01 Asignación contradictoria de los bornes de la fuente

**Prioridad crítica. Hecho documental confirmado.** La ficha `componentes/meanwell-lrs-50-5/README.md` presenta en varias partes el orden 1 −V, 2 +V, 3 FG, 4 AC/L y 5 AC/N. El plano del fabricante indica **1 AC/L, 2 AC/N, 3 FG, 4 −V y 5 +V**. `MONTAJE-GENERAL.md` sí utiliza el orden correcto. Seguir la ficha errónea podría conectar la red a los bornes de salida; no se debe intentar validar esa discrepancia energizando la fuente. [R01, R02, R03]

La corrección consiste en sustituir las tres asignaciones erróneas, retirar cualquier esquema derivado de ellas y usar una única tabla de bornes respaldada por el plano de la revisión comprada. La aceptación exige concordancia entre plano, serigrafía visible y lista de conexiones. Esta auditoría documenta la corrección; no modifica silenciosamente la ficha histórica.

### A02 Dos versiones de montaje sin una lista única de conexiones

**Prioridad alta. Hecho documental confirmado.** Las figuras principales corresponden a la base y el apartado 6.3 introduce A con otra ubicación de la red, puesta a tierra, fusibles, FFC y Wi-Fi. Es posible fabricar una combinación que nunca se haya revisado como conjunto. [R01]

Debe publicarse una revisión única con lista W actualizada, esquema de red, mapa de masas, protecciones y longitudes. La propuesta R1 de este informe adopta un cajón de electrónica con red fija fuera del cajón. Es una decisión de corrección propuesta, no una atribución al diseño original.

### A03 La carcasa depende de un puente desmontable en A

**Prioridad crítica. Riesgo de topología confirmado; fallo físico no observado.** En A, C14 y fuente están en el cajón. El puente con faston es el enlace explícito entre PE del cajón y carcasa. El grafo pierde la conexión PE de la carcasa cuando se retira ese puente con C13 todavía conectado. El repositorio no describe una secuencia mecánicamente impuesta que lo impida. Dos espárragos no aportan dos caminos de protección independientes. [R01, C02 T08_A]

R1 coloca C14, protecciones de entrada y fuente en un compartimento fijo; une PE directamente a carcasa y FG. El cajón recibe su propia unión de protección, pero retirarla no interrumpe la de la carcasa. Se desconecta C13 antes de intervenir. Si se conserva A, debe impedirse retirar o separar su PE con la red conectada mediante un diseño verificable de acceso o interbloqueo; un recordatorio escrito no equivale a esa función.

### A04 El interruptor y el fusible de entrada no están resueltos

**Prioridad alta. Resultado topológico y falta de coordinación.** Un interruptor unipolar apagado puede dejar un borne de la fuente conectado a fase al invertir el Schuko. Un DPST correctamente identificado abre ambos conductores hacia la fuente, pero la entrada anterior al interruptor sigue con tensión. Un fusible en un único polo cubre un corto entre polos en las dos orientaciones; no garantiza que una derivación a chasis del otro polo activo atraviese ese fusible. La desconexión de esa derivación depende también de la instalación y de su impedancia, fuera del modelo. [R01, R03, C02]

La solución propuesta es un módulo documentado con corte bipolar y protección de ambos polos físicos si se quiere cubrir localmente las dos orientaciones. El PE nunca se conmuta ni se fusila. La selección de dos fusibles es una decisión de diseño de R1, no una afirmación de obligación legal universal. Dos fusibles independientes tampoco aseguran apertura simultánea de los dos polos; se retira C13 para mantenimiento. Un ejemplo de familia con configuración adecuada es Schurter KD; debe confirmarse la referencia, el montaje y la protección exactos. [R10]

Tampoco se da por aprobado el T2,5 A únicamente porque la fuente anuncie 45 A típicos de arranque. Falta la duración y forma de ese pulso, las condiciones en caliente y la comparación con la curva del fusible real. Un pulso rectangular hipotético de 45 A produce 2,025 A²s en 1 ms y 20,25 A²s en 10 ms: el mismo pico representa diez veces más esfuerzo. La selección requiere información o ensayo de coordinación, incluyendo poder de corte. [R03, R11, C03]

### A05 La tensión de la Pi puede ser insuficiente

**Prioridad alta. Resultado del modelo sujeto a resistencias y cargas declaradas.** Con 0,50 m de troncal de 0,75 mm², latiguillo Pi de 15 cm, contactos de referencia y 5 A simultáneos, la base calcula 4,808 V tras F1 de Pi con fuente a 5,20 V. Añadir 20 mΩ en la protección externa de A reduce el resultado a 4,768 V. Un ajuste nominal de 5,10 V produciría 4,668 V en ese mismo escenario A. [C01]

Raspberry Pi recomienda mantener la alimentación por encima de 4,8 V para un funcionamiento fiable. El aviso de subtensión de 4,63 V ±5 % es un diagnóstico, no el mínimo de diseño; su intervalo publicado alcanza 4,8615 V por el extremo superior. La ausencia de un aviso no acredita margen suficiente. Deben medirse el conector de entrada y el raíl GPIO tras F1. [R04, R05, R07]

La corrección reduce resistencia común y de ramales, incluye los elementos de protección en el presupuesto y comprueba tensión en cada carga. Se mantiene F1 y la entrada micro-USB de la Pi. Si no se cumple el presupuesto, se rediseña el alimentador o se proporciona una alimentación regulada dedicada; no se puentea F1 como remedio ni se sube sin límite el raíl compartido.

### A06 El ajuste de tensión no garantiza una ventana segura

**Prioridad alta. Especificación y presupuesto de tolerancias.** El margen entre 5,20 V y el techo provisional de sistema de 5,25 V es sólo 50 mV. La fuente especifica regulación, coeficiente térmico y rizado; su nota 7 advierte que en 3,3/5 V y cargas de 0 a 50 % el modo de ráfagas puede superar el rizado indicado. La carga típica estimada de 2,3 A cae en esa zona. No se puede utilizar 80 mVpp como cota universal. [R03, C01]

La OVP de la fuente, 5,9 a 7,3 V, tampoco protege por sí sola el máximo oficial de 5,3 V del ZE29A. R1 exige una ventana efectiva medida de fuente de 5,10 a 5,20 V en los estados previstos, más protección de salida que evite superar la ventana admisible de los receptores ante una avería. El valor del trimmer se elige después de medir; no se equipara una consigna a una garantía. [R03, R06]

El techo de 5,25 V y el suelo de 4,75 V para Solo y pantalla se utilizan aquí como objetivos provisionales de integración, porque sus ventanas exactas no están acreditadas para las unidades previstas. Si sus especificaciones resultan más estrictas, se actualizan los criterios y se recalcula el circuito. Una TVS genérica no se considera un limitador preciso de 5,25 V: hace falta una función de corte o regulación cuyas tolerancias y sobreimpulso se hayan comprobado.

### A07 Los fusibles de rama no acreditan selectividad

**Prioridad alta. Contraejemplo calculado y dinámica pendiente.** Los calibres de A suman 11 A. El escenario 2,9 + 2,9 + 2,9 + 1,9 A no supera ninguno de ellos, pero demanda 55,12 W a 5,20 V, por encima de los 50 W nominales y dentro del extremo inferior del intervalo de protección por sobrecarga de la fuente. Este ejemplo muestra una sobrecarga agregada sin que una rama exceda su calibre; los cuatro fusibles no garantizan evitar la caída de la alimentación común. [R01, R03, C03]

Ante un corto duro, la fuente puede entrar en hiccup antes de que el fusible de rama acumule energía suficiente para abrir. Sin curvas, resistencias, capacidad de salida y forma del hiccup no es posible predecir el despeje. Las corrientes de cortocircuito de fuente ideal del archivo numérico sólo muestran que se rebasa su dominio nominal; **no son corrientes que se afirme que entrega la LRS**. [C01]

R1 incorpora limitación y corte por rama en el positivo, arranque controlado y señal de fallo. Debe cumplirse que la suma de corrientes sanas y el máximo de limitación de la rama en fallo no haga caer la fuente durante el tiempo de actuación. La protección del troncal se coordina con su sección y recorrido. Los fusibles pueden seguir proporcionando protección de cableado, pero se validan por curva e I²t; no se confunde ese cometido con mantener encendida la Pi.

### A08 Las masas de señales pueden convertirse en retornos de potencia

**Prioridad alta. Caminos condicionales de fallo.** Alimentar Pi y pantalla desde la misma estrella no evita que HDMI una sus masas. Con un enlace de retorno HDMI hipotético de 0,10 Ω y el negativo de Pi abierto, el modelo obliga a los 2 A de carga de Pi a volver por HDMI y por el retorno de pantalla. La tensión calculada de Pi cae a 4,471 V. La corriente real dependería de limitación y apagado de la placa, pero el camino alternativo existe si esas masas están unidas. [C01, C02]

Asimismo, si el AR9271 une masa USB y blindaje RF, el pasamuros metálico conectado al chasis une GND de Pi con PE. El requisito del documento de encontrar circuito abierto entre pin 6 y caja sería incompatible con esa configuración. Una sola unión RF no demuestra por sí misma que circule corriente de carga por PE: para ello tiene que existir otro camino que cierre el circuito. [R01, C01, C02]

R1 conserva retornos dedicados, continuos y de baja resistencia, y exige un mapa medido de GND, blindajes y chasis. Se adopta una electrónica referenciada al chasis cuando los blindajes de los equipos así lo impongan; no se exige una falsa condición de flotación. Los cables de protección siguen siendo independientes. No se cortan PE ni masas funcionales de HDMI para eliminar un lazo. Se utilizan conectores enclavados, retorno que conecte primero y se separe al final cuando corresponda, y mantenimiento sin energía. Estas medidas reducen la probabilidad de apertura; no demuestran tolerancia a un conductor roto en servicio. Para cerrar ese fallo se exige una solución específica: retornos redundantes de potencia con terminaciones independientes, o detección de corriente desviada con desconexión y energía de fallo limitada. Se debe validar sin cortar PE ni masas funcionales de HDMI. Este requisito permanece abierto hasta implementar y ensayar esa medida.

### A09 La UART directa no cubre alimentación parcial

**Prioridad alta. Compatibilidad normal documentada y fallo condicionado no caracterizado.** TX y RX están correctamente cruzados y el manual declara TTL de 3,3 V. No aporta corrientes máximas de inyección ni tolerancia de los pines del ZE29A cuando está apagado. Un fusible abierto en una rama puede dejar el otro TX activo e inyectar corriente por el receptor sin alimentación. Añadir una resistencia serie arbitraria no demuestra que esa condición sea admisible. [R01, R06]

Para tolerar secuencias diferentes se especifica una interfaz de dos direcciones fijas con aislamiento durante apagado, salidas de alta impedancia y habilitación condicionada a alimentaciones válidas. Un traductor como TXU0202 ilustra funciones Ioff y de desconexión por alimentación, pero debe alimentarse cada lado al nivel lógico correcto; 5 V de Vin del ZE no significa UART de 5 V. Su selección no certifica los límites desconocidos del sensor. [R12]

Si el requisito incluye tolerar la apertura del retorno sin camino por señales, R1 requiere separación galvánica de los dos canales UART, con alimentación y referencia locales a cada lado, y estados definidos durante rampas y apagado. El lado ZE necesita una alimentación lógica local de 3,3 V derivada de su rama; no se alimenta el aislador de ese lado desde Pi. La barrera de señal no convierte al sistema entero en aislado porque las alimentaciones siguen compartiendo la estrella. El esquema detallado y sus estados de arranque se revisan antes de fabricar la interfaz.

### A10 El puente de datos USB no garantiza que cargue el Solo

**Prioridad alta para funcionamiento. Identificación incompleta.** Un puente D+ a D− satisface la condición resistiva de identificación DCP si es de hasta 200 Ω. No garantiza por sí solo la corriente disponible, la protección ni el reconocimiento del Solo. El cable legado USB-A a USB-C requiere Rp de 56 kΩ ±5 % y anuncia corriente USB por defecto; no se transforma en una fuente Type-C de 3 A sustituyendo esa resistencia. [R08, R09]

R1 utiliza un puerto de carga documentado y protegido, compatible con el receptor. Si una solución DCP de 1,5 A mantiene el Solo cargado durante el ciclo de uso, puede ser suficiente tras comprobarlo. Si se requiere mayor potencia mediante Type-C, se implementa una fuente Type-C real, su controlador CC, la capacidad anunciada y cable C a C, y se revisa el presupuesto total. Los 2 A empleados en el cálculo son una hipótesis de carga del proyecto; no acreditan un contrato USB de 2 A.

El Solo incorpora batería: abrir su rama de 5 V no equivale a apagarlo. Debe medirse si aparece corriente inversa hacia el puerto; esta auditoría no afirma que la unidad la produzca. La pantalla requiere confirmar sus conectores y necesidades reales. El borne S libre del adaptador no prueba que el blindaje esté aislado de GND: existen uniones dentro de los conectores especificadas por USB. Debe incluirse ese camino en el mapa de masas. [R08]

### A11 Temperatura y montaje pueden invalidar el circuito correcto en papel

**Prioridad alta. Requisitos de integración sin ensayo.** El ZE29A especifica 10 a 40 °C. El funcionamiento de la fuente en su propio rango no acredita que el sensor, a otra temperatura y posición, esté dentro del suyo. Tampoco la temperatura de CPU equivale a temperatura de aire junto al sensor. [R03, R06]

Como sensibilidad, 2,3 A a 5,20 V con una eficiencia supuesta de 83 % representan 14,41 W que acabarían como calor si toda la energía se disipase dentro. A 5 A serían 31,33 W. El 83 % publicado es típico a carga nominal, no una eficiencia garantizada en estos dos puntos. Con ambiente exterior de 35 °C y límite de sensor de 40 °C, esos balances requerirían resistencias térmicas globales aproximadas de 0,347 y 0,160 K/W, respectivamente. No se ha calculado una temperatura real de la caja. [C03]

La corrección separa el aire caliente de la fuente del sensor, define ventilación y evita condensación o líquido procedente de la neumática sobre red o electrónica. Los terminales de red quedan cubiertos y sujetos; el cableado se segrega del FFC y de señales y no roza cantos o piezas móviles. Las holguras de extracción, radios de curvatura y paso de cables se comprueban con un prototipo mecánico. La sección eléctrica por sí sola no acredita aptitud para flexión repetida.

### A12 El circuito alimentado no demuestra la función completa

**Prioridad media en esta auditoría eléctrica. Límite de implementación confirmado.** El commit contiene documentación y un descargador de documentos, pero no la aplicación de control que permita ejecutar el ciclo completo. La UART requiere configuración y validación de tramas; A requiere conservar la radio que haga de AP, por lo que desactivar indiscriminadamente el Wi-Fi interno contradice esa arquitectura. CSI y HDMI necesitan configuración y pruebas del cable y pantalla elegidos. [R01, C04]

Se propone una prueba funcional posterior con registro de estados de alimentación, UART, cámara, pantalla y red. El resultado numérico de alcohol requiere confirmar unidades y calibración; el divisor 220 propuesto en otra ficha no queda validado por una prueba eléctrica. Los pagos requieren reconciliar su estado final: un timeout o una solicitud de terminación no equivalen a confirmación de impago. Estos puntos quedan separados de la aprobación del cableado. [R06, R13]

## Resultados eléctricos cuantitativos

### Entradas y criterios del modelo DC

Las corrientes se toman como presupuestos, no como consumos medidos. La rama Pi incluye cámara, tarjeta y adaptador Wi-Fi. La cota de 0,5 A del ZE procede del fabricante; su consumo típico de 0,1 A es una estimación. Solo y pantalla carecen de un perfil de carga confirmado para esta integración. [R01, R06, C01]

| Escenario | Pi | Solo | Pantalla | ZE | Total CC |
|---|---|---|---|---|---|
| Típico estimado | 0,9 A | 0,8 A | 0,5 A | 0,1 A | 2,3 A |
| Pico del presupuesto original | 2,0 A | 2,0 A | 0,5 A | 0,5 A | 5,0 A |
| Sensibilidad de pantalla | 2,0 A | 2,0 A | 1,0 A | 0,5 A | 5,5 A |
| Dimensionado ampliado | 2,5 A | 2,0 A | 1,0 A | 0,5 A | 6,0 A |

El modelo CP asigna a cada carga una potencia igual a 5 V por su corriente de presupuesto. Con menor tensión, esa carga ideal absorbe más corriente. Sirve para comprobar que una estimación a corriente constante no oculta ese efecto. No reproduce el algoritmo de carga del Solo ni la desconexión por baja tensión de un equipo real.

| Parámetro de referencia | Valor | Naturaleza |
|---|---|---|
| Troncal positivo y retorno | 0,50 m por conductor, 0,75 mm² | Longitud heredada del presupuesto, sin medir |
| Resistencia de cobre del troncal | 26 Ω/km por conductor a 20 °C | Referencia genérica de cable flexible, no certificación del comprado |
| Contactos comunes | 5 mΩ por conductor | Hipótesis de sensibilidad |
| Pi | 15 cm por conductor, 22 AWG | Longitud prevista, calibre a confirmar |
| F1 de Pi | 50 mΩ en perfil de referencia | Hipótesis, no resistencia medida |
| Protección externa de A | 20 mΩ por rama | Hipótesis de fusible y portafusible |
| Solo | Alimentador 20 cm y cable A a C 30 cm, 22 AWG supuesto | Recorrido y calibre sin verificar |
| Pantalla | Alimentador 20 cm y cable 50 cm, 24 AWG supuesto | Recorrido y calibre sin verificar |
| ZE | 15 cm por conductor, 22 AWG | Hipótesis del latiguillo previsto |

Se exploran contactos bajos, de referencia y altos; temperaturas de conductor de 20, 40 y 60 °C; cables Pi de 15 y 30 cm; alternativas de calibre USB y resistencias de protección. No se atribuye una distribución estadística a esos perfiles. Las temperaturas de cable exploradas tampoco autorizan a situar el sensor a 60 °C. [C01]

Para el caso de estrella sin retornos paralelos se verifica la relación:

$$V_{\mathrm{carga}} = V_{\mathrm{fuente}} - I_{\mathrm{total}} R_{\mathrm{troncal}} - I_{\mathrm{rama}} R_{\mathrm{rama}}$$

Las dos resistencias incluyen ida y retorno. En la rama Pi se añade F1. En consecuencia, el máximo de resistencia admisible es:

$$R_{\mathrm{rama,max}} = \frac{V_{\mathrm{fuente,min}} - V_{\mathrm{carga,min}} - I_{\mathrm{total}} R_{\mathrm{troncal}}}{I_{\mathrm{rama}}}$$

Esta expresión es válida para el caso CC indicado. En CP se resuelve la red no lineal; no se aplica la fórmula manteniendo una corriente que ya ha cambiado. [C01]

### Comparación del circuito documentado

Los valores siguientes son tensiones diferenciales en las cargas a 20 °C, perfil de contactos de referencia y carga CC. La Pi se informa después de F1. Todos los valores son calculados. [C01]

| Variante y condición | Fuente | Pi | Solo | Pantalla | ZE |
|---|---|---|---|---|---|
| Base, típico 2,3 A | 5,20 V | 5,022 V | 5,036 V | 5,040 V | 5,113 V |
| Base, pico 5 A | 5,20 V | 4,808 V | 4,816 V | 4,943 V | 4,997 V |
| A, pico 5 A | 5,20 V | 4,768 V | 4,776 V | 4,933 V | 4,987 V |
| A, pico 5 A | 5,15 V | 4,718 V | 4,726 V | 4,883 V | 4,937 V |
| A, pico 5 A | 5,10 V | 4,668 V | 4,676 V | 4,833 V | 4,887 V |
| A, dimensionado 6 A | 5,20 V | 4,669 V | 4,740 V | 4,809 V | 4,951 V |

**Interpretación:** la potencia total nominal disponible no resuelve las caídas. El troncal de referencia tiene 36 mΩ de lazo; a 5 A pierde 0,18 V y disipa 0,90 W. La rama Pi de referencia añade 105,888 mΩ incluyendo F1; A suma otros 20 mΩ. El escenario base de 5 A queda apenas 8 mV por encima de 4,8 V, antes de considerar rizado, transitorios y variación de resistencias. [C01]

![Tensión calculada en la Raspberry Pi](figuras/tension-pi.png)

**Figura 2.** Sensibilidad de la tensión tras F1 al ajuste de fuente. Cada línea usa hipótesis de resistencia y carga indicadas; no es una curva medida. El objetivo de R1 es reducir pérdidas manteniendo una ventana de salida acotada.

### Tolerancias y transitorios

El barrido de fuente utiliza como sensibilidad ±2,25 %: ±0,5 % de línea, ±1 % de carga y ±0,75 % por 25 K de variación. No se añade de nuevo la tolerancia global de fábrica de ±2 %, porque la nota 3 ya incluye ajuste, línea y carga. La suma de límites usada es exploratoria; no constituye una garantía combinada para todos los estados de la fuente ajustada. El rizado y las rampas quedan fuera de ese barrido. [R03, C01]

Una consigna de 5,20 V con +2,25 % alcanzaría 5,317 V en el modelo, incluso sin añadir rizado. Eso basta para mostrar por qué medir sólo en vacío una vez no cierra el presupuesto. La propuesta se acepta por tensión observada en fuente y cargas bajo los estados definidos, no por la posición del trimmer.

Un condensador de 1000 µF ideal sólo sostiene un incremento de 0,5 A durante 0,4 ms si se permite una caída de 0,2 V. Para 10 ms harían falta 25 mF en ese modelo aislado. Además, cargar 1000 µF a 5,15 V en 1 ms exige 5,15 A de corriente capacitiva ideal. Son sensibilidades que justifican medir el escalón real y controlar el arranque; no constituyen una recomendación de instalar 25 mF. [C03]

### Resultados ante aperturas y cortocircuitos

| Caso | Resultado ejecutado | Alcance del resultado |
|---|---|---|
| SPST apagado y Schuko invertido | Un borne AC de fuente sigue conectado directamente a fase | Topología confirmada para esa variante |
| DPST apagado, ambas orientaciones | Ambos bornes hacia fuente abiertos; entrada C14 aún activa | No equivale a mantenimiento sin tensión |
| Puente PE de A abierto | Carcasa pierde su camino PE explícito | Riesgo si puede ocurrir con C13 conectado |
| Puente de cajón abierto en R1 | Carcasa fija conserva su camino PE | El cajón necesita su propio procedimiento seguro |
| Retorno Pi abierto, HDMI 0,10 Ω | 2 A ideales por retorno HDMI; Pi 4,471 V | Depende de unión de masas y comportamiento real de carga |
| Retorno pantalla abierto | Su corriente puede regresar por HDMI y Pi | HDMI no se acepta como conductor de retorno de potencia |
| Rama positiva abierta | La carga queda sin alimentar en el modelo resistivo | Inyección por pines y blindajes activos no modelada |
| Corto de 10 mΩ en cada rama | La proyección con fuente ideal rebasa los límites nominales | No predice corriente real, hiccup ni apertura de fusible |
| RF unido internamente a USB GND | GND de Pi tiene camino a chasis | Condición que debe medirse en el dongle real |

## Propuesta eléctrica R1

R1 corrige la topología de mantenimiento, reduce el presupuesto de caída y define protecciones e interfaces como requisitos verificables. Es una propuesta de ingeniería para desarrollar el esquema final y cualificar sus componentes. No se presenta como un PCB terminado o un montaje ya validado.

![Arquitectura eléctrica propuesta R1](figuras/topologia-r1.png)

**Figura 3.** La red y el PE principal permanecen en la carcasa. El cajón recibe alimentación de baja tensión y su unión de protección. P0 representa la protección del alimentador; P1 a P4 protegen los positivos de cada rama. Las funciones de protección se seleccionan y coordinan con el presupuesto de resistencia.

### Red y puesta a tierra

El C14, la protección de entrada, el DPST y la fuente quedan en un recinto fijo con bornes inaccesibles durante el uso normal. El PE del C14 llega directamente al punto de protección de carcasa. De ahí salen enlaces a FG y a las piezas metálicas que lo requieran; la continuidad del frontal no depende de pintura, muelles o contacto casual. El cajón no transporta red ni contiene el único punto que protege la carcasa.

El cable PE del cajón tiene holgura para el recorrido previsto y una unión que no se suelta accidentalmente. La separación completa se realiza después de retirar C13 y comprobar ausencia de energía. La clasificación de la salida como SELV o PELV depende del esquema final, aislamiento y conexiones a tierra; no se deduce sólo de que sean 5 V.

### Ventanas y resistencias objetivo

| Requisito R1 | Límite u objetivo | Verificación necesaria |
|---|---|---|
| Fuente efectiva en sus bornes | 5,10 a 5,20 V con alimentación establecida y cargas habilitadas | Medición DC y osciloscopio; carga ligera y escalones normales |
| Pi tras F1 | Más de 4,8 V; objetivo de diseño al menos 4,90 V en estados normales | Medición en GPIO y registro bajo carga; no basta el LED |
| ZE en sus pines 1 y 2 | 4,70 a 5,30 V oficiales | Medición durante calentamiento, muestreo y recuperación |
| Solo y pantalla | Objetivo provisional 4,75 a 5,25 V | Confirmar primero ventana de sus referencias exactas |
| Troncal completo | Hasta 9,4 mΩ, ida y retorno con conexiones y protección común | Medición de caída a corriente conocida, en caliente |
| Rama Pi completa | Hasta 55 mΩ, incluyendo protección externa, cable, micro-USB y F1 | Presupuesto y medición de la unidad real |
| Rama Solo y pantalla | Hasta 87 mΩ cada una | Incluye todos los cables y contactos |
| Rama ZE | Hasta 40 mΩ | Incluye conector y protección de rama |

Durante arranque y apagado la fuente atraviesa tensiones inferiores al rango normal. Se especifican rampas admisibles, habilitación y estados seguros; se comprueba también el límite superior y el sobreimpulso en esas transiciones. No se exige que exista 5,10 V desde el instante de conexión.

La realización numérica de R1 usa troncal de 20 cm por conductor y 1,5 mm², contactos comunes de 2 mΩ por conductor, cables cortos y el perfil objetivo documentado en el script. Produce 9,320 mΩ de troncal y lazos de 54,888 / 86,176 / 86,176 / 39,888 mΩ. **Estos valores son objetivos hipotéticos, no propiedades concedidas al material de la lista de compra.** En particular, F1 se supone de 15 mΩ en ese perfil y la protección externa de 10 mΩ; el presupuesto debe rehacerse si en caliente tienen valores superiores. [C01]

Si se añade un protector común P0, su resistencia pertenece al presupuesto de 9,4 mΩ, no se añade gratuitamente. Si ese valor total no resulta alcanzable, se coloca la distribución más cerca de la fuente, se aumenta sección, se reduce el número de contactos o se separan alimentaciones. El modelo no justifica mantener un objetivo incumplido asignando al componente una resistencia ideal.

### Resultado numérico de la propuesta

| Fuente efectiva y carga | Corriente de fuente | Pi | Solo | Pantalla | ZE |
|---|---|---|---|---|---|
| 5,10 V y vacío | 0 A | 5,100 V | 5,100 V | 5,100 V | 5,100 V |
| 5,10 V y típico CC | 2,300 A | 5,029 V | 5,010 V | 5,035 V | 5,075 V |
| 5,10 V y dimensionado CC | 6,000 A | 4,907 V | 4,872 V | 4,958 V | 5,024 V |
| 5,10 V y dimensionado CP | 6,111 A | 4,903 V | 4,866 V | 4,956 V | 5,023 V |
| 5,20 V y dimensionado CP | 5,984 A | 5,007 V | 4,971 V | 5,059 V | 5,125 V |
| 5,20 V y vacío | 0 A | 5,200 V | 5,200 V | 5,200 V | 5,200 V |

Los doce escenarios específicos de R1 satisfacen los criterios estáticos adoptados en sus parámetros. Además se ejecuta un ensayo independiente con todas las resistencias en sus máximos de 9,4 / 55 / 87 / 87 / 40 mΩ: a 5,10 V y 30 W CP, Pi queda en 4,902300 V, Solo en 4,863662 V, pantalla en 4,954745 V y ZE en 5,022630 V; la fuente entrega 6,112768 A. El margen de Pi sobre el objetivo de 4,90 V es sólo 2,3 mV, y sobre el criterio de 4,8 V es 102,3 mV. Por ello tolerancias e incertidumbre de medida deben estar contenidas en esas cotas; no se añade margen por redondeo. [C05] La fila de 5,10 V y CP disipa 1,166 W en las resistencias modeladas. En ella la Pi demanda aproximadamente 2,549 A para mantener sus 12,5 W ideales; también debe verificarse la capacidad térmica de F1, ya que la corriente supera ligeramente 2,5 A. El paso siguiente es comprobar que el conjunto real cumple sus ventanas y resistencias, incluyendo el efecto de temperatura y envejecimiento. La inductancia de cables, los condensadores, las respuestas de regulación y los pulsos reales pueden producir caídas adicionales; por eso se mide también en cada receptor. [C01]

### Protección y comportamiento ante fallo

P1 a P4 deben limitar o desconectar una rama en corto sin interrumpir los retornos. Se especifican tensión admisible, corriente normal, umbral máximo con tolerancia, tiempo de actuación, arranque, capacidad de carga, energía admisible, bloqueo de corriente inversa cuando sea necesario y estado después de fallo. El diseño debe registrar el fallo y evitar reintentos rápidos indefinidos que hagan oscilar el equipo.

La suma de la corriente máxima de las ramas sanas y la corriente limitada de la rama en fallo debe quedar por debajo de la capacidad real disponible de fuente, con temperatura y margen de respuesta. Como presupuesto inicial se estudian 6 A a corriente constante y 30 W a potencia constante, que requieren hasta 6,113 A en el extremo R1 calculado. La coordinación utiliza la corriente máxima resultante, con tolerancias y transitorios. Se propone un techo de coordinación de 8 A a 5,20 V, equivalente a 41,6 W. Este techo es un requisito propuesto, no una capacidad térmica acreditada ni un juego final de calibres. Debe revisarse si la carga USB elegida exige más corriente.

La función contra sobretensión debe cortar o limitar antes de exceder la menor tensión admisible de los receptores, considerando tolerancia y sobreimpulso. En el presupuesto provisional el máximo de diseño es 5,25 V. El intervalo entre 5,20 V normales y 5,25 V es estrecho: si el protector no puede separar ambas condiciones con margen, se reduce la tensión normal y la resistencia de distribución, o se usan reguladores por rama. No basta escribir «OVP 5,25 V» sin circuito y tolerancias.

El mantenimiento no permite desconectar señales o retornos bajo carga. La Pi necesita además un apagado ordenado antes de retirar alimentación. Si se requiere sobrevivir a cortes imprevistos sin pérdida de datos, se diseña una reserva de energía y aviso de fallo de red calculados para ese apagado, o se reduce la dependencia de escrituras a la microSD; la retención de decenas de milisegundos de la fuente no equivale a un UPS. [R03, R04]

### Interfaz UART y masas

La conexión normal mantiene TX de Pi hacia RX del sensor y TX del sensor hacia RX de Pi. La versión tolerante a retorno abierto añade dos canales de aislamiento con direcciones opuestas, referencias locales y niveles lógicos de 3,3 V. No cruza un conductor GND por la barrera de señal. Cada salida debe permanecer en un estado admisible cuando cualquiera de las dos ramas esté apagada o subiendo. La habilitación permanece desactivada por defecto y sólo se permite con ambos dominios válidos y control preparado. Para la alternativa de buffer común, la condición funcional es OE = PG_PI AND PG_ZE AND UART_READY; el hardware debe imponerla aunque Linux falle. En una solución aislada, las señales de supervisión tampoco deben crear un puente galvánico que anule la barrera. Se elimina la consola serie de arranque y se comprueba el comportamiento de TX desde el encendido.

Debe comprobarse el mapa de continuidad con los cables finales conectados: negativo de fuente, GND de Pi, GND de ZE, GND de pantalla, blindajes USB y HDMI, RF y todas las piezas PE. Se registra cada unión esperada y su resistencia. Una unión GND a chasis no se interpreta automáticamente como defecto; una unión no prevista sí exige revisar corrientes de retorno, inmunidad y compatibilidad electromagnética.

## Plan de pruebas del circuito antes de cualificar los receptores

Este plan permite comprobar distribución y protecciones con cargas artificiales antes de conectar Pi, pantalla, Solo y sensor. Las pruebas de red y protección deben prepararlas personas competentes con instrumentos y procedimientos adecuados; no se propone inyectar fallos de 230 V manualmente. Los umbrales de continuidad PE y aislamiento deben fijarse según la clasificación y norma aplicables al equipo final.

### Etapa uno sin tensión

1. Fijar revisión de esquema y cotejar la lista de conexiones. Fotografiar etiquetas y bornes. Confirmar 1 AC/L, 2 AC/N, 3 FG, 4 −V y 5 +V en la fuente concreta.
2. Con C13 retirado y energía descargada, comprobar el módulo C14 separado del resto. Identificar contactos del interruptor, fusibles y lámpara; registrar continuidad ON y OFF de ambos polos.
3. Verificar PE directo a carcasa, fuente y elementos móviles. Comprobar que retirar el cajón no elimina PE de carcasa. El objetivo ≤0,1 Ω mencionado en la guía puede conservarse como objetivo interno, pero no se presenta como límite normativo universal.
4. Preparar el ensayo de continuidad de protección evitando que la corriente de prueba circule por blindajes de señales o placas. Una prueba de 10 a 25 A aplicada sin controlar caminos paralelos podría dañar la electrónica o dar una lectura engañosa.
5. Comprobar segregación, cubiertas, sujeción, holgura, polaridad, ausencia de conductor suelto y de contacto casual entre positivos, chasis y señales. Los ensayos de aislamiento se realizan con el procedimiento compatible con la fuente y la electrónica, sin aplicar una tensión de prueba improvisada a GPIO o USB.

### Etapa dos distribución de 5 V con cargas artificiales

Se sustituyen los cuatro receptores por cargas electrónicas o resistencias adecuadamente dimensionadas. Primero se alimenta la distribución desde una fuente de laboratorio con tensión y corriente limitadas, manteniendo separada la red del equipo. Se comprueban vacío, carga típica, 5 A, 5,5 A y dimensionado de 6 A, con sus cuatro contribuciones indicadas en la tabla de cargas. Se añade el ensayo a potencia constante de 30 W con cargas electrónicas; una resistencia fija no reproduce ese comportamiento.

| Prueba | Evidencia que se guarda | Aceptación de diseño |
|---|---|---|
| Polaridad y caída de cada rama | V e I en origen y extremo, recorrido y longitud | Polaridad correcta; resistencia total dentro del presupuesto |
| Carga simultánea | Tensiones de todas las ramas al mismo tiempo | Ventanas R1 cumplidas; sin calentamiento fuera del límite del material |
| Escalones de carga | Oscilogramas en fuente, Pi equivalente y ZE equivalente | No exceder ventanas en los estados normales definidos |
| Arranque con capacitancias representativas | Corriente pico, tiempo de subida y tensión mínima de las otras ramas | Arranque repetible, sin disparos ni colapso común |
| Sobrecarga de una rama | Corriente limitada, tiempo de corte, estado de otras ramas | Rama aislada y ramas sanas dentro de su ventana si ése es el requisito |
| Corto controlado por útil de ensayo | Forma de onda y energía, sin receptores conectados | Protección y cableado soportan el evento; no se atribuye sólo al fusible nominal |
| Sobretensión de entrada de distribución | Umbral y sobreimpulso a cargas artificiales | Ninguna salida supera el límite elegido para sus receptores |
| Apertura de positivo y retorno | Caminos y corriente por enlaces equivalentes de señal | Ningún enlace de señal se usa como retorno de potencia admisible |

Para comprobar el presupuesto de la Pi antes de conectarla, se añade al útil una resistencia representativa de F1 y del conector. Esa sustitución valida el cableado con la hipótesis elegida, no cualifica la F1 real. La comprobación final requiere repetir la medida en la placa.

Sólo después de aceptar la distribución y la parte de red se introduce la fuente del equipo. Se repiten las pruebas de ventana, carga ligera, arranque en frío/caliente y escalones con la LRS real. El ensayo de coordinación se hace con instrumentación que permita distinguir limitación de rama, disparo del troncal y hiccup de fuente.

### Etapa tres interfaces y secuencias de alimentación

| Estado | Qué se comprueba | Criterio |
|---|---|---|
| Pi y ZE encendidos | Niveles UART, referencia y tramas | Niveles compatibles y comunicación sin errores |
| Sólo Pi encendida | Tensión y corriente en pines del ZE apagado | Dentro de límites documentados; salida local inhibida con receptor inválido |
| Sólo ZE encendido | Tensión y corriente en GPIO de Pi apagada | Sin alimentación inversa fuera de límites |
| Rampa lenta y apagado de cada rama | Estados de interfaz y habilitación | Ninguna salida activa indebida ni estado flotante peligroso |
| Pantalla alimentada con Pi apagada y al revés | HDMI, 5 V auxiliar y retornos | Sin alimentación inversa no prevista; comportamiento definido |
| RF y blindajes conectados | Continuidad GND a chasis y rutas paralelas | Coinciden con el mapa aprobado |
| Puerto USB de carga | CC, identificación, corriente y tensión | Puerto conforme a la función anunciada; receptor reconoce carga |

La barrera elimina el camino conductor entre dominios, pero su salida local aún puede excitar RX durante una rampa del sensor. Cada salida debe quedar deshabilitada mientras su receptor no tenga alimentación válida. Se documentarán corrientes residuales, estados de rampa y tiempos; la supervisión del ZE se referencia a sus pines de alimentación al extremo del cable. Se miden tensión del pin respecto a GND local y corriente que entra en él, junto con alimentación y habilitación. Sin límites del fabricante o demostración de ausencia de excitación inadmisible, esta condición queda sin cualificar. No se acepta «parece apagado» como medición de ausencia de alimentación parásita.

### Etapa cuatro funcionamiento y caja cerrada

Con los receptores ya cualificados, se ejecutan arranque, cámara activa, pantalla a máximo brillo previsto, tráfico Wi-Fi, carga del Solo y muestreo del ZE simultáneos. Se guardan las tensiones mínimas y máximas, corrientes, temperaturas, versión de placa y firmware, mensajes de subtensión y estado de `vcgencmd get_throttled`. Sus bits históricos deben interpretarse; un valor aislado no reemplaza el registro eléctrico.

La prueba térmica se mantiene hasta estabilización bajo el ambiente más exigente declarado. Se mide aire junto al ZE, temperatura de fuente, conectores, protecciones y cableado, además de CPU. Debe mantenerse el ZE en 10 a 40 °C y cada elemento dentro de su rango. Si se pretende servicio por debajo de 10 °C o por encima de 40 °C alrededor del sensor, el circuito documentado requiere una solución térmica adicional o cambiar ese requisito. [R06]

Se repiten ciclos de extracción con el equipo sin energía para comprobar que los mazos no se tensan ni rozan. Por separado se prueba la recuperación tras fallo de una rama, reinicio, pérdida de Internet y pérdida de energía. La medición de alcohol y el pago se aceptan con pruebas funcionales y de calibración propias, posteriores a la aceptación eléctrica.

## Criterios para cerrar la auditoría

La revisión puede pasar de dictamen desfavorable a aprobación de diseño cuando exista una sola revisión de conexiones, se corrija la ficha de bornes, la carcasa conserve su PE durante el procedimiento previsto y estén definidos el interruptor y las protecciones. Deben cerrarse además el presupuesto de tensión y resistencia, el comportamiento de cada rama en fallo y la estrategia de masas y alimentación parcial.

La aprobación del montaje requiere después resultados físicos trazables: identificación del ejemplar, instrumentos, conexiones, temperatura ambiente, configuración, valores, formas de onda y criterio de aceptación. Una casilla PASS sin condiciones ni registro no permite reproducir el ensayo.

| Entregable pendiente para aceptación física | Responsable de validación por función |
|---|---|
| Esquema único y lista de conexiones final | Diseño eléctrico |
| Red, PE y coordinación de entrada | Responsable competente de seguridad eléctrica |
| Ventanas DC, protecciones y pruebas de fallo | Integración de alimentación |
| UART, USB, HDMI y secuencias | Integración electrónica |
| Temperatura y recorrido de mazos | Integración electromecánica |
| Ciclo de medición y pago | Control y aplicación |

Estas funciones no presuponen que exista un equipo de seis personas; indican qué competencia y evidencia debe cubrir quien cierre cada punto. Hasta entonces, el resultado defendible es: **hay una arquitectura corregible y una propuesta estáticamente viable; el montaje actual no está demostrado como funcional ni aprobado para energizar a partir de sus documentos contradictorios.**

## Reproducción y archivos de evidencia

Los cuatro modelos utilizan únicamente la biblioteca estándar de Python 3. No descargan archivos, no envían datos, no controlan hardware y no ejecutan pagos. Desde la carpeta de esta auditoría:

```bash
python3 modelos/model_dc.py --output-dir resultados
python3 modelos/model_topology.py --out resultados
python3 modelos/model_integration.py --out resultados
python3 modelos/model_r1_corner.py --out resultados
```

`dc_results.json` contiene hipótesis, fuentes, 548 escenarios normales, 23 de fallo, tensiones, corrientes, residuos y advertencias. Se incluye también como `dc_results.json.gz` para reducir tamaño; los comandos regeneran la versión JSON sin comprimir. Los CSV facilitan la revisión independiente; `dc_validation.json` registra los oráculos analíticos. `topology_results.json` conserva por separado el resultado de la comprobación y el veredicto del diseño. `netlist_graph.json` es una representación del grafo de cálculo, no un archivo de fabricación ni un esquema completo de R1.

La verificación DC compara un circuito CC con la ley de Ohm, un circuito CP con la raíz analítica de su ecuación cuadrática, un divisor de corriente en retornos y un caso CP sin solución positiva. En los 571 escenarios numéricos el residuo máximo de corriente nodal es 9,94 × 10⁻¹¹ A y el de balance de potencia 9,20 × 10⁻¹⁰ W. Estos residuos acreditan consistencia matemática; no miden precisión respecto a hardware cuya resistencia y carga aún se desconocen. [C01]

### Fuentes del cálculo

- **C01** `modelos/model_dc.py`, `resultados/dc_results.json`, `resultados/dc_scenarios.csv`, `resultados/dc_faults.csv`, `resultados/dc_resistance_budgets.csv` y `resultados/dc_validation.json`.
- **C02** `modelos/model_topology.py`, `resultados/topology_results.json`, `resultados/topology_results.csv` y `resultados/netlist_graph.json`.
- **C03** `modelos/model_integration.py` y `resultados/integration_results.json`.
- **C04** `inventario_fuentes.csv`, hashes del contenido auditado y cobertura del estudio previo.
- **C05** `modelos/model_r1_corner.py` y `resultados/r1_corner_validation.json`. Seis extremos de R1 y contraste independiente mediante raíces cuadráticas y bisección.

### Referencias documentales

- **R01** [MONTAJE-GENERAL del commit auditado](https://github.com/GuillermoAladro/Alcoholimetro/blob/84be97669a9efec43e79b3dadc4af5e87458c41a/MONTAJE-GENERAL.md). W1 a W29, comprobaciones previas y apartado 6.3. Fuente principal de topología y variantes.
- **R02** [Ficha Mean Well del commit auditado](https://github.com/GuillermoAladro/Alcoholimetro/blob/84be97669a9efec43e79b3dadc4af5e87458c41a/componentes/meanwell-lrs-50-5/README.md). Tabla de especificaciones, verificación de bornes y propuesta de montaje. Contiene la asignación errónea que se señala en A01.
- **R03** [Mean Well LRS-50-SPEC](https://www.meanwell.com/Upload/PDF/LRS-50/LRS-50-SPEC.PDF), revisión 2025-04-07. Página 2, tabla y notas 1 a 9; página 3, reducción de carga; página 4, asignación de bornes. Copia equivalente en `componentes/meanwell-lrs-50-5/datasheets/MEAN_WELL_LRS-50_DATA_SHEET.pdf`.
- **R04** [Raspberry Pi hardware documentation](https://www.raspberrypi.com/documentation/computers/raspberry-pi.html), apartados Power supply warnings y Back-powering. Consultado el 21-10-2026. Aviso de 4,63 V ±5 % y consecuencias de alimentación insuficiente.
- **R05** [Raspberry Pi config.txt documentation](https://www.raspberrypi.com/documentation/computers/config_txt.html), apartado Monitoring voltage. Consultado el 21-10-2026. Recomendación de tensión superior a 4,8 V y medida entre VCC y GND.
- **R06** [Winsen ZE29A-C2H5OH manual](https://www.winsen-sensor.com/d/files/manual/ze29a-c2h5oh.pdf), V1.1. Parámetros, pines, UART y notas de uso. Copia local en `componentes/winsen-ze29a/datasheets/ze29a-c2h5oh.pdf`.
- **R07** [Raspberry Pi 3B+ reduced schematics](https://pip-assets.raspberrypi.com/categories/532-raspberry-pi-3-model-b/documents/RP-008339-DS-1-raspberry-pi-3-b-plus-reduced-schematics.pdf), RP-008339-DS-1, página 1. J1, F1 y raíl de 5 V de J8. Copia local en la ficha de Pi.
- **R08** [USB Type-C specification library](https://www.usb.org/document-library/usb-type-cr-cable-and-connector-specification-release-25), Release 2.5, marzo de 2026; copia incluida en los ZIP de `componentes/documentos-compartidos/usb/`. Apartado 3.5, página PDF 85; tabla 3-13, página PDF 87, notas 1 y 5 para USB 2.0 A a C; tabla 3-12, página PDF 86, notas 2 y 6 para USB 3.1 A a C. Rp de 56 kΩ y uniones internas de blindaje.
- **R09** [USB Battery Charging 1.2 library](https://www.usb.org/document-library/battery-charging-v12-spec-and-adopters-agreement), documento consolidado con erratas de 2012 incluido en los ZIP del repositorio. Identificación DCP, resistencia de datos y límites de carga del dispositivo. No acredita por sí solo el comportamiento del Solo.
- **R10** [Schurter KD](https://www.schurter.com/en/datasheet/typ_KD.pdf). Familia de entrada C14, configuraciones de interruptor bipolar y portafusibles. Referencia candidata KD14.1101.151 a confirmar para el diseño final.
- **R11** [Schurter SPT](https://www.schurter.com/en/datasheet/typ_SPT_5x20.pdf). Curvas y datos de la familia de fusibles temporizados. La referencia concreta y sus condiciones deben coincidir con el material elegido.
- **R12** [Texas Instruments TXU0202](https://www.ti.com/lit/ds/symlink/txu0202.pdf). Funciones de traducción en dos direcciones fijas, Ioff y aislamiento por alimentación. Ejemplo de arquitectura, no componente ya cualificado en este circuito.
- **R13** [SumUp Cloud API](https://developer.sumup.com/terminal-payments/cloud-api/), apartados de consulta y terminación de checkout. Consultado el 21-10-2026. La terminación es asíncrona y no confirma por sí misma el resultado de pago.
- **R14** [LAPP tabla T11](https://t3.lappcdn.com/fileadmin/DAM/Miltronic_Denmark/4_servicecenter/T11.pdf). Resistencias de conductores de cobre flexibles. Copia local en la ficha `cable-2x0-75-rojo-negro-10m`.

Las referencias de fabricante sustentan límites o funciones identificadas. Las magnitudes calculadas y las propuestas son trabajo de esta auditoría. Las fichas de productos comparables y los anuncios genéricos no se han utilizado como certificados del componente exacto comprado.
