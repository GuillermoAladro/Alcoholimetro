#!/usr/bin/env python3
"""Convierte el informe Markdown a DOCX. Requiere python-docx y pandoc.

El PDF se exporta desde el DOCX con LibreOffice o Word; revisar su paginación.
No modifica ni ejecuta los modelos eléctricos.
"""
import argparse
import subprocess
import tempfile
from pathlib import Path
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT

BLUE='163F5A'; BLACK='111111'; GRAY='68727C'; LIGHT='F2F5F7'

def cell_shading(cell, fill):
    tcPr=cell._tc.get_or_add_tcPr()
    shd=OxmlElement('w:shd');shd.set(qn('w:fill'),fill);tcPr.append(shd)

def field(paragraph,instruction):
    run=paragraph.add_run();f=OxmlElement('w:fldSimple');f.set(qn('w:instr'),instruction)
    run._r.addnext(f)

def style_document(doc):
    sec=doc.sections[0]
    sec.page_width=Inches(8.5);sec.page_height=Inches(11)
    sec.top_margin=Inches(.72);sec.bottom_margin=Inches(.72)
    sec.left_margin=Inches(.75);sec.right_margin=Inches(.75)
    sec.header_distance=Inches(.28);sec.footer_distance=Inches(.30)
    normal=doc.styles['Normal'];normal.font.name='Calibri';normal.font.size=Pt(11)
    normal.font.color.rgb=RGBColor.from_string(BLACK)
    normal.paragraph_format.line_spacing=1.05
    normal.paragraph_format.space_after=Pt(5)
    normal.paragraph_format.widow_control=True
    for name,size in [('Title',25),('Heading 1',23),('Heading 2',17),('Heading 3',13)]:
        st=doc.styles[name];st.font.name='Calibri';st.font.size=Pt(size);st.font.bold=True
        st.font.color.rgb=RGBColor.from_string('000000')
        st.paragraph_format.keep_with_next=True
        st.paragraph_format.space_before=Pt(14 if name not in ('Title','Heading 1') else 4)
        st.paragraph_format.space_after=Pt(7)
    for name in ['Body Text','First Paragraph','Compact']:
        if name in doc.styles:
            st=doc.styles[name];st.font.name='Calibri';st.font.size=Pt(11)
            st.paragraph_format.line_spacing=1.05;st.paragraph_format.space_after=Pt(5)
    for name in ['Source Code','Verbatim Char']:
        if name in doc.styles:
            doc.styles[name].font.name='Consolas';doc.styles[name].font.size=Pt(9)
    if 'Caption' in doc.styles:
        doc.styles['Caption'].font.size=Pt(9.5)
        doc.styles['Caption'].font.color.rgb=RGBColor.from_string(GRAY)

def generate(source,output):
    source=source.resolve();output=output.resolve()
    output.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='auditor6_doc_') as temp:
        reference=Path(temp)/'reference.docx'
        doc=Document();style_document(doc);doc.save(reference)
        subprocess.run(['pandoc',str(source),'--from=markdown+pipe_tables+tex_math_dollars-implicit_figures','--to=docx',
                        '--standalone','--reference-doc='+str(reference),'--resource-path='+str(source.parent),
                        '--output='+str(output)],check=True)
    doc=Document(output);style_document(doc)
    doc.core_properties.author='Auditor 6'
    doc.core_properties.last_modified_by='Auditor 6'
    doc.core_properties.title='Auditoría eléctrica del alcoholímetro'
    doc.core_properties.subject='Revisión documental y modelos eléctricos del commit 84be976'
    doc.core_properties.keywords='Auditor 6; Alcoholimetro; auditoría eléctrica; R1'
    doc.core_properties.comments='Sin ensayos físicos. Hipótesis y criterios en el informe.'
    doc.core_properties.language='es-ES'
    first=True
    page_starts={'Hallazgos y correcciones','Resultados eléctricos cuantitativos','Propuesta eléctrica R1',
                 'Reproducción y archivos de evidencia'}
    for p in doc.paragraphs:
        if first and p.text.strip():
            p.style=doc.styles['Title'];first=False
        if p.text in page_starts:p.paragraph_format.page_break_before=True
        if p._p.xpath('.//w:drawing'):
            p.paragraph_format.keep_with_next=True;p.alignment=WD_ALIGN_PARAGRAPH.CENTER
        if p.text.startswith('Figura '):
            p.style=doc.styles['Caption'];p.paragraph_format.keep_with_next=False
        if p.text.startswith(('R01','R02','R03','R04','R05','R06','R07','R08','R09','R10','R11','R12','R13','R14')):
            p.style=doc.styles['Normal']
            for num in list(p._p.xpath('./w:pPr/w:numPr')):
                num.getparent().remove(num)
            p.paragraph_format.keep_together=True
            for run in p.runs:run.font.size=Pt(9.5)
    for shape in doc.inline_shapes:
        ratio=shape.height/shape.width
        shape.width=Inches(6.65);shape.height=int(shape.width*ratio)
    for ti,table in enumerate(doc.tables):
        table.style='Table Grid'
        table.alignment=WD_TABLE_ALIGNMENT.CENTER;table.autofit=False
        n=len(table.columns)
        if n==2:widths=[1.72,5.28]
        elif n==3:widths=[1.58,2.86,2.56]
        elif n==6:widths=[2.30,.94,.94,.94,.94,.94]
        else:widths=[7/n]*n
        if n==3 and table.cell(0,0).text=='Cable':widths=[.55,3.35,3.10]
        if n==3 and table.cell(0,0).text=='Aspecto':widths=[1.3,2.85,2.85]
        tblPr=table._tbl.tblPr
        old=tblPr.find(qn('w:tblBorders'))
        if old is not None:tblPr.remove(old)
        borders=OxmlElement('w:tblBorders')
        for side in ('top','left','bottom','right','insideH','insideV'):
            e=OxmlElement('w:'+side);e.set(qn('w:val'),'single');e.set(qn('w:sz'),'4');e.set(qn('w:color'),'D9D9D9');borders.append(e)
        tblPr.append(borders)
        margins=OxmlElement('w:tblCellMar')
        for name,value in [('top',80),('bottom',80),('left',85),('right',85)]:
            e=OxmlElement('w:'+name);e.set(qn('w:w'),str(value));e.set(qn('w:type'),'dxa');margins.append(e)
        tblPr.append(margins)
        for idx,width in enumerate(widths):table.columns[idx].width=Inches(width)
        for ri,row in enumerate(table.rows):
            trPr=row._tr.get_or_add_trPr();cant=OxmlElement('w:cantSplit');trPr.append(cant)
            if ri==0:
                repeat=OxmlElement('w:tblHeader');trPr.append(repeat)
            for ci,cell in enumerate(row.cells):
                cell.width=Inches(widths[ci]);cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
                if ri==0:cell_shading(cell,BLUE)
                elif ri%2==0:cell_shading(cell,LIGHT)
                for p in cell.paragraphs:
                    p.style=doc.styles['Normal']
                    p.paragraph_format.space_after=Pt(2);p.paragraph_format.space_before=Pt(2)
                    p.paragraph_format.line_spacing=1.02;p.paragraph_format.keep_with_next=False
                    for run in p.runs:
                        run.font.name='Calibri';run.font.size=Pt(9.5)
                        if ri==0:run.font.bold=True;run.font.color.rgb=RGBColor(255,255,255)
        # La cabecera permanece junto a la primera fila.
        for cell in table.rows[0].cells:
            for p in cell.paragraphs:p.paragraph_format.keep_with_next=True
    sec=doc.sections[0]
    header=sec.header.paragraphs[0];header.text='AUDITOR 6  |  ALCOHOLÍMETRO  |  REVISIÓN ELÉCTRICA'
    for run in header.runs:run.font.size=Pt(8);run.font.color.rgb=RGBColor.from_string(GRAY)
    footer=sec.footer.paragraphs[0];footer.alignment=WD_ALIGN_PARAGRAPH.RIGHT
    run=footer.add_run('21 octubre 2026  ·  Auditor 6  ·  ');run.font.size=Pt(8)
    field(footer,'PAGE');footer.add_run(' / ');field(footer,'NUMPAGES')
    for st in doc.styles:
        for border in list(st.element.xpath('.//w:pBdr')):
            border.getparent().remove(border)
    for p in doc.paragraphs:
        for border in list(p._p.xpath('./w:pPr/w:pBdr')):
            border.getparent().remove(border)
    doc.save(output)
    print(str(output))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();generate(args.source,args.output)
