#!/usr/bin/env python3
"""Genera figuras exactas de la auditoría. Dependencia opcional: matplotlib."""
import argparse
import importlib.util
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle

BLUE='#164B74'; RED='#A23F3F'; GREEN='#317152'; GRAY='#596470'; LIGHT='#F4F6F8'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'svg.fonttype':'none'})

def box(ax,x,y,w,h,label,color=BLUE,fc='white',size=11):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.04,rounding_size=0.06',ec=color,fc=fc,lw=1.4))
    ax.text(x+w/2,y+h/2,label,ha='center',va='center',fontsize=size,color='#17212C',linespacing=1.35)

def wire(ax,coords,color=BLUE,dashed=False,arrow=False):
    xs,ys=zip(*coords)
    ax.plot(xs,ys,color=color,lw=1.6,ls='--' if dashed else '-',zorder=1)
    if arrow:
        ax.annotate('',xy=coords[-1],xytext=coords[-2],arrowprops=dict(arrowstyle='-|>',color=color,lw=1.4))

def canvas(title,subtitle):
    fig,ax=plt.subplots(figsize=(11.4,7.8))
    ax.set(xlim=(0,12),ylim=(0,8));ax.axis('off')
    ax.text(.15,7.72,title,ha='left',va='top',fontsize=18,weight='bold')
    ax.text(.15,7.28,subtitle,ha='left',va='top',fontsize=10,color=GRAY)
    return fig,ax

def save(fig,out,name):
    fig.savefig(out/(name+'.png'),dpi=190,bbox_inches='tight',facecolor='white')
    fig.savefig(out/(name+'.svg'),bbox_inches='tight',facecolor='white')
    plt.close(fig)

def base(out):
    f,a=canvas('Circuito reconstruido','Auditor 6 · Esquema funcional de interfaces · Base y cambio A identificados')
    box(a,.2,5.9,2.1,.9,'C14\n230 V + PE')
    box(a,3.0,5.9,3.0,.9,'Fusible e interruptor\nSPST o DPST sin cerrar')
    box(a,7.2,5.75,4.3,1.2,'LRS-50-5\n1 L · 2 N · 3 FG · 4 −V · 5 +V')
    wire(a,[(2.3,6.35),(3.,6.35)],RED,arrow=True)
    wire(a,[(6,6.35),(7.2,6.35)],RED,arrow=True)
    wire(a,[(1.25,5.9),(1.25,5.2),(6.4,5.2),(6.4,5.95),(7.2,5.95)],GREEN)
    a.text(2.1,5.28,'PE a metales y FG',color=GREEN,fontsize=10)
    box(a,7.25,4.3,4.25,.7,'W11 y W12 → WAGO + / GND',fc=LIGHT)
    wire(a,[(9.35,5.75),(9.35,5.0)],BLUE,arrow=True)
    centers=[1.45,4.4,7.35,10.3]
    wire(a,[(1.45,3.85),(10.3,3.85)],BLUE)
    wire(a,[(9.35,4.3),(9.35,3.85)],BLUE)
    a.text(.2,4.3,'Base sin fusibles de rama. Positivo y retorno por carga.\nA: Pi 3 A · ZE 2 A · pantalla 3 A · Solo 3 A.',fontsize=10,color=GRAY)
    labels=['Raspberry Pi\nW13 · micro-USB','ZE29A\nW18 · pines 1 y 2','Pantalla HDMI\nW16–W17 · USB','SumUp Solo\nW14–W15 · USB']
    for x,label in zip(centers,labels):
        wire(a,[(x,3.85),(x,3.3)],BLUE,arrow=True)
        box(a,x-1.1,2.45,2.2,.85,label,size=10.5)
    wire(a,[(2.55,2.8),(3.3,2.8)],GRAY)
    a.text(2.92,3.03,'UART',fontsize=9,ha='center')
    wire(a,[(1.45,2.45),(1.45,1.95),(7.35,1.95),(7.35,2.45)],GRAY)
    a.text(4.5,2.06,'W23 · HDMI y referencia de masa',ha='center',fontsize=10,color=GRAY)
    box(a,.35,.6,2.2,.8,'Cámara + AR9271\nAlimentados por Pi',fc=LIGHT,size=10)
    wire(a,[(1.45,1.95),(1.45,1.4)],GRAY,arrow=True)
    box(a,4.1,.6,3.25,.8,'RF → pasamuros → chasis\nGND interno por confirmar',fc=LIGHT,size=10)
    wire(a,[(2.55,1),(4.1,1)],GREEN,dashed=True)
    a.text(8,.98,'A mueve C14 y fuente al cajón.\nSu puente PE pasa a ser crítico.',fontsize=10,color=RED,va='center')
    a.text(.2,.12,'Trazo discontinuo: unión condicionada al hardware. No es un plano de fabricación.',fontsize=9,color=GRAY)
    save(f,out,'topologia-base')

def corrected(out):
    f,a=canvas('Propuesta eléctrica R1','Auditor 6 · Objetivos a realizar y medir · Protecciones e interfaces pendientes de cualificación')
    a.add_patch(Rectangle((.15,5.3),11.4,1.65,fc=LIGHT,ec='#BCC5CE',lw=1))
    a.text(.3,6.8,'COMPARTIMENTO FIJO DE RED',fontsize=10,color=GRAY)
    box(a,.4,5.55,3.2,.9,'C14 · DPST · dos fusibles\nOrden según módulo real',size=10.5)
    box(a,4.2,5.55,3.1,.9,'Fuente 5 V\nFG a PE permanente')
    box(a,8.0,5.55,3.2,.9,'P0 y función OVP\nIncluidas en presupuesto R',size=10.5)
    wire(a,[(3.6,6),(4.2,6)],RED,arrow=True)
    wire(a,[(7.3,6),(8.,6)],BLUE,arrow=True)
    wire(a,[(1.,5.55),(1.,4.85),(6.,4.85)],GREEN)
    a.text(1.1,4.95,'PE → carcasa y FG; enlace propio al cajón',fontsize=10,color=GREEN)
    wire(a,[(9.6,5.55),(9.6,4.2),(1.4,4.2)],BLUE)
    wire(a,[(9.6,4.2),(10.4,4.2)],BLUE)
    wire(a,[(5.75,4.85),(5.75,5.55)],GREEN)
    a.text(6.7,4.48,'5,10–5,20 V efectivos',fontsize=10,color=BLUE)
    a.text(.3,4.48,'Troncal y retorno ≤9,4 mΩ',fontsize=10,color=BLUE)
    centers=[1.4,4.4,7.4,10.4]
    protect=['P1 · Pi','P4 · ZE','P3 · Pantalla','P2 · Solo']
    loads=['Pi + cámara + radio','ZE29A','Pantalla','Solo']
    for x,p,l in zip(centers,protect,loads):
        wire(a,[(x,4.2),(x,3.7)],BLUE,arrow=True)
        box(a,x-1.1,3.0,2.2,.7,p,fc=LIGHT)
        wire(a,[(x,3),(x,2.55)],BLUE,arrow=True)
        box(a,x-1.1,1.85,2.2,.7,l,size=10.5)
    wire(a,[(1.4,1.85),(1.4,1.1),(2.05,1.1)],GRAY)
    box(a,2.05,.68,1.7,.85,'UART\n2 canales aislados',size=9.5)
    wire(a,[(3.75,1.1),(4.4,1.1),(4.4,1.85)],GRAY)
    a.text(6.1,1.1,'Retornos de potencia continuos.\nHDMI y RF incluidos en mapa de masas.\nServicio con C13 retirado.',fontsize=10,color=GRAY,va='center')
    a.text(.2,.12,'P1–P4: limitación y corte en positivo. El diagrama no define aún un circuito de protección fabricable.',fontsize=9,color=GRAY)
    save(f,out,'topologia-r1')

def voltage(out,model_path):
    spec=importlib.util.spec_from_file_location('audit_dc',model_path)
    m=importlib.util.module_from_spec(spec)
    import sys
    sys.modules[spec.name]=m;spec.loader.exec_module(m)
    f,a=plt.subplots(figsize=(10.9,5.6))
    voltages=[5+i*.005 for i in range(41)]
    rows=[('Base · 5 A',dict(),BLUE),('A · 5 A',dict(external_fuse_ohm=.02,revision='A_conditional'),RED),
          ('A · 6 A',dict(external_fuse_ohm=.02,revision='A_conditional',load_case='sizing_pi_2_5A'),'#947142')]
    for name,kw,color in rows:
        y=[m.analyse(m.Config(setpoint_v=v,**kw),'plot')['branches']['pi']['voltage_v'] for v in voltages]
        a.plot(voltages,y,label=name,color=color,lw=2.2)
    vs=[v for v in voltages if v>=5.1]
    y=[m.analyse(m.Config(setpoint_v=v,contact_profile='target',trunk_length_m=.20,trunk_area_mm2=1.5,
          screen_cable_length_m=.30,screen_awg=22,external_fuse_ohm=.01,revision='R1_target',load_case='sizing_pi_2_5A'),'plot')['branches']['pi']['voltage_v'] for v in vs]
    a.plot(vs,y,label='R1 · 6 A · resistencias objetivo',color=GREEN,lw=2.8)
    a.axhspan(4.4,4.8,color='#F8EDEE',alpha=1)
    a.axhline(4.8,color='#5B6470',ls='--',lw=1.2)
    a.text(5.003,4.81,'Criterio de fiabilidad: más de 4,8 V',fontsize=10,color=GRAY)
    a.set(xlim=(4.998,5.202),ylim=(4.43,5.1),xlabel='Tensión efectiva de fuente en el modelo (V)',ylabel='Tensión calculada tras F1 de Raspberry Pi (V)')
    a.set_title('Caída de tensión en la rama Pi',loc='left',fontsize=17,weight='bold',pad=15)
    a.legend(loc='lower right',frameon=False,fontsize=10)
    a.grid(alpha=.2);a.spines[['right','top']].set_visible(False)
    f.text(.125,.015,'Auditor 6 · Cargas de corriente constante · 20 °C · Resistencias supuestas, no mediciones',fontsize=9,color=GRAY)
    f.subplots_adjust(bottom=.15)
    save(f,out,'tension-pi')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output-dir',type=Path,required=True);p.add_argument('--model',type=Path,required=True)
    args=p.parse_args();args.output_dir.mkdir(parents=True,exist_ok=True)
    base(args.output_dir);corrected(args.output_dir);voltage(args.output_dir,args.model)
