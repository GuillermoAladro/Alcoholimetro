#!/usr/bin/env python3
"""Comprobación separada de máximos R1: no modifica la matriz de model_dc.

Uso: python3 model_r1_corner.py --out resultados
Mantener model_dc.py en la misma carpeta. Sólo biblioteca estándar de Python.
Son límites de requisito del recorrido completo en caliente, no R medidas.
La fuente se evalúa en los límites EFECTIVOS 5,10/5,20 V tras su habilitación;
no se añade deriva de consigna sobre esos límites ni se modelan rampas.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path

import model_dc
from model_dc import Load, Resistor, solve_network

R_TRUNK_MAX = .0094
R_BRANCH_MAX = {"pi": .055, "solo": .087, "screen": .087, "ze": .040}
I_BUDGET = {"pi": 2.5, "solo": 2.0, "screen": 1.0, "ze": .5}
P_BUDGET = {branch: 5.0*current for branch, current in I_BUDGET.items()}
SOURCE_BOUNDS = (5.10, 5.20)


def build_resistors() -> list[Resistor]:
    # Repartir el lazo entre + y - por igual conserva tensiones diferenciales,
    # corrientes y pérdidas en esta estrella sin enlaces de retorno adicionales.
    # No representa dónde están realmente F1/P0 ni predice offsets de masa.
    parts = [Resistor("trunk_positive_equivalent", "source_plus", "bus_plus", R_TRUNK_MAX/2, "trunk"),
             Resistor("trunk_return_equivalent", "bus_minus", "source_minus", R_TRUNK_MAX/2, "trunk")]
    for branch, resistance in R_BRANCH_MAX.items():
        parts.extend([
            Resistor(branch+"_positive_equivalent", "bus_plus", branch+"_plus", resistance/2, "branch"),
            Resistor(branch+"_return_equivalent", branch+"_minus", "bus_minus", resistance/2, "branch"),
        ])
    return parts


def cp_analytic_star(source_v: float) -> dict:
    """Oráculo CP independiente: raíces cuadráticas por rama + bisección de barra.

    Vj=(Vbus+sqrt(Vbus^2-4RjPj))/2; Vbus=E-Rtrunk*sum(Pj/Vj).
    El intervalo se limita a la rama alta cercana a operación normal.
    """
    lo, hi = source_v/2, source_v

    def at(bus_v):
        volts = {}
        for branch, power in P_BUDGET.items():
            discriminant = bus_v*bus_v-4*R_BRANCH_MAX[branch]*power
            if discriminant <= 0:
                raise ValueError("El intervalo no contiene raíces altas reales de todas las ramas.")
            volts[branch] = (bus_v+math.sqrt(discriminant))/2
        total = sum(P_BUDGET[branch]/v for branch, v in volts.items())
        return source_v-R_TRUNK_MAX*total-bus_v, volts, total

    assert at(lo)[0] > 0 and at(hi)[0] < 0
    for _ in range(100):
        middle = (lo+hi)/2
        if at(middle)[0] > 0:
            lo = middle
        else:
            hi = middle
    _, volts, total = at((lo+hi)/2)
    return {"bus_v": (lo+hi)/2, "branch_v": volts, "source_current_a": total}


def run_case(source_v: float, mode: str) -> dict:
    load_mode = "CP" if mode == "CP" else "CC"
    values = P_BUDGET if mode == "CP" else I_BUDGET if mode == "CC" else {key: 0.0 for key in I_BUDGET}
    loads = [Load(branch, branch+"_plus", branch+"_minus", load_mode, value) for branch, value in values.items()]
    solution = solve_network(build_resistors(), loads, {"source_plus": source_v, "source_minus": 0.0})
    branches = solution["loads"]
    current = solution["fixed_node_current_out_a"]["source_plus"]
    pi_v = branches["pi"]["voltage_v"]
    criteria = {
        "effective_source_within_5_10_to_5_20V": 5.10 <= source_v <= 5.20,
        "pi_rail_at_least_4_90V_design_objective": pi_v >= 4.90,
        "pi_rail_above_4_80V_reliability_criterion": pi_v > 4.80,
        "pi_above_upper_warning_threshold_4_8615V": pi_v > 4.63*1.05,
        "pi_below_provisional_5_25V_design_ceiling": pi_v <= 5.25,
        "solo_within_provisional_4_75_to_5_25V": 4.75 <= branches["solo"]["voltage_v"] <= 5.25,
        "screen_within_provisional_4_75_to_5_25V": 4.75 <= branches["screen"]["voltage_v"] <= 5.25,
        "ze_within_vendor_4_70_to_5_30V": 4.70 <= branches["ze"]["voltage_v"] <= 5.30,
        "source_current_within_nominal_10A": current <= 10,
        "source_power_within_nominal_50W": solution["source_power_w"] <= 50,
        "KCL_residual_below_1e_minus_8A": solution["max_kcl_residual_a"] < 1e-8,
        "power_balance_residual_below_1e_minus_8W": abs(solution["power_residual_w"]) < 1e-8,
    }
    if mode == "CP":
        oracle = cp_analytic_star(source_v)
        expected = oracle["branch_v"]
        oracle_name = "per_branch_quadratic_high_root_and_bus_bisection"
        criteria["CP_30W_conserved"] = math.isclose(solution["load_power_w"], 30.0, abs_tol=1e-10)
    else:
        total = 6.0 if mode == "CC" else 0.0
        expected = {branch: source_v-R_TRUNK_MAX*total-R_BRANCH_MAX[branch]*values[branch] for branch in I_BUDGET}
        oracle_name = "Ohm_CC_or_unloaded_zero_drop"
    error = max(abs(branches[branch]["voltage_v"]-expected[branch]) for branch in I_BUDGET)
    criteria["independent_analytic_voltage_error_below_1e_minus_9V"] = error < 1e-9
    assert all(criteria.values()), (source_v, mode, criteria)
    return {
        "id": f"R1_max_R_{source_v:.2f}V_{mode}", "source_effective_v": source_v,
        "load_model": mode, "source_current_a": current,
        "source_power_w": solution["source_power_w"], "load_power_w": solution["load_power_w"],
        "loss_w": solution["resistor_loss_w"], "branches": branches,
        "pi_margin_above_4_90V_v": pi_v-4.90,
        "pi_margin_above_4_80V_v": pi_v-4.80,
        "pi_current_above_2_5A_requires_F1_thermal_review": branches["pi"]["current_a"] > 2.5,
        "criteria": criteria, "all_numeric_criteria_pass": all(criteria.values()),
        "verification": {"analytic_method": oracle_name, "analytic_branch_v": expected,
                         "max_analytic_voltage_error_v": error,
                         "max_kcl_residual_a": solution["max_kcl_residual_a"],
                         "power_residual_w": solution["power_residual_w"]},
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    cases = [run_case(source_v, mode) for source_v in SOURCE_BOUNDS for mode in ("CC", "CP", "unloaded")]
    output = {
        "study": "R1 maximum-resistance corner, separate from the 548-scenario matrix",
        "snapshot_commit": model_dc.COMMIT,
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "model_dc_sha256": hashlib.sha256(Path(model_dc.__file__).read_bytes()).hexdigest(),
        "requirements": {"effective_source_v": SOURCE_BOUNDS, "maximum_trunk_loop_ohm": R_TRUNK_MAX,
                         "maximum_branch_loop_ohm": R_BRANCH_MAX, "CC_budget_a": I_BUDGET,
                         "CP_budget_w": P_BUDGET},
        "assumptions": [
            "All R values are proposed maximum complete-loop requirements at operating temperature, not properties measured or granted to any purchased part.",
            "Trunk R includes both conductors, all common contacts and any P0 protection; Pi R includes cable, contacts, external protection and F1.",
            "Equal splitting of each loop between positive and return is only an equivalent for differential DC voltages in a star without alternate returns; it is not a ground-offset or physical pin model.",
            "5.10/5.20 V are effective source boundaries after power is established and loads enabled. They are not trimmer settings; no +/-2.25% envelope is added to these boundaries.",
            "CP loads hold powers specified at 5 V; actual IC, battery, USB negotiation, UVLO, PTC dynamics, source transient behaviour and thermal limits are not modelled.",
            "Solo/screen 4.75-5.25 V and Pi 5.25 V ceiling are provisional design criteria, not verified absolute maximum ratings of the exact products.",
            "All_numeric_criteria_pass means only the listed mathematical checks. It does not approve thermal operation, fuse coordination, fault tolerance, hardware compliance or construction.",
            "The 2.30 mV margin above the 4.90 V design objective is small: measurement uncertainty and parameter tolerances must already be contained within the effective-V and maximum-R requirements.",
        ],
        "criteria_sources": {
            "pi_4_8V_reliability": "https://www.raspberrypi.com/documentation/computers/config_txt.html#monitoring-voltage",
            "pi_warning_threshold": "https://www.raspberrypi.com/documentation/computers/raspberry-pi.html#power-supply-warnings",
            "ze_range": "https://www.winsen-sensor.com/d/files/manual/ze29a-c2h5oh.pdf",
            "source_nominal_rating": "https://www.meanwell.com/Upload/PDF/LRS-50/LRS-50-SPEC.PDF",
        },
        "case_count": len(cases), "cases": cases,
        "all_listed_numeric_criteria_pass": all(case["all_numeric_criteria_pass"] for case in cases),
        "minimum_pi_v": min(case["branches"]["pi"]["voltage_v"] for case in cases),
        "maximum_source_current_a": max(case["source_current_a"] for case in cases),
        "base_model_scenario_matrix_modified": False,
    }
    args.out.mkdir(parents=True, exist_ok=True)
    path = args.out/"r1_corner_validation.json"
    path.write_text(json.dumps(output, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    print(json.dumps({"case_count": len(cases), "all_listed_numeric_criteria_pass": output["all_listed_numeric_criteria_pass"],
                      "minimum_pi_v": output["minimum_pi_v"], "maximum_source_current_a": output["maximum_source_current_a"],
                      "cases": [{"id": case["id"], "branch_v": {k: v["voltage_v"] for k, v in case["branches"].items()}, "loss_w": case["loss_w"]} for case in cases]}, indent=2))


if __name__ == "__main__":
    main()
