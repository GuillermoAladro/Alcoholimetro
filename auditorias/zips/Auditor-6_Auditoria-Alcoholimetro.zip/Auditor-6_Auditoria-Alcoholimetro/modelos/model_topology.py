#!/usr/bin/env python3
"""Auditoría de conectividad, sin energizar hardware y sin modelo SPICE.

Modelo de conductores ideales. No calcula impedancia de red, tiempos de
despeje, rigidez dieléctrica, fugas, distancias de aislamiento ni EMC.
Los escenarios que necesitan una unión interna RF/GND se marcan condicionales.
Un self-check correcto significa que el cálculo detecta el resultado esperado;
no significa que el circuito auditado sea apto.
"""
from __future__ import annotations
import argparse
import csv
import json
from collections import deque
from dataclasses import asdict, dataclass
from pathlib import Path

SNAPSHOT = "84be97669a9efec43e79b3dadc4af5e87458c41a"

@dataclass(frozen=True)
class Edge:
    a: str
    b: str
    ref: str
    kind: str = "wire"

def path(edges, source, target, exclude=()):
    adjacency = {}
    for e in edges:
        if e.ref in exclude:
            continue
        adjacency.setdefault(e.a, []).append((e.b, e.ref))
        adjacency.setdefault(e.b, []).append((e.a, e.ref))
    queue = deque([(source, [])])
    seen = {source}
    while queue:
        node, refs = queue.popleft()
        if node == target:
            return refs
        for other, ref in adjacency.get(node, []):
            if other not in seen:
                seen.add(other)
                queue.append((other, refs + [ref]))
    return None

def mains(poles=2, switch_on=True, reversed_plug=False, two_fuses=False):
    # A y B son polos físicos del C14, no promesas de fase/neutro.
    e = [Edge("LINE", "C14.B" if reversed_plug else "C14.A", "W1.phase"),
         Edge("NEUTRAL", "C14.A" if reversed_plug else "C14.B", "W1.neutral"),
         Edge("C14.A", "SW.A", "F_AC_A", "fuse"),
         Edge("C14.B", "SW.C", "F_AC_B" if two_fuses else "W3", "fuse" if two_fuses else "wire"),
         Edge("SW.B", "PSU.1.L", "W4"),
         Edge("SW.D", "PSU.2.N", "W5")]
    if switch_on:
        e.append(Edge("SW.A", "SW.B", "SW_AB", "switch"))
    if poles == 1 or switch_on:
        e.append(Edge("SW.C", "SW.D", "BYPASS_N" if poles == 1 else "SW_CD", "wire" if poles == 1 else "switch"))
    return e

def protective_earth(variant="base", drawer_bridge=True):
    # Los metales unidos por soldadura se agrupan; se debe medir su continuidad.
    e = []
    if variant == "A":
        e += [Edge("PE_IN", "DRAWER", "W6.A", "PE"), Edge("DRAWER", "PSU.FG", "W7.A", "PE")]
        if drawer_bridge:
            e.append(Edge("DRAWER", "CHASSIS", "PE_FASTON_A", "PE"))
        e.append(Edge("CHASSIS", "FRONT", "W8", "PE"))
    else:
        e += [Edge("PE_IN", "CHASSIS", "W6", "PE"),
              Edge("CHASSIS", "PSU.FG", "W7", "PE"),
              Edge("CHASSIS", "FRONT", "W8", "PE")]
        if variant == "base":
            e.append(Edge("CHASSIS", "INNER_BOX", "W9", "PE"))
        if drawer_bridge:
            e.append(Edge("CHASSIS", "DRAWER", "W10", "PE"))
    return e

def dc(rf_bond=False, hdmi_ground=True, uart_direct=True, returns_open=()):
    e = [Edge("PSU.5.PLUS", "STAR.PLUS", "W11"), Edge("PSU.4.MINUS", "STAR.GND", "W12")]
    for device, ref in (("PI", "W13"), ("SOLO", "W14-W15"), ("SCREEN", "W16-W17"), ("ZE", "W18")):
        e.append(Edge("STAR.PLUS", device + ".VIN", ref + ".plus"))
        if device not in returns_open:
            e.append(Edge("STAR.GND", device + ".GND", ref + ".return"))
    e += [Edge("PI.TX", "ZE.RX", "W19") if uart_direct else Edge("PI.TX", "ISO.A.IN", "W19.R1A"),
          Edge("ZE.TX", "PI.RX", "W20") if uart_direct else Edge("ISO.A.OUT", "PI.RX", "W20.R1A"),
          Edge("PI.GND", "AR9271.USB_GND", "W25.GND")]
    if hdmi_ground:
        e.append(Edge("PI.GND", "SCREEN.GND", "W23.HDMI_GND"))
    if rf_bond:
        e += [Edge("AR9271.USB_GND", "AR9271.RF_SHIELD", "INTERNAL_RF_GND_CONDITIONAL"),
              Edge("AR9271.RF_SHIELD", "CHASSIS", "W26.SHIELD")]
    e += [Edge("USB1.DPLUS", "USB1.DMINUS", "DCP1"), Edge("USB2.DPLUS", "USB2.DMINUS", "DCP2")]
    return e

def run(output_dir: Path):
    output_dir.mkdir(parents=True, exist_ok=True)
    results = []
    def record(test_id, scenario, criterion, observed, expected, verdict, evidence=None, conditional=False):
        if observed != expected:
            raise AssertionError(f"{test_id}: {observed!r} != {expected!r}")
        results.append(dict(id=test_id, scenario=scenario, criterion=criterion, observed=observed,
                            design_verdict=verdict, conditional=conditional, path=evidence,
                            self_check="PASS"))
    for reversed_plug in (False, True):
        e = mains(poles=1, switch_on=False, reversed_plug=reversed_plug)
        live = [n for n in ("PSU.1.L", "PSU.2.N") if path(e, "LINE", n) is not None]
        record("T01R" if reversed_plug else "T01N", "SPST OFF, Schuko " + ("invertido" if reversed_plug else "normal"),
               "Ningún borne AC de la fuente conectado directamente a fase", live,
               ["PSU.2.N"] if reversed_plug else [], "FAIL" if reversed_plug else "PASS_IN_THIS_ORIENTATION")
        e = mains(poles=2, switch_on=False, reversed_plug=reversed_plug)
        live = [n for n in ("PSU.1.L", "PSU.2.N") if path(e, "LINE", n) is not None]
        record("T02R" if reversed_plug else "T02N", "DPST OFF, Schuko " + ("invertido" if reversed_plug else "normal"),
               "Ningún borne AC fuente tiene camino conductor directo a fase", live, [], "PASS_TOPOLOGY")
        incoming_live = path(e, "LINE", "C14.B" if reversed_plug else "C14.A") is not None
        record("T03R" if reversed_plug else "T03N", "DPST OFF con C13 conectado", "Entrada totalmente sin tensión",
               incoming_live, True, "FAIL_IF_USED_AS_SERVICE_ISOLATION")
    for reversed_plug in (False, True):
        e = mains(switch_on=True, reversed_plug=reversed_plug)
        e.append(Edge("PSU.1.L", "PSU.2.N", "FAULT_LN", "fault"))
        p = path(e, "LINE", "NEUTRAL")
        record("T04R" if reversed_plug else "T04N", "Corto entre polos aguas abajo del switch",
               "La trayectoria de corto incluye F_AC_A", "F_AC_A" in p, True, "PASS_PATH_ONLY", p)
        e = mains(switch_on=True, reversed_plug=reversed_plug)
        fault_node = "PSU.2.N" if reversed_plug else "PSU.1.L"
        e += [Edge(fault_node, "CHASSIS", "FAULT_TO_CHASSIS", "fault"), Edge("CHASSIS", "PE_IN", "PE", "PE")]
        p = path(e, "LINE", "PE_IN")
        record("T05R" if reversed_plug else "T05N", "Derivación del polo activo a chasis, fusible único",
               "La trayectoria incluye el fusible del aparato", "F_AC_A" in p, not reversed_plug,
               "FAIL_LOCAL_FUSE_COVERAGE" if reversed_plug else "PASS_PATH_ONLY", p)
    e = mains(switch_on=True, reversed_plug=True, two_fuses=True)
    e += [Edge("PSU.2.N", "CHASSIS", "FAULT_TO_CHASSIS", "fault"), Edge("CHASSIS", "PE_IN", "PE", "PE")]
    p = path(e, "LINE", "PE_IN")
    record("T06", "Dos fusibles, derivación B activo a chasis", "Trayectoria incluye fusible B", "F_AC_B" in p, True, "PASS_PATH_ONLY", p)
    for variant, metal in (("base", ["CHASSIS", "PSU.FG", "FRONT", "INNER_BOX", "DRAWER"]), ("A", ["CHASSIS", "PSU.FG", "FRONT", "DRAWER"]), ("R1", ["CHASSIS", "PSU.FG", "FRONT", "DRAWER"])):
        e = protective_earth(variant)
        missing = [n for n in metal if path(e, "PE_IN", n) is None]
        record("T07_" + variant, "PE íntegro " + variant, "Todos los metales modelados tienen PE", missing, [], "PASS_TOPOLOGY")
    for variant in ("A", "R1"):
        e = protective_earth(variant, drawer_bridge=False)
        p = path(e, "PE_IN", "CHASSIS")
        record("T08_" + variant, "Puente de cajón retirado con C13 conectado " + variant,
               "La carcasa fija conserva PE", p is not None, variant == "R1",
               "PASS_TOPOLOGY_CHASSIS_ONLY" if variant == "R1" else "FAIL", p)
    e = dc()
    record("T09", "Distribución DC sin modelos internos de cargas", "No hay puente ideal entre +5V y GND",
           path(e, "STAR.PLUS", "STAR.GND") is None, True, "PASS_WIRING_ONLY")
    record("T10", "UART del documento", "La Pi y ZE disponen de referencia GND común",
           path(e, "PI.GND", "ZE.GND") is not None, True, "PASS_TOPOLOGY", path(e, "PI.GND", "ZE.GND"))
    for source, target, test_id in (("PI.TX", "ZE.RX", "T11"), ("ZE.TX", "PI.RX", "T12")):
        record(test_id, "Cruce UART", "TX llega a RX opuesto", path(e, source, target) is not None, True, "PASS_WIRING_ONLY", path(e, source, target))
    e = dc(returns_open=("SCREEN",))
    p = path(e, "SCREEN.GND", "STAR.GND")
    record("T13", "Retorno pantalla abierto y masas HDMI comunes", "Apertura del retorno no encuentra camino por HDMI",
           p is None, False, "FAIL_CONDITIONAL_RETURN_PATH", p, True)
    e = dc(returns_open=("PI",))
    p = path(e, "PI.GND", "STAR.GND")
    record("T14", "Retorno Pi abierto y masas HDMI comunes", "Apertura del retorno no encuentra camino por HDMI",
           p is None, False, "FAIL_CONDITIONAL_RETURN_PATH", p, True)
    e = dc(rf_bond=True)
    p = path(e, "PI.GND", "CHASSIS")
    record("T15", "AR9271 con unión RF a GND, condición no medida", "Pin GND Pi aislado de chasis",
           p is None, False, "FAIL_CONDITIONAL_FLOATING_CLAIM", p, True)
    e = dc(rf_bond=False)
    record("T16", "Sin unión RF/GND ni otras uniones no modeladas", "Pin GND Pi aislado de chasis",
           path(e, "PI.GND", "CHASSIS") is None, True, "CONDITIONAL_ONLY", conditional=True)
    for device in ("USB1", "USB2"):
        record("T17_" + device, "Identificación DCP", "D+ y D- unidos y separados de alimentación en el cableado ideal",
               path(e, device + ".DPLUS", device + ".DMINUS") is not None and path(e, device + ".DPLUS", "STAR.PLUS") is None,
               True, "PASS_WIRING_ONLY")
    summary = {"audited_commit": SNAPSHOT, "model": "ideal_wire_connectivity", "hardware_tests": 0,
               "self_checks": len(results), "self_checks_pass": len(results),
               "warning": "PASS del programa valida el cálculo; design_verdict conserva fallos y condiciones.",
               "tests": results}
    (output_dir / "topology_results.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    with (output_dir / "topology_results.csv").open("w", encoding="utf-8", newline="") as f:
        fields = ["id", "scenario", "criterion", "observed", "design_verdict", "conditional", "path", "self_check"]
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(results)
    nets = {"audited_commit": SNAPSHOT, "variants": {}, "limitations": summary["warning"]}
    for name in ("base", "A", "R1"):
        nets["variants"][name] = {"mains": [asdict(x) for x in mains()], "PE": [asdict(x) for x in protective_earth(name)],
                                  "DC_and_signals": [asdict(x) for x in dc()]}
    nets["notes"] = ["R1 aquí sólo cambia la topología PE/ubicación de red; protecciones y UART se especifican en el informe.",
                      "Las entradas mains de A/base representan el caso DPST reconocido; la variante SPST se ensaya por separado.",
                      "No hay modelo eléctrico interno del convertidor AC/DC ni de los receptores."]
    (output_dir / "netlist_graph.json").write_text(json.dumps(nets, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"self_checks": len(results), "pass": len(results), "hardware_tests": 0, "output": str(output_dir)}, ensure_ascii=False))

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=Path(__file__).parent / "resultados")
    run(parser.parse_args().out)
