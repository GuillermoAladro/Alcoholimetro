#!/usr/bin/env python3
"""Auditoría resistiva DC reproducible del Alcoholimetro, sólo Python estándar.

Uso: python3 model_dc.py --output-dir ./resultados
No lee/escribe el repositorio, no usa red, SPICE, modelos de IC ni medidas físicas.
El grafo separa positivo y retorno, W11/W12, cuatro ramas y F1 de la Pi.
CC = corriente constante. CP = potencia constante P=5 V * corriente de presupuesto.
Las resistencias desconocidas son hipótesis de sensibilidad, no valores certificados.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import itertools
import json
import math
from dataclasses import asdict, dataclass, replace
from pathlib import Path

COMMIT = "84be97669a9efec43e79b3dadc4af5e87458c41a"
REPO = "https://github.com/GuillermoAladro/Alcoholimetro/blob/" + COMMIT + "/"
BRANCHES = ("pi", "solo", "screen", "ze")
VOLTAGES = (5.0, 5.1, 5.15, 5.2)
ALPHA_CU = 0.00393  # /K, supuesto de sensibilidad tomado del presupuesto del repo.
R_AWG = {22: 0.05296, 24: 0.08422, 28: 0.2129}  # ohm/m/conductor, 20 C.
R_METRIC = {0.75: 0.026, 1.5: 0.0133}  # LAPP T11, clase 5, Cu desnudo, ohm/m.
SOURCE_DRIFT = 0.005 + 0.01 + 0.0003 * 25.0  # +/-2,25%; envolvente ilustrativa.
FUSE_RATINGS = {"pi": 3.0, "solo": 3.0, "screen": 3.0, "ze": 2.0}
LOADS = {
    "typical_estimate": {"pi": 0.9, "solo": 0.8, "screen": 0.5, "ze": 0.1},
    "peak_estimate": {"pi": 2.0, "solo": 2.0, "screen": 0.5, "ze": 0.5},
    "peak_screen_1A": {"pi": 2.0, "solo": 2.0, "screen": 1.0, "ze": 0.5},
    "sizing_pi_2_5A": {"pi": 2.5, "solo": 2.0, "screen": 1.0, "ze": 0.5},
    "unloaded": {key: 0.0 for key in BRANCHES},
}

SOURCES = [
    {"id": "S01", "url": REPO + "MONTAJE-GENERAL.md", "location": "W11-W20, W23-W27; secciones 1 y 6.3", "supports": "Topología, pines, secciones nominales, longitudes Pi/ZE y fusibles condicionales del diseño A."},
    {"id": "S02", "url": REPO + "componentes/latiguillo-micro-usb-22awg/README.md", "location": "secciones 2 y 4.1-4.3", "supports": "Presupuesto estimado Pi 0,9/2 A con cámara y Wi-Fi; tabla AWG; antecedentes F1. No certifica el latiguillo ni R de la unidad."},
    {"id": "S03", "url": REPO + "componentes/cable-2x0-75-rojo-negro-10m/README.md", "location": "sección 4; presupuesto de 0,50 m de troncal", "supports": "Longitud de 0,50 m es hipótesis anterior, no medida. Coeficiente Cu 0,00393/K heredado para sensibilidad."},
    {"id": "S04", "url": "https://t3.lappcdn.com/fileadmin/DAM/Miltronic_Denmark/4_servicecenter/T11.pdf", "local": "componentes/cable-2x0-75-rojo-negro-10m/datasheets/T11.pdf", "location": "tabla T11, clase 5 cobre desnudo a 20 C", "supports": "0,75 mm2: 26,0 ohm/km; 1,5 mm2: 13,3 ohm/km. Referencia genérica, no medición del cable comprado."},
    {"id": "S05", "url": "https://www.meanwell.com/Upload/PDF/LRS-50/LRS-50-SPEC.PDF", "local": "componentes/meanwell-lrs-50-5/datasheets/MEAN_WELL_LRS-50_DATA_SHEET.pdf", "location": "pp.1-2 tabla y notas; p.4 bornes", "supports": "5 V/10 A/50 W; linea +/-0,5%, carga +/-1%, coeficiente +/-0,03%/C (0-50 C), 80 mVpp con excepción de nota 7 en 0-50% de carga; OCP 110-150% de potencia con hiccup; OVP 5,9-7,3 V."},
    {"id": "S06", "url": "https://www.raspberrypi.com/documentation/computers/config_txt.html", "location": "Monitoring voltage; consultado 2026-10-21", "supports": "Mantener tensión por encima de 4,8 V para fiabilidad; medir VCC/GND en GPIO. Se usa >4,8 V como criterio en rail tras F1 y también se informa J1."},
    {"id": "S07", "url": "https://www.raspberrypi.com/documentation/computers/raspberry-pi.html", "location": "Power supply warnings; consultado 2026-10-21", "supports": "Umbral de aviso 4,63 V +/-5%, no tensión mínima garantizada de funcionamiento."},
    {"id": "S08", "url": "https://pip-assets.raspberrypi.com/categories/532-raspberry-pi-3-model-b/documents/RP-008339-DS-1-raspberry-pi-3-b-plus-reduced-schematics.pdf", "local": "componentes/raspberry-pi-3b-plus/datasheets/RP-008339-DS-1-raspberry-pi-3-b-plus-reduced-schematics.pdf", "location": "p.1, J1/F1/D7 y J8", "supports": "J1 pin1 VBUS pasa por F1 MF-MSMF250/X antes del rail 5V; pin5 GND; GPIO2/4 5V, GPIO6/9 GND. F1 no se puentea en este modelo."},
    {"id": "S09", "url": "https://www.winsen-sensor.com/d/files/manual/ze29a-c2h5oh.pdf", "local": "componentes/winsen-ze29a/datasheets/ze29a-c2h5oh.pdf", "location": "Manual V1.1, parámetros técnicos y definición de pines", "supports": "ZE29A 5 V +/-0,3 V y corriente <500 mA; pin1 Vin, pin2 GND, pin3 TX, pin4 RX; UART TTL 3,3 V."},
    {"id": "S10", "url": REPO + "componentes/sumup-solo/README.md", "location": "sección de alimentación", "supports": "0,8/2 A son estimaciones del diseño, no datos publicados de consumo del Solo; cargador REG001 no equivale a consumo del lector."},
    {"id": "S11", "url": REPO + "componentes/pantalla-geeekpi-7-hdmi/README.md", "location": "secciones 1, 2 y alimentación", "supports": "0,5 A y ventana 4,75-5,25 V fueron tomados de otra pantalla; 1 A es margen de diseño, no corriente máxima publicada de la 52Pi concreta."},
    {"id": "S12", "url": "https://usb.org/document-library/usb-20-specification", "local": "componentes/latiguillo-micro-usb-22awg/datasheets/Micro-USB_1_01.pdf", "location": "Micro-USB Rev1.01 secciones 5.2-5.3", "supports": "30 mOhm/contacto inicial es límite genérico; no acredita el conjunto comprado ni permite inferir temperatura a partir de corriente."},
]

PIN_FLAGS = [
    {"id": "P01", "connection": "LRS-50-5", "mapping": "1 AC/L; 2 AC/N; 3 FG; 4 DC -V; 5 DC +V", "status": "MONTAJE y dibujo primario coinciden; el README antiguo de la fuente tiene una tabla invertida", "sources": ["S01", "S05"]},
    {"id": "P02", "connection": "W11/W12 y WAGO", "mapping": "+V a WAGO positiva polo1; -V a WAGO retorno polo1; polos2 Pi,3 Solo,4 pantalla,5 ZE", "status": "Cada WAGO es una sola barra eléctrica; las dos barras deben permanecer separadas", "sources": ["S01"]},
    {"id": "P03", "connection": "W13 Pi J1", "mapping": "microUSB1 VBUS -> F1 -> rail5V; microUSB5 GND", "status": "Mostrar V antes y después de F1; no inferir polaridad sólo por color ni puentear F1", "sources": ["S01", "S08"]},
    {"id": "P04", "connection": "W14-W17 USB-A a C", "mapping": "Borne + a VBUS; borne - a GND; D+/D- unidos según montaje; S externo libre", "status": "Identificación de carga, Rp/CC, corriente realmente admitida y retorno interno de malla no son resueltos por el modelo resistivo", "sources": ["S01"]},
    {"id": "P05", "connection": "W18 ZE", "mapping": "pin1 Vin5V, pin2 GND; no por colores", "status": "Tipo y paso del conector pendientes; rango eléctrico del módulo4,7-5,3 V", "sources": ["S01", "S09"]},
    {"id": "P06", "connection": "W19/W20 UART", "mapping": "Pi físico8 TX -> ZE4 RX; ZE3 TX -> Pi físico10 RX", "status": "TTL3,3 V; usar diferencia de masas calculada. Ningún GPIO de señal recibe5 V. Clamps y alimentación parásita no modelados", "sources": ["S01", "S09"]},
    {"id": "P07", "connection": "Pi medida", "mapping": "GPIO físico2/4 = rail5V trasF1; físico6/9 = GND", "status": "Criterio de fiabilidad >4,8 V; 4,63 V +/-5% es detección de subtensión", "sources": ["S06", "S07", "S08"]},
    {"id": "P08", "connection": "W23 HDMI y W26 coaxial", "mapping": "HDMI puede cerrar PiGND-pantallaGND; coaxial/carcasa puede cerrar GND-PE", "status": "Una sola unión GND-PE no crea por sí sola un segundo retorno a la fuente; el caso chasis del modelo presupone circuito cerrado", "sources": ["S01"]},
    {"id": "P09", "connection": "Diseño A condicional", "mapping": "Pi3 A; Solo3 A; pantalla3 A; ZE2 A", "status": "Se supone fusible en positivo. Curva, parte, resistencia en caliente y coordinación con hiccup pendientes; abrir el fusible no demuestra aislamiento frente a señales", "sources": ["S01", "S05"]},
    {"id": "P10", "connection": "Presupuesto Pi", "mapping": "Incluye cámaraCSI, AR9271USB y SD", "status": "No sumar esos periféricos dos veces; la frase 'Pi no alimenta nada' del resumen no describe literalmente W24/W25/W27", "sources": ["S01", "S02"]},
]

# Cada valor de contacto/F1 es una hipótesis, no una estadística ni una medida.
# Resistencias por pata salvo F1 (positivo sólo). El perfil target es un objetivo
# que debe verificarse en conjunto y en caliente; no se presupone alcanzado.
CONTACTS = {
    "low": {"common_leg": .0025, "branch_terminal_leg": .0025, "micro_leg": .010, "ac_leg": .020, "ze_leg": .005, "pi_f1": .015},
    "reference": {"common_leg": .005, "branch_terminal_leg": .005, "micro_leg": .015, "ac_leg": .025, "ze_leg": .010, "pi_f1": .050},
    "high": {"common_leg": .010, "branch_terminal_leg": .010, "micro_leg": .030, "ac_leg": .050, "ze_leg": .020, "pi_f1": .100},
    "target": {"common_leg": .002, "branch_terminal_leg": .002, "micro_leg": .005, "ac_leg": .015, "ze_leg": .005, "pi_f1": .015},
}


@dataclass(frozen=True)
class Resistor:
    name: str
    a: str
    b: str
    ohm: float
    category: str


@dataclass(frozen=True)
class Load:
    name: str
    positive: str
    negative: str
    mode: str
    value: float  # A en CC, W en CP.


@dataclass(frozen=True)
class Config:
    setpoint_v: float = 5.2
    envelope: str = "nominal"
    load_case: str = "peak_estimate"
    mode: str = "CC"
    contact_profile: str = "reference"
    wire_temperature_c: float = 20.0
    trunk_length_m: float = .50  # ida; existe otro conductor de retorno igual.
    trunk_area_mm2: float = .75
    pi_length_m: float = .15
    ac_lead_length_m: float = .20  # W14/W16 por conductor; supuesto sin medida.
    solo_cable_length_m: float = .30
    solo_awg: int = 22  # supuesto: el cable A-C no declara calibre verificado.
    screen_cable_length_m: float = .50  # supuesto: longitud desconocida.
    screen_awg: int = 24  # supuesto: calibre desconocido.
    ze_length_m: float = .15
    external_fuse_ohm: float = 0.0  # fusible+portafusibles de la rama, no F1.
    revision: str = "base_without_branch_fuses"
    hdmi_return_ohm: float | None = None  # enlace condicionado, resistencia supuesta.
    chassis_return_ohm: float | None = None  # circuito CERRADO PiGND a source_minus.
    open_return: str | None = None
    open_positive: str | None = None
    short_branch: str | None = None
    short_ohm: float = .010

    @property
    def source_v(self) -> float:
        return self.setpoint_v * {"nominal": 1.0, "low": 1-SOURCE_DRIFT, "high": 1+SOURCE_DRIFT}[self.envelope]


class NoOperatingPoint(ValueError):
    pass


def solve_linear(matrix: list[list[float]], rhs: list[float]) -> list[float]:
    """Eliminación de Gauss con pivote parcial; sistemas pequeños, doble precisión."""
    a = [row[:] + [value] for row, value in zip(matrix, rhs)]
    n = len(a)
    for col in range(n):
        pivot = max(range(col, n), key=lambda row: abs(a[row][col]))
        if abs(a[pivot][col]) < 1e-13:
            raise NoOperatingPoint("Grafo singular o rama sin retorno; no hay solución única.")
        a[col], a[pivot] = a[pivot], a[col]
        for row in range(col+1, n):
            factor = a[row][col] / a[col][col]
            for j in range(col, n+1):
                a[row][j] -= factor*a[col][j]
    result = [0.0]*n
    for i in range(n-1, -1, -1):
        result[i] = (a[i][n]-sum(a[i][j]*result[j] for j in range(i+1, n)))/a[i][i]
    return result


def solve_network(resistors: list[Resistor], loads: list[Load], fixed: dict[str, float]) -> dict:
    """KCL nodal. CP usa Newton amortiguado desde el punto CC I=P/5 V.

    Se busca la solución positiva cercana al funcionamiento normal, no dinámica
    ni estabilidad del lazo real. La convergencia matemática no acredita hardware.
    """
    nodes = sorted(({r.a for r in resistors} | {r.b for r in resistors} |
                    {l.positive for l in loads} | {l.negative for l in loads}) - set(fixed))
    ix = {node: i for i, node in enumerate(nodes)}
    n = len(nodes)
    g = [[0.0]*n for _ in nodes]
    source_rhs = [0.0]*n
    for r in resistors:
        if r.ohm <= 0:
            raise ValueError("Las resistencias deben ser positivas.")
        conductance = 1.0/r.ohm
        for a, b in ((r.a, r.b), (r.b, r.a)):
            if a in ix:
                g[ix[a]][ix[a]] += conductance
                if b in ix:
                    g[ix[a]][ix[b]] -= conductance
                else:
                    source_rhs[ix[a]] += conductance*fixed[b]
    rhs = source_rhs[:]
    for load in loads:
        current = load.value if load.mode == "CC" else load.value/5.0
        for node, sign in ((load.positive, -1.0), (load.negative, 1.0)):
            if node in ix:
                rhs[ix[node]] += sign*current
    x = solve_linear(g, rhs)

    def residual(values: list[float], jacobian: bool = False):
        volts = {**fixed, **dict(zip(nodes, values))}
        f = [sum(g[i][j]*values[j] for j in range(n))-source_rhs[i] for i in range(n)]
        jac = [row[:] for row in g] if jacobian else None
        for load in loads:
            dv = volts[load.positive]-volts[load.negative]
            if load.mode == "CP" and load.value and dv <= .05:
                raise NoOperatingPoint("CP ideal fuera del dominio positivo del solucionador.")
            current = load.value if load.mode == "CC" else (load.value/dv if load.value else 0.0)
            derivative = 0.0 if load.mode == "CC" else (-load.value/dv**2 if load.value else 0.0)
            for a, sa in ((load.positive, 1.0), (load.negative, -1.0)):
                if a in ix:
                    f[ix[a]] += sa*current
                    if jacobian:
                        for b, sb in ((load.positive, 1.0), (load.negative, -1.0)):
                            if b in ix:
                                jac[ix[a]][ix[b]] += sa*sb*derivative
        return f, jac

    iterations = 0
    if any(l.mode == "CP" and l.value for l in loads):
        for iterations in range(1, 81):
            f, jac = residual(x, True)
            norm = max(map(abs, f), default=0.0)
            if norm < 1e-10:
                break
            step = solve_linear(jac, [-v for v in f])
            scale = 1.0
            for _ in range(24):
                candidate = [v+scale*s for v, s in zip(x, step)]
                try:
                    cf, _ = residual(candidate)
                    if max(map(abs, cf), default=0.0) < norm:
                        x = candidate
                        break
                except NoOperatingPoint:
                    pass
                scale *= .5
            else:
                raise NoOperatingPoint("Newton no encontró descenso positivo; CP ideal sin punto verificado.")
        else:
            raise NoOperatingPoint("CP ideal no convergió.")
    volts = {**fixed, **dict(zip(nodes, x))}
    edges = []
    balance = {node: 0.0 for node in volts}
    loss = 0.0
    for r in resistors:
        current = (volts[r.a]-volts[r.b])/r.ohm
        power = current*current*r.ohm
        edges.append({**asdict(r), "current_a": current, "loss_w": power})
        balance[r.a] += current
        balance[r.b] -= current
        loss += power
    load_results = {}
    load_power = 0.0
    for load in loads:
        dv = volts[load.positive]-volts[load.negative]
        current = load.value if load.mode == "CC" else (load.value/dv if load.value else 0.0)
        balance[load.positive] += current
        balance[load.negative] -= current
        load_results[load.name] = {"voltage_v": dv, "current_a": current, "power_w": dv*current}
        load_power += dv*current
    source_power = sum(volts[node]*balance[node] for node in fixed)
    return {"voltages": volts, "loads": load_results, "edges": edges,
            "fixed_node_current_out_a": {node: balance[node] for node in fixed},
            "source_power_w": source_power, "resistor_loss_w": loss, "load_power_w": load_power,
            "max_kcl_residual_a": max((abs(balance[node]) for node in nodes), default=0.0),
            "power_residual_w": source_power-loss-load_power, "newton_iterations": iterations}


def build_network(config: Config):
    c = CONTACTS[config.contact_profile]
    factor = 1.0 + ALPHA_CU*(config.wire_temperature_c-20)
    tw = config.trunk_length_m*R_METRIC[config.trunk_area_mm2]*factor
    resistors = [Resistor("W11_trunk_positive", "source_plus", "bus_plus", tw+c["common_leg"], "trunk"),
                 Resistor("W12_trunk_return", "bus_minus", "source_minus", tw+c["common_leg"], "trunk")]
    specs = {}
    loads = []
    for branch in BRANCHES:
        wire = config.pi_length_m*R_AWG[22]*factor if branch == "pi" else (
            config.ze_length_m*R_AWG[22]*factor if branch == "ze" else
            config.ac_lead_length_m*R_METRIC[.75]*factor +
            (config.solo_cable_length_m*R_AWG[config.solo_awg]*factor if branch == "solo" else
             config.screen_cable_length_m*R_AWG[config.screen_awg]*factor))
        connector = c["micro_leg"] if branch == "pi" else c["ze_leg"] if branch == "ze" else c["ac_leg"]
        leg = wire + connector + c["branch_terminal_leg"]
        p, m = branch+"_plus", branch+"_minus"
        pre = "pi_j1_vbus" if branch == "pi" else p
        if config.open_positive != branch:
            resistors.append(Resistor(branch+"_positive", "bus_plus", pre, leg+config.external_fuse_ohm, "branch_feed"))
        if branch == "pi":
            resistors.append(Resistor("pi_F1", pre, p, c["pi_f1"], "pi_onboard_fuse"))
        if config.open_return != branch:
            resistors.append(Resistor(branch+"_return", m, "bus_minus", leg, "branch_return"))
        specs[branch] = {"wire_each_leg_ohm": wire, "connector_each_leg_ohm": connector,
                         "branch_terminal_each_leg_ohm": c["branch_terminal_leg"],
                         "positive_ohm": leg+config.external_fuse_ohm+(c["pi_f1"] if branch == "pi" else 0),
                         "return_ohm": leg,
                         "loop_ohm": 2*leg+config.external_fuse_ohm+(c["pi_f1"] if branch == "pi" else 0),
                         "external_fuse_ohm": config.external_fuse_ohm,
                         "onboard_F1_ohm": c["pi_f1"] if branch == "pi" else 0.0}
        if config.short_branch == branch:
            resistors.append(Resistor(branch+"_fault_short", p, m, config.short_ohm, "fault"))
        else:
            nominal = LOADS[config.load_case][branch]
            loads.append(Load(branch, p, m, config.mode, nominal if config.mode == "CC" else nominal*5.0))
    if config.hdmi_return_ohm is not None:
        resistors.append(Resistor("HDMI_ground_link", "pi_minus", "screen_minus", config.hdmi_return_ohm, "parallel_return"))
    if config.chassis_return_ohm is not None:
        resistors.append(Resistor("closed_chassis_return", "pi_minus", "source_minus", config.chassis_return_ohm, "parallel_return"))

    # Conectividad sólo a través de conductores: las cargas no sustituyen un retorno.
    adjacency = {}
    for r in resistors:
        adjacency.setdefault(r.a, set()).add(r.b)
        adjacency.setdefault(r.b, set()).add(r.a)
    def reachable(start):
        seen, todo = {start}, [start]
        while todo:
            for node in adjacency.get(todo.pop(), set()) - seen:
                seen.add(node)
                todo.append(node)
        return seen
    source_connected = reachable("source_plus") | reachable("source_minus")
    plus_connected, minus_connected = reachable("source_plus"), reachable("source_minus")
    unpowered = [load.name for load in loads if load.positive not in plus_connected or load.negative not in minus_connected]
    loads = [load for load in loads if load.name not in unpowered]
    resistors = [r for r in resistors if r.a in source_connected and r.b in source_connected]
    return resistors, loads, specs, unpowered, 2*(tw+c["common_leg"])


def analyse(config: Config, scenario_id: str, include_edges: bool = False) -> dict:
    resistors, loads, specs, unpowered, trunk_loop = build_network(config)
    solution = solve_network(resistors, loads, {"source_plus": config.source_v, "source_minus": 0.0})
    volts = solution["voltages"]
    edges = {e["name"]: e for e in solution["edges"]}
    branch_results = {}
    for branch in BRANCHES:
        if branch in unpowered:
            branch_results[branch] = {"status": "unpowered_in_resistive_model", "voltage_v": None, "current_a": 0.0, "power_w": 0.0}
        elif config.short_branch == branch:
            fault = edges[branch+"_fault_short"]
            branch_results[branch] = {"status": "short_circuit_ideal_source_projection", "voltage_v": volts[branch+"_plus"]-volts[branch+"_minus"], "current_a": fault["current_a"], "power_w": fault["loss_w"]}
        else:
            branch_results[branch] = {"status": "mathematical_operating_point", **solution["loads"][branch]}
        item = branch_results[branch]
        item["ground_wrt_source_minus_v"] = volts.get(branch+"_minus")
        item["main_return_current_a"] = edges.get(branch+"_return", {}).get("current_a", 0.0)
        item["R_loop_without_parallel_ohm"] = specs[branch]["loop_ohm"]
        item["external_fuse_current_ratio"] = item["current_a"]/FUSE_RATINGS[branch] if config.revision == "A_conditional" else None
    pi = branch_results["pi"]
    pi["j1_before_F1_v"] = (volts.get("pi_j1_vbus", 0)-volts.get("pi_minus", 0)) if "pi" not in unpowered else None
    if pi["voltage_v"] is not None:
        pi["margin_to_4_8V_v"] = pi["voltage_v"]-4.8
        pi["margin_to_nominal_warning_v"] = pi["voltage_v"]-4.63
        pi["margin_to_upper_warning_tolerance_v"] = pi["voltage_v"]-4.63*1.05
    source_i = solution["fixed_node_current_out_a"]["source_plus"]
    flags = []
    if source_i > 10 or solution["source_power_w"] > 50:
        flags.append("OUTSIDE_NOMINAL_SOURCE_RATING_IDEAL_SOURCE_RESULT_NOT_PREDICTION")
    if solution["source_power_w"] > 55:
        flags.append("ABOVE_110_PERCENT_OCP_POWER_BOUND_HICCUP_AND_FUSE_TIMING_UNMODELLED")
    if pi["voltage_v"] is not None and pi["voltage_v"] <= 4.8:
        flags.append("PI_RAIL_NOT_ABOVE_4_8V_RELIABILITY_CRITERION")
    if pi["voltage_v"] is not None and pi["voltage_v"] < 4.63*1.05:
        flags.append("PI_BELOW_UPPER_TOLERANCE_OF_WARNING_THRESHOLD")
    for branch, low, high in (("ze", 4.7, 5.3), ("solo", 4.75, 5.25), ("screen", 4.75, 5.25)):
        voltage = branch_results[branch]["voltage_v"]
        if voltage is not None and not low <= voltage <= high:
            flags.append(branch.upper()+ ("_OUTSIDE_OFFICIAL_INPUT_RANGE" if branch == "ze" else "_OUTSIDE_ASSUMED_DESIGN_WINDOW_NOT_VENDOR_LIMIT"))
    if pi["voltage_v"] is not None and pi["voltage_v"] > 5.25:
        flags.append("PI_ABOVE_ASSUMED_5_25V_DESIGN_CEILING_NOT_PUBLISHED_ABSOLUTE_MAXIMUM")
    if unpowered:
        flags.append("OPEN_BRANCH_PHANTOM_POWER_THROUGH_SIGNAL_IC_NOT_MODELLED")
    if config.open_return and config.open_return not in unpowered:
        flags.append("RETURN_OPEN_LOAD_CURRENT_USES_CONDITIONAL_ALTERNATIVE_PATH")
    if not config.short_branch and any(item["voltage_v"] is not None and item["voltage_v"] < 4.0 for item in branch_results.values()):
        flags.append("IDEAL_LOAD_LAW_EXTRAPOLATED_ACTUAL_UVLO_BEHAVIOUR_UNKNOWN")
    result = {"id": scenario_id, "parameters": asdict(config), "source_v": config.source_v,
              "source_current_a": source_i, "source_power_w": solution["source_power_w"],
              "source_output_power_percent_of_50W": solution["source_power_w"]*2,
              "bus_differential_v": volts["bus_plus"]-volts["bus_minus"],
              "trunk_loop_ohm": trunk_loop,
              "trunk_loss_w": sum(e["loss_w"] for e in solution["edges"] if e["category"] == "trunk"),
              "all_resistive_loss_w": solution["resistor_loss_w"],
              "load_power_w": solution["load_power_w"], "branches": branch_results,
              "pi_minus_ze_ground_v": volts["pi_minus"]-volts["ze_minus"] if "pi_minus" in volts and "ze_minus" in volts else None,
              "hdmi_ground_current_pi_to_screen_a": edges.get("HDMI_ground_link", {}).get("current_a", 0.0),
              "chassis_current_pi_to_source_a": edges.get("closed_chassis_return", {}).get("current_a", 0.0),
              "validation": {k: solution[k] for k in ("max_kcl_residual_a", "power_residual_w", "newton_iterations")},
              "flags": flags}
    if include_edges:
        result.update({"nodes_v": volts, "edges": solution["edges"], "branch_resistance_breakdown": specs})
    return result


def validate() -> list[dict]:
    """Oráculos analíticos independientes de la construcción específica del montaje."""
    checks = []
    r = [Resistor("p", "s", "p", .1, "test"), Resistor("m", "m", "g", .2, "test")]
    out = solve_network(r, [Load("x", "p", "m", "CC", 2.0)], {"s": 5.0, "g": 0.0})
    actual = out["loads"]["x"]["voltage_v"]
    assert math.isclose(actual, 4.4, abs_tol=1e-11)
    assert math.isclose(out["voltages"]["m"], .4, abs_tol=1e-11)
    assert math.isclose(out["resistor_loss_w"], 1.2, abs_tol=1e-11)
    checks.append({"test": "single_CC_Ohm_loop", "expected_load_v": 4.4, "actual_load_v": actual, "passed": True})
    r = [Resistor("p", "s", "p", .06, "test"), Resistor("m", "m", "g", .04, "test")]
    out = solve_network(r, [Load("x", "p", "m", "CP", 10.0)], {"s": 5.0, "g": 0.0})
    expected = (5+math.sqrt(25-4*.1*10))/2
    assert math.isclose(out["loads"]["x"]["voltage_v"], expected, abs_tol=1e-10)
    checks.append({"test": "single_CP_quadratic_high_voltage_root", "expected_load_v": expected, "actual_load_v": out["loads"]["x"]["voltage_v"], "passed": True})
    r = [Resistor("r1", "m", "g", .1, "test"), Resistor("r2", "m", "g", .2, "test")]
    out = solve_network(r, [Load("x", "s", "m", "CC", 3.0)], {"s": 5.0, "g": 0.0})
    currents = [edge["current_a"] for edge in out["edges"]]
    assert math.isclose(currents[0], 2, abs_tol=1e-11) and math.isclose(currents[1], 1, abs_tol=1e-11)
    checks.append({"test": "parallel_return_current_division", "expected_a": [2.0, 1.0], "actual_a": currents, "passed": True})
    try:
        solve_network([Resistor("r", "s", "p", .5, "test")], [Load("x", "p", "g", "CP", 13)], {"s": 5.0, "g": 0.0})
    except NoOperatingPoint:
        checks.append({"test": "CP_no_real_root_above_maximum_power", "analytic_pmax_w": 12.5, "requested_w": 13, "passed": True})
    else:
        raise AssertionError("Una CP de 13 W no puede tener solución positiva con E=5 V, R=0,5 ohm.")
    return checks


def scenario_matrix() -> list[tuple[str, Config]]:
    scenarios = []
    def add(group, c):
        scenarios.append((group+"_"+str(len(scenarios)+1).zfill(4), c))
    for voltage, length, contact, load_case, mode, fused in itertools.product(VOLTAGES, (.15, .30), ("low", "reference", "high"), ("typical_estimate", "peak_estimate"), ("CC", "CP"), (False, True)):
        add("core", Config(setpoint_v=voltage, pi_length_m=length, contact_profile=contact, load_case=load_case, mode=mode, external_fuse_ohm=.020 if fused else 0, revision="A_conditional" if fused else "base_without_branch_fuses"))
    for voltage, load_case, envelope, mode, fused in itertools.product(VOLTAGES, ("typical_estimate", "peak_screen_1A"), ("low", "nominal", "high"), ("CC", "CP"), (False, True)):
        add("envelope", Config(setpoint_v=voltage, load_case=load_case, envelope=envelope, mode=mode, external_fuse_ohm=.020 if fused else 0, revision="A_conditional" if fused else "base_without_branch_fuses"))
    for voltage, length, temperature, mode, fused in itertools.product(VOLTAGES, (.15, .30), (40.0, 60.0), ("CC", "CP"), (False, True)):
        add("wire_temperature", Config(setpoint_v=voltage, pi_length_m=length, wire_temperature_c=temperature, mode=mode, external_fuse_ohm=.020 if fused else 0, revision="A_conditional" if fused else "base_without_branch_fuses"))
    for voltage, load_case, mode, fused in itertools.product(VOLTAGES, ("peak_screen_1A", "sizing_pi_2_5A"), ("CC", "CP"), (False, True)):
        add("load_sensitivity", Config(setpoint_v=voltage, load_case=load_case, mode=mode, external_fuse_ohm=.020 if fused else 0, revision="A_conditional" if fused else "base_without_branch_fuses"))
    for voltage, awg, length, mode in itertools.product(VOLTAGES, (22, 24, 28), (.30, 1.0), ("CC", "CP")):
        add("unknown_USB_cables", Config(setpoint_v=voltage, solo_awg=awg, screen_awg=awg, screen_cable_length_m=length, load_case="peak_screen_1A", mode=mode, external_fuse_ohm=.020, revision="A_conditional"))
    for voltage, resistance, mode in itertools.product(VOLTAGES, (0.0, .010, .020, .050), ("CC", "CP")):
        add("fuse_series_R", Config(setpoint_v=voltage, external_fuse_ohm=resistance, revision="A_conditional", mode=mode))
    for voltage, envelope, mode, load_case in itertools.product(VOLTAGES+(5.125,), ("low", "nominal", "high"), ("CC", "CP"), ("peak_screen_1A", "sizing_pi_2_5A")):
        add("target_R_NOT_measured", Config(setpoint_v=voltage, envelope=envelope, contact_profile="target", trunk_length_m=.20, trunk_area_mm2=1.5, screen_cable_length_m=.30, screen_awg=22, mode=mode, load_case=load_case, external_fuse_ohm=.010, revision="A_conditional"))
    for voltage, envelope in itertools.product(VOLTAGES, ("low", "nominal", "high")):
        add("unloaded", Config(setpoint_v=voltage, envelope=envelope, load_case="unloaded"))
    # R1: fronteras EFECTIVAS propuestas a la salida de la fuente, no consignas.
    # No se añade +/-2,25% porque 5,10/5,20 V YA son la ventana que se exige medir.
    for voltage, load_case, mode in itertools.product((5.10, 5.20), ("unloaded", "typical_estimate", "sizing_pi_2_5A"), ("CC", "CP")):
        add("R1_effective_source_bounds", Config(setpoint_v=voltage, envelope="nominal", contact_profile="target", trunk_length_m=.20, trunk_area_mm2=1.5, screen_cable_length_m=.30, screen_awg=22, mode=mode, load_case=load_case, external_fuse_ohm=.010, revision="A_conditional"))
    return scenarios


def fault_scenarios() -> list[dict]:
    results = []
    reference = Config(setpoint_v=5.2)
    cases = [("star_reference", reference), ("pi_positive_open", replace(reference, open_positive="pi")),
             ("pi_return_open_no_other_path", replace(reference, open_return="pi")),
             ("ze_return_open_no_signal_clamps_modelled", replace(reference, open_return="ze"))]
    for resistance in (.020, .100, .500):
        cases.extend([("HDMI_parallel_"+str(resistance), replace(reference, hdmi_return_ohm=resistance)),
                      ("pi_return_open_HDMI_"+str(resistance), replace(reference, open_return="pi", hdmi_return_ohm=resistance)),
                      ("screen_return_open_HDMI_"+str(resistance), replace(reference, open_return="screen", hdmi_return_ohm=resistance))])
    cases.append(("closed_chassis_return_conditional", replace(reference, chassis_return_ohm=.1)))
    cases.append(("open_pi_return_closed_chassis_conditional", replace(reference, open_return="pi", chassis_return_ohm=.1)))
    for branch, fused in itertools.product(BRANCHES, (False, True)):
        cases.append(("short_"+branch+("_A" if fused else "_base"), replace(reference, short_branch=branch, external_fuse_ohm=.020 if fused else 0, revision="A_conditional" if fused else "base_without_branch_fuses")))
    for name, config in cases:
        results.append(analyse(config, name, True))
    return results


def budgets() -> list[dict]:
    """Presupuestos analíticos de resistencia CC; no válidos sin cambios para CP."""
    rows = []
    for voltage, envelope, load_case, trunk_loop in itertools.product(VOLTAGES, ("nominal", "low"), ("peak_estimate", "peak_screen_1A", "sizing_pi_2_5A"), (.036, .010, .00932)):
        actual_source = voltage*(1-SOURCE_DRIFT if envelope == "low" else 1)
        total = sum(LOADS[load_case].values())
        for branch, minimum in (("pi", 4.8), ("solo", 4.75), ("screen", 4.75), ("ze", 4.7)):
            current = LOADS[load_case][branch]
            available = actual_source-minimum-total*trunk_loop
            rows.append({"setpoint_v": voltage, "source_envelope": envelope, "source_v": actual_source, "load_case": load_case, "total_current_a": total, "branch": branch, "branch_current_a": current, "criterion_minimum_v": minimum, "trunk_loop_ohm": trunk_loop, "maximum_branch_loop_ohm_including_F1_and_fuse": available/current, "already_impossible_without_branch_R": available < 0, "criterion": "manufacturer_reliability_floor_strictly_above" if branch == "pi" else "manufacturer_range" if branch == "ze" else "assumed_design_window_not_vendor_spec"})
    return rows


def flat(result: dict) -> dict:
    row = {"id": result["id"], **result["parameters"]}
    for key in ("source_v", "source_current_a", "source_power_w", "bus_differential_v", "trunk_loop_ohm", "trunk_loss_w", "all_resistive_loss_w", "pi_minus_ze_ground_v", "hdmi_ground_current_pi_to_screen_a", "chassis_current_pi_to_source_a"):
        row[key] = result[key]
    for branch in BRANCHES:
        for key in ("voltage_v", "current_a", "main_return_current_a", "R_loop_without_parallel_ohm"):
            row[branch+"_"+key] = result["branches"][branch][key]
    row["pi_j1_before_F1_v"] = result["branches"]["pi"]["j1_before_F1_v"]
    row["flags"] = "|".join(result["flags"])
    row.update(result["validation"])
    return row


def write_csv(path: Path, rows: list[dict]):
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    checks = validate()
    results = [analyse(config, name) for name, config in scenario_matrix()]
    faults = fault_scenarios()
    all_cases = results+faults
    max_kcl = max(case["validation"]["max_kcl_residual_a"] for case in all_cases)
    max_power = max(abs(case["validation"]["power_residual_w"]) for case in all_cases)
    assert max_kcl < 1e-8 and max_power < 1e-8, (max_kcl, max_power)
    checks.append({"test": "KCL_and_power_conservation_all_scenarios", "scenario_count": len(all_cases), "max_kcl_residual_a": max_kcl, "max_power_residual_w": max_power, "passed": True})
    budget_rows = budgets()
    data = {"model": "Static resistive nodal network, deterministic, standard-library Python", "snapshot_commit": COMMIT,
            "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "scope": "Numerical model only; no SPICE, IC model, certification, actual load capture, fuse-trip model, or physical testing.",
            "sources": SOURCES, "pin_flags": PIN_FLAGS,
            "inputs": {"loads_a_at_budget": LOADS, "load_status": "All currents are estimates except ZE <0.5 A vendor bound; 0.5 A is design upper bound. Pi includes camera, Wi-Fi USB and SD.", "contact_profiles_ohm": CONTACTS, "contact_status": "Every contact/F1 value is sensitivity, not a measured distribution or product qualification. F1 0.1 ohm is not asserted as initial resistance.", "wire_R20_ohm_per_m_per_conductor": {"metric": R_METRIC, "AWG": R_AWG}, "alpha_Cu_per_K": ALPHA_CU, "source_relative_envelope": SOURCE_DRIFT, "source_envelope_status": "Illustrative additive sensitivity of line/load/25 K coefficient after calibration; not combined guarantee. Factory +/-2% is not added again. No ripple/transient bound included. Wire temperature independent of PSU coefficient range.", "CP_definition": "P=5.0*budget_current watts, high-voltage positive mathematical branch; actual charging/UVLO/IC behaviour unknown.", "fuse_status": "A conditional only: 3/3/3/2 A. Positive-leg location is a modelling assumption. R=0.02 ohm/reference (0/0.01/0.05 sweep) is not a part specification. No clearing prediction."},
            "verification": checks, "scenario_count": len(results), "fault_scenario_count": len(faults),
            "scenarios": results, "faults": faults, "resistance_budgets": budget_rows}
    (args.output_dir/"dc_results.json").write_text(json.dumps(data, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    (args.output_dir/"dc_validation.json").write_text(json.dumps(checks, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    (args.output_dir/"dc_pinflags.json").write_text(json.dumps(PIN_FLAGS, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    write_csv(args.output_dir/"dc_scenarios.csv", [flat(item) for item in results])
    write_csv(args.output_dir/"dc_faults.csv", [flat(item) for item in faults])
    write_csv(args.output_dir/"dc_resistance_budgets.csv", budget_rows)
    print(json.dumps({"normal_scenarios": len(results), "fault_scenarios": len(faults), "verification": checks}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
