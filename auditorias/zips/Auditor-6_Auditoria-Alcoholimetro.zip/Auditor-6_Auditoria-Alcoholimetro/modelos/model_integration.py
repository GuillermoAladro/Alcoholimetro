#!/usr/bin/env python3
"""Cálculos de integración y sensibilidad; no son mediciones ni un modelo térmico 3D."""
import argparse
import json
from pathlib import Path

def calculate(out):
    cases = {}
    cases["power_fuse_coordination"] = {
        "source_power_rating_W": 50.0,
        "source_at_V": 5.2,
        "rating_power_limited_current_A": 50.0 / 5.2,
        "A_fuse_nominal_A": [3, 3, 3, 2],
        "example_branch_current_A": [2.9, 2.9, 2.9, 1.9],
        "example_total_A": sum([2.9, 2.9, 2.9, 1.9]),
        "example_output_W": 5.2 * sum([2.9, 2.9, 2.9, 1.9]),
        "example_all_currents_below_fuse_nominal": all(i < f for i, f in zip([2.9, 2.9, 2.9, 1.9], [3, 3, 3, 2])),
        "source_OLP_W_range": [55.0, 75.0],
        "interpretation": "Contraejemplo a selectividad garantizada. No predice cuándo funde un fusible ni la forma del hiccup."
    }
    cases["capacitor_sensitivity"] = {
        "assumption": "Carga diferencial constante y capacitor ideal, sin ayuda de fuente/cable durante intervalo.",
        "C_F": 0.001, "delta_I_A": 0.5, "allowed_drop_V": 0.2,
        "support_time_s": 0.001 * 0.2 / 0.5,
        "C_required_for_10ms_F": 0.5 * 0.010 / 0.2,
        "capacitor_charge_A_at_5p15V_1ms_ramp": 0.001 * 5.15 / 0.001,
        "interpretation": "1000uF no resuelve por sí solo cualquier reset; medir duración, ESR y escalón real. Controlar arranque."
    }
    cases["OVP_gap"] = {"source_OVP_min_V": 5.9, "source_OVP_max_V": 7.3,
                        "ZE_max_V": 5.3, "provisional_system_max_V": 5.25,
                        "gap_min_to_ZE_V": 5.9 - 5.3,
                        "interpretation": "La OVP de la fuente no garantiza la ventana de tensión del ZE ni la provisional del resto."}
    cases["AC_inrush_sensitivity"] = {
        "peak_typical_A": 45.0,
        "assumed_rectangular_pulses": [
            {"duration_ms": ms, "I2t_A2s": 45 ** 2 * ms / 1000}
            for ms in (1, 5, 10)],
        "interpretation": "Pulsos ficticios para sensibilidad; no son forma de onda de la LRS. El pico no determina I2t."
    }
    cases["thermal_energy_balance"] = {
        "assumption": "Toda potencia entregada se disipa en caja; conservador si batería almacena energía o hay disipación externa. Eficiencias a carga parcial son hipótesis.",
        "rows": [
            {"source_V": 5.2, "load_A": current, "efficiency_assumed": eta,
             "DC_W": 5.2 * current, "source_loss_W": 5.2 * current * (1 / eta - 1),
             "total_heat_W": 5.2 * current / eta,
             "max_Rtheta_K_per_W_for_ZE_40C_ambient_35C": (40 - 35) / (5.2 * current / eta)}
            for current in (2.3, 5.0, 6.0) for eta in (0.75, 0.83, 0.90)]}
    cases["source_transient_envelope_example"] = {
        "assumption": "Ejemplo de presupuesto, no límite demostrado de la LRS en carga parcial.",
        "rows": [{"setpoint_V": v, "positive_DC_error_assumed_V": 0.05,
                  "positive_ripple_excursion_assumed_V": 0.04,
                  "peak_example_V": v + 0.05 + 0.04,
                  "provisional_5p25V_limit_exceeded": v + 0.05 + 0.04 > 5.25}
                 for v in (5.0, 5.1, 5.15, 5.2)]}
    checks = [
        abs(cases["power_fuse_coordination"]["example_output_W"] - 55.12) < 1e-10,
        cases["power_fuse_coordination"]["example_all_currents_below_fuse_nominal"],
        abs(cases["capacitor_sensitivity"]["support_time_s"] - 0.0004) < 1e-12,
        abs(cases["capacitor_sensitivity"]["C_required_for_10ms_F"] - 0.025) < 1e-12,
        abs(cases["AC_inrush_sensitivity"]["assumed_rectangular_pulses"][1]["I2t_A2s"] - 10.125) < 1e-10,
        all(abs(row["DC_W"] + row["source_loss_W"] - row["total_heat_W"]) < 1e-10 for row in cases["thermal_energy_balance"]["rows"])
    ]
    assert all(checks), checks
    results = {"hardware_tests": 0, "self_checks": len(checks), "self_checks_pass": sum(checks), "cases": cases}
    out.mkdir(parents=True, exist_ok=True)
    (out / "integration_results.json").write_text(json.dumps(results, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"self_checks":len(checks), "pass":sum(checks), "hardware_tests":0, "output":str(out)}))

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=Path(__file__).parent / "resultados")
    calculate(parser.parse_args().out)
