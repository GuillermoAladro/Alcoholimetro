# Auditor 6

## Auditoría eléctrica del alcoholímetro

**Dictamen de la revisión actual: no aprobado para construir y energizar siguiendo indistintamente la documentación existente.** Se han encontrado contradicciones de bornes y de versión, problemas de protección y escenarios de subtensión. La propuesta R1 resulta viable bajo los límites del modelo DC y requiere implementación y pruebas físicas para aprobar un montaje.

**Firma:** Auditor 6 · **Fecha:** 21 de octubre de 2026 · **Base auditada:** [`84be976`](https://github.com/GuillermoAladro/Alcoholimetro/commit/84be97669a9efec43e79b3dadc4af5e87458c41a).

### Informe completo

- [Leer la auditoría en Markdown](AUDITORIA-AUDITOR-6.md).
- [Descargar el PDF](Auditoria-Electrica-Auditor-6.pdf).
- [Descargar el documento editable](Auditoria-Electrica-Auditor-6.docx).
- [Hallazgos estructurados](hallazgos.json) e [inventario de fuentes con hashes](inventario_fuentes.csv).

El informe reconstruye W1–W29, separa la base y la variante A, identifica doce hallazgos, propone R1 y especifica un plan de ensayos con cargas artificiales antes de conectar los receptores. La propuesta R1 no modifica el montaje existente ni acredita que las correcciones estén implementadas.

### Qué se ha ejecutado

- **548 escenarios DC normales y 23 de fallo**, con cargas ideales de corriente o potencia constante.
- **26 comprobaciones de conectividad**, incluidas inversión del Schuko y apertura del puente PE.
- **Seis casos extremos de R1** con todos los máximos de resistencia simultáneos.
- Verificaciones analíticas de ley de Ohm, raíz de carga CP, reparto de corriente, KCL y conservación de potencia; cálculos de integración adicionales.

**No se ha ensayado hardware físico.** Los modelos no son SPICE ni modelos internos de los componentes. Los PASS de los programas comprueban su cálculo; los fallos de diseño mantienen su veredicto propio. Las corrientes de cortocircuito obtenidas con fuente ideal y marcadas fuera de rango no se atribuyen a la fuente real.

Las rutas del inventario y los campos `local` de las fuentes se refieren al repositorio auditado, no a archivos incluidos en este ZIP; los cuatro modelos se ejecutan sin descargar ese repositorio.

### Reproducir los cálculos

Se requiere Python 3.10 o posterior. Los modelos sólo utilizan su biblioteca estándar y no necesitan red, credenciales ni hardware. Ejecutar desde esta carpeta:

```bash
python3 modelos/model_dc.py --output-dir resultados
python3 modelos/model_topology.py --out resultados
python3 modelos/model_integration.py --out resultados
python3 modelos/model_r1_corner.py --out resultados
```

Los comandos generan el JSON completo y los CSV. La copia incluida de `dc_results.json` está comprimida como [dc_results.json.gz](resultados/dc_results.json.gz); puede abrirse con cualquier descompresor gzip. Los CSV contienen los resultados principales sin comprimir.

| Archivo | Contenido |
|---|---|
| [dc_scenarios.csv](resultados/dc_scenarios.csv) | Tensiones, corrientes, resistencias e hipótesis de 548 escenarios |
| [dc_faults.csv](resultados/dc_faults.csv) | 23 escenarios de aperturas, retornos paralelos y cortocircuitos |
| [dc_validation.json](resultados/dc_validation.json) | Oráculos analíticos y residuos del solucionador |
| [dc_resistance_budgets.csv](resultados/dc_resistance_budgets.csv) | 288 presupuestos de resistencia máxima |
| [topology_results.json](resultados/topology_results.json) | Caminos encontrados y veredictos separados del self-check |
| [netlist_graph.json](resultados/netlist_graph.json) | Grafo de cálculo, sin carácter de archivo de fabricación |
| [integration_results.json](resultados/integration_results.json) | Potencia, condensadores, sobretensión y sensibilidad térmica |
| [r1_corner_validation.json](resultados/r1_corner_validation.json) | Seis extremos R1 y contraste analítico independiente |

### Figuras y documento

Las figuras se generan desde ecuaciones y topología explícitas. Su código requiere `matplotlib`; la generación del DOCX requiere `python-docx` y `pandoc`. Estas dependencias sólo se necesitan para regenerar la presentación, no para los cuatro modelos eléctricos.

```bash
python3 herramientas/generar_figuras.py --output-dir figuras --model modelos/model_dc.py
python3 herramientas/generar_documento.py --source AUDITORIA-AUDITOR-6.md --output Auditoria-Electrica-Auditor-6.docx
```

El PDF se exporta desde el DOCX y se revisa visualmente. [SHA256SUMS.txt](SHA256SUMS.txt) registra los hashes de los entregables de esta revisión.
