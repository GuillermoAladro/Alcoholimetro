#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Cálculos y comprobaciones documentales del diseño eléctrico (Auditor P).

Reconstruye el circuito descrito en MONTAJE-GENERAL.md (commit 84be976,
21-10-2026, diseño del 20-10-2026) como redes eléctricas y ejecuta 14
comprobaciones sobre datos documentados. NOTA IMPORTANTE: no es una
validación ejecutable del circuito ni una simulación eléctrica; los estados
se derivan de condiciones sobre datos documentados e hipótesis declaradas.
Un dato ausente NO es un aprobado.
"""

import json

# ---------------------------------------------------------------- netlist ---
# Redes eléctricas del diseño (W1..W29), tal como las documenta
# MONTAJE-GENERAL.md, apartado 2. Descripción documental de cada red.

NETS = {
    "NET-L":   {"desc": "Fase tras interruptor (caso 1: C14→interruptor A-B→borne 1 AC/L; caso 2: pestaña fase→A-B→borne 1)", "v": "230VAC"},
    "NET-N":   {"desc": "Neutro (caso 1: C14→interruptor C-D→borne 2 AC/N; caso 2: directo a borne 2)", "v": "230VAC"},
    "NET-PE":  {"desc": "Tierra de protección: pin PE C14 → espárrago M4 → FG fuente, panel, caja interior, cajón", "v": "PE"},
    "NET-5V":  {"desc": "+5 V: borne 5 (+V) fuente → WAGO +5V polo 1; polos 2-5 → Pi (VBUS micro-USB), borne USB-A nº1 +, borne USB-A nº2 +, ZE29A pin 1", "v": "5V"},
    "NET-GND": {"desc": "0 V: borne 4 (−V) fuente → WAGO GND polo 1; polos 2-5 → Pi (GND micro-USB), bornes USB-A −, ZE29A pin 2, Pi pin 9 (GND)", "v": "5V-return"},
    "NET-TXD": {"desc": "UART: Pi pin 8 (GPIO14 TXD) → ZE29A pin 4 (RXD)", "v": "3.3V-signal"},
    "NET-RXD": {"desc": "UART: ZE29A pin 3 (TXD) → Pi pin 10 (GPIO15 RXD)", "v": "3.3V-signal"},
    "NET-BTN": {"desc": "Pulsador: faston A → Pi pin 11 (GPIO17, pull-up interno); faston B → Pi pin 9 (GND)", "v": "3.3V-signal/GND"},
}

# Asignación de bornes de la fuente según MONTAJE-GENERAL (W4, W5, W7, W11, W12)
PSU_BORNES_MONTAJE = {"1": "AC/L", "2": "AC/N", "3": "FG", "4": "DC-V", "5": "DC+V"}
# Asignación según la fila «Bornes» de la ficha #14 (H22)
PSU_BORNES_FICHA14 = {"1": "DC-V", "2": "DC+V", "3": "FG", "4": "AC/L", "5": "AC/N"}
# Asignación leída en las copias locales del datasheet (extraída con pdftotext)
PSU_BORNES_PDF_LOCAL = {"1": "AC/L", "2": "AC/N", "3": "FG", "4": "DC-V", "5": "DC+V"}

# Pines del ZE29A según el manual V1.1 (copia local verificada con pdftotext)
ZE29A_PINS = {1: "Vin 5V", 2: "GND", 3: "TXD 3.3V", 4: "RXD 3.3V"}

# GPIO de la Pi 3B+ (pinout estándar de la cabecera de 40 pines)
PI_HEADER_5V = {2, 4}
PI_HEADER_33V = {1, 3}
PI_HEADER = {8: "GPIO14/TXD0", 9: "GND", 10: "GPIO15/RXD0", 11: "GPIO17"}

# Consumos ESTIMADOS (guía §3 y fichas; hipótesis declaradas, no medidas)
LOADS = {
    "Pi total por micro-USB": {"typ": 0.95, "peak": 1.45, "src": "RPi 0,5 + cámara 0,25 + AR9271 0,3 (fuentes de fichas)"},
    "SumUp Solo":             {"typ": 0.80, "peak": 2.00, "src": "guía §3 (estimación, sin fuente)"},
    "Pantalla 7\"":           {"typ": 0.50, "peak": 0.50, "src": "guía §3 (estimación, sin fuente)"},
    "ZE29A":                  {"typ": 0.10, "peak": 0.50, "src": "manual: <500 mA (máximo, sin típico)"},
}

results = []
def check(cid, name, criteria, result, evidence, status):
    results.append({"id": cid, "prueba": name, "criterio": criteria,
                    "resultado": result, "evidencia": evidence, "estado": status})

# ------------------------------------------------------------------ C-01 ---
# Coherencia interna: numeración de bornes de la fuente
ficha14_wrong = PSU_BORNES_FICHA14 != PSU_BORNES_PDF_LOCAL
montaje_right = PSU_BORNES_MONTAJE == PSU_BORNES_PDF_LOCAL
check("C-01", "Numeración de bornes de la LRS-50-5",
      "MONTAJE-GENERAL, ficha #14 y datasheet local deben coincidir",
      f"MONTAJE-GENERAL y el PDF local coinciden: {montaje_right}. La fila «Bornes» de la "
      "ficha #14 da el orden inverso al del PDF local.",
      "pdftotext de LRS-50-SPEC.pdf, MEAN_WELL_LRS-50_DATA_SHEET.pdf y LRS-50-5.pdf: "
      "'Pin 1 AC/L, 2 AC/N, 3 FG, 4 DC OUTPUT -V, 5 DC OUTPUT +V'",
      "NO CONFORME (documentación)" if ficha14_wrong else "CONFORME")

# ------------------------------------------------------------------ C-02 ---
# Pines del ZE29A
ze29a_ok = (ZE29A_PINS[1] == "Vin 5V" and ZE29A_PINS[3] == "TXD 3.3V"
            and ZE29A_PINS[4] == "RXD 3.3V")
check("C-02", "Pinout del ZE29A (manual V1.1)",
      "Pines 1 Vin, 2 GND, 3 TXD, 4 RXD a 3,3 V; W19/W20 cruzan TX↔RX",
      "El manual local confirma el pinout; W19 (Pi8→sensor RX) y W20 (sensor TX→Pi10) "
      "están correctamente cruzadas. Compatibilidad documental, no ensayo.",
      "pdftotext ze29a-c2h5oh.pdf: 'PIN Definition: 1 Vin (voltage input 5V), 2 GND, "
      "3 UART (TXD) 3.3V TTL OUTPUT, 4 UART (RXD) 3.3V TTL INPUT'",
      "CONFORME (documental)" if ze29a_ok else "NO CONFORME")

# ------------------------------------------------------------------ C-03 ---
# Mapa GPIO
used = {8, 9, 10, 11}
conflict = sorted(used & (PI_HEADER_5V | PI_HEADER_33V))
dup = len(used) != len(set(used))
check("C-03", "Mapa de pines GPIO (W19-W22)",
      "Pines 8/9/10/11 usados una sola vez, ninguno en 5 V (2, 4) ni 3,3 V (1, 3)",
      "Sin conflictos: 8=TXD, 10=RXD (UART cruzada), 9=GND, 11=GPIO17 con pull-up interno."
      + (" CONFLICTO DETECTADO: " + str(conflict) if conflict else ""),
      "Pinout estándar Pi 3B+; figura 3 del repositorio",
      "CONFORME (documental) con advertencia: un alojamiento Dupont desplazado hacia el "
      "pin 1 puede caer en los pines de 5 V (riesgo documentado en la figura 3)")

# ------------------------------------------------------------------ C-04 ---
# Dominios de tensión
check("C-04", "Dominios de tensión por red",
      "Cada red pertenece a un único dominio (230 V, PE, 5 V, 3,3 V)",
      "Redes separadas en el papel: L/N (230 V), PE, +5 V/GND, TXD/RXD/botón (3,3 V). "
      "La unión −V↔PE queda SIN DECIDIR (W12) y el jack RP-SMA de panel puede unir la "
      "malla del coaxial a PE por contacto mecánico (W26). No se puede verificar la "
      "configuración real de masas sin medir la máquina.",
      "MONTAJE-GENERAL apartados 2B y 5.2; fichas #14, #13 y #30",
      "NO VERIFICABLE (decisión de diseño abierta)")

# ------------------------------------------------------------------ C-05 ---
# Presupuesto de corriente
typ_total = sum(v["typ"] for v in LOADS.values())
peak_total = sum(v["peak"] for v in LOADS.values())
src_cap = 10.0
ocp_low = 1.10 * 50 / 5.20    # 110 % de 50 W a 5,20 V
ocp_high = 1.50 * 50 / 5.20   # 150 % de 50 W a 5,20 V
cable_amp = 6.0  # 0,75 mm² (valor documentado en fichas, no medido)
check("C-05", "Presupuesto de corriente del raíl de 5 V (hipótesis declaradas)",
      "Consumo estimado ≤ capacidad de la fuente; cada conductor ≤ su asignación",
      f"Con consumos ESTIMADOS: típico {typ_total:.2f} A, pico {peak_total:.2f} A "
      f"(23-50 % de 10 A; la fuente sobra con estos datos). PERO el OCP de la fuente "
      f"actúa entre {ocp_low:.1f} y {ocp_high:.1f} A, por encima de los {cable_amp:.0f} A "
      "asignados al cable de 0,75 mm², y actúa en modo hiccup (reintenta): no hay "
      "demostración de que un fallo en una rama quede cortado por nada antes del cable. "
      "Falta fusible o PTC por rama y falta protección del troncal.",
      "LRS-50: OCP 110-150 % hiccup (ficha #14); cable 0,75 mm²: 6 A (ficha #21); "
      "guía §3: pico 5 A estimado",
      "NO CONFORME: sin protección demostrada por rama ni del troncal")

# ------------------------------------------------------------------ C-06 ---
# Fusible de entrada vs arranque (escenario ilustrativo)
i2t_inrush_low = 0.5 * 45**2 * 0.00072   # 100 µF, τ=0,72 ms
i2t_inrush_high = 0.5 * 45**2 * 0.0016   # 220 µF, τ=1,6 ms
allowed = 22.29 * 0.22
check("C-06", "Fusible T2,5A frente al pico de arranque (escenario ilustrativo)",
      "I²t del pulso ≤ 22 % del I²t nominal de fusión (criterio Littelfuse)",
      f"Escenario con condensador de entrada SUPUESTO (no publicado): pulso ≈ "
      f"{i2t_inrush_low:.1f}-{i2t_inrush_high:.1f} A²s frente a {allowed:.1f} A²s "
      "admisibles (margen 3-7×). Conclusión: no se ve incompatibilidad MANIFIESTA. "
      "NO es una aprobación: el condensador real no consta y el fusible concreto de "
      "Amazon (#16) no publica hoja de datos; la coordinación queda sin demostrar.",
      "Littelfuse 215 T2,5A (familia de referencia, no la pieza #16): 22,29 A²s; "
      "LRS-50: 45 A típ. en frío a 230 VAC",
      "NO VERIFICABLE (escenario ilustrativo con hipótesis)")

# ------------------------------------------------------------------ C-07 ---
# Márgenes de tensión (escenario conservador)
v_set = 5.20
worst_up = v_set * (1 + 0.005 + 0.010 + 0.0003 * 30)     # escenario conservador
v_drop_pi = 0.35                                           # hipótesis de la ficha #19
v_pi_peak = v_set - v_drop_pi
v_pi_at_510 = 5.10 - v_drop_pi
check("C-07", "Márgenes de tensión de la salida de 5 V (escenario conservador)",
      "Máximo peor caso ≤ 5,3 V (ZE29A); mínimo en la Pi ≥ umbral de subtensión",
      f"Escenario conservador con ajuste a {v_set} V: máximo ≈ {worst_up:.2f} V (supera "
      "los 5,3 V del ZE29A solo por suma de tolerancias; no evidencia de la unidad real). "
      f"Con la caída hipotética de {v_drop_pi} V a 2 A, la Pi quedaría a ≈ {v_pi_peak:.2f} V "
      f"(ajuste a 5,10 V: ≈ {v_pi_at_510:.2f} V). CONSECUENCIA: no existe todavía un ajuste "
      "aprobado global; con 5,10-5,15 V y esa caída, la Pi queda por debajo de 4,9 V. "
      "Hacen falta las caídas y consumos REALES (pantalla y Solo sin verificar) para fijar "
      "un intervalo admisible común.",
      "Tolerancias de la hoja LRS (±0,5 % línea, ±1 % carga, ±0,03 %/°C); ficha #19 "
      "caso D; umbral Pi 4,63 V (dato no oficial, banda hasta 4,86 V)",
      "NO CONFORME (marginal) + SIN AJUSTE APROBADO: medir caídas y consumos reales "
      "antes de fijar la tensión")

# ------------------------------------------------------------------ C-08 ---
# Protocolo UART: checksums (condición ejecutable)
def cksum(frame):
    return (-(sum(frame[1:8]))) & 0xFF

frames = {
    "0x85 estado":       ([0xFF,0x01,0x85,0,0,0,0,0], 0x7A),
    "0x86 resultado":   ([0xFF,0x01,0x86,0,0,0,0,0], 0x79),
    "0x87 cambiar":      ([0xFF,0x01,0x87,0x31,0,0,0,0], 0x47),
    "0x88 leer t":       ([0xFF,0x01,0x88,0,0,0,0,0], 0x77),
    "0x89 fijar t 4s":   ([0xFF,0x01,0x89,0x04,0,0,0,0], 0x72),
    "0x90 leer umbral":  ([0xFF,0x01,0x90,0,0,0,0,0], 0x6F),
    "0x91 fijar 14/50":  ([0xFF,0x01,0x91,0x14,0x50,0,0,0], 0x0A),
    "0x92 leer presión": ([0xFF,0x01,0x92,0,0,0,0,0], 0x6D),
    "0x93 fijar presión": ([0xFF,0x01,0x93,0x08,0,0,0,0], 0x64),
    "0x87 precalentar":  ([0xFF,0x01,0x87,0x32,0,0,0,0], 0x46),
    "0x89 t 5s":         ([0xFF,0x01,0x89,0x05,0,0,0,0], 0x71),
}
bad = [(name, hex(cksum(b)), hex(e)) for name, (b, e) in frames.items() if cksum(b) != e]
# Prueba de sensibilidad: un checksum corrupto debe hacer fallar la comprobación
sensitivity = cksum([0xFF,0x01,0x87,0x32,0,0,0,0]) != 0x48  # 0x48 es el erróneo del foro
check("C-08", "Protocolo UART ZE29A: checksums de las tramas documentadas",
      "Recalcular el checksum de cada trama: (−suma bytes 1-7) & 0xFF",
      ("Las 11 tramas documentadas (incluida la de precalentado 0x46) recalculan "
       "correctamente. La variante 0x48 que circula en un foro es errónea (prueba de "
       "sensibilidad superada)." if not bad and sensitivity else
       "FALLOS: " + str(bad)),
      "Recálculo independiente con el algoritmo del manual V1.1",
      "CONFORME (condición ejecutable)" if not bad and sensitivity else "NO CONFORME")

# ------------------------------------------------------------------ C-09 ---
# Topología de tierra
check("C-09", "Topología de tierra de protección (W6-W10)",
      "PE continuo desde el pin del C14 a las piezas metálicas; sin fusible ni "
      "interruptor en el PE",
      "Camino documentado: pin PE → espárrago M4 → FG fuente + panel + caja interior + "
      "cajón. Sin elementos de corte en el PE (correcto). Sección del PE: decisión "
      "abierta (1,5 vs 2,5 mm²; ITC-BT-19 §2.3 es para instalaciones fijas y no se "
      "puede aplicar directamente al cableado interno; EN 60335-1 no se ha podido "
      "leer). Un solo espárrago con 5 ojales: riesgo de punto único a evaluar, no "
      "no conformidad automática. La continuidad real (≤0,1 Ω con 10-25 A) no se "
      "puede verificar sobre papel.",
      "MONTAJE-GENERAL apartado 2A; ITC-BT-19 §2.3; fichas #22, #23, #25",
      "NO VERIFICABLE físicamente; decisión de sección y arquitectura abiertas")

# ------------------------------------------------------------------ C-10 ---
# Camino de red: caso 1 / caso 2 del interruptor del C14
check("C-10", "Esquema interno del módulo C14 (W2-W5)",
      "Identificar el esquema real antes de cablear; el interruptor y el fusible deben "
      "quedar identificados polo a polo",
      "El anuncio del C14 no da el esquema interno; sus dos dibujos se contradicen y "
      "dos reseñas dicen que están mal. Con enchufe Schuko reversible, un módulo "
      "unipolar deja el fusible y el interruptor en un solo conductor: en la orientación "
      "contraria quedan en el neutro y un fallo de fase a chasis no pasa por ellos. "
      "Una prueba de continuidad NO puede garantizar la fase en ambas orientaciones: "
      "si el módulo es unipolar, la corrección es bipolar (cortar y fusionar los dos "
      "polos) o sustituir el módulo.",
      "MONTAJE-GENERAL apartado 2A (casos 1 y 2); anuncios 21-10-2026; ficha #15 §4-§5",
      "NO CONFORME (bloqueante para cablear la red): medir el módulo suelto; si es "
      "unipolar, sustituir o bipolarizar")

# ------------------------------------------------------------------ C-11 ---
# Elementos deliberadamente sin conectar
check("C-11", "Elementos sin conectar (esperados)",
      "LED del pulsador, hilo S (malla) de los bornes USB-A, base de carga del Solo, "
      "hilos D± del latiguillo micro-USB, cable C-C del Solo",
      "Todos quedan sin conectar por diseño, coherente con las fichas. El LED del "
      "pulsador es de 5 V y no se usa; la malla no se conecta.",
      "MONTAJE-GENERAL W13, W14, W21-W22; fichas #11, #18, #9",
      "CONFORME (documental)")

# ------------------------------------------------------------------ C-12 ---
# Corrientes por conector
check("C-12", "Corriente por el borne USB-A y el conector del Solo",
      "Corriente de rama ≤ asignación del conector (dato que falta)",
      "Pico estimado del Solo 2,0 A frente a 1-1,5 A habituales en receptáculos USB-A "
      "de placa (placas comparables: 0,1-0,5 A); el borne comprado no publica corriente. "
      "El puente D+/D− (BC 1.2 DCP) no está probado con el Solo: su comportamiento de "
      "carga con ese 'cargador' no está documentado. Pantalla ~0,5 A estimados: sin "
      "evidencia contraria.",
      "Ficha #18 apartado 2; ficha #10; Microchip BC 1.2",
      "NO CONFORME (por verificar): medir corriente real del Solo; confirmar el "
      "reconocimiento del puente; verificar la asignación del borne")

# ------------------------------------------------------------------ C-13 ---
# UART de la Pi 3B+
check("C-13", "UART de la Pi 3B+ (PL011 vs mini-UART)",
      "La UART de GPIO14/15 debe ser PL011 para el sensor",
      "En la Pi 3B+ la UART primaria es PL011 pero por defecto la usa el Bluetooth; "
      "hace falta dtoverlay=disable-bt para liberarla. Documentado en el diseño.",
      "Ficha ZE29A §5; documentación Raspberry Pi",
      "CONFORME (requisito de software, pendiente de verificar en la imagen final)")

# ------------------------------------------------------------------ C-14 ---
# Aislamiento 230 V / 5 V
check("C-14", "Separación 230 V / 5 V y bornes al aire de la fuente",
      "Ningún conductor de 5 V junto a bornes de 230 V; bornes inaccesibles",
      "En la regleta de la fuente +V queda junto a FG y FG junto a L (verificado en la "
      "hoja). El cable rojo/negro de 0,75 mm² se anuncia sin vaina y con aislamiento de "
      "50 V. La fuente no tiene tapa de bornes documentada. Requisitos de separación "
      "exactos (distancias, grados) sin evaluar: requieren la norma de producto "
      "aplicable, no leída.",
      "Ficha #14 apartado 4.2 y 5.2; ficha #21 (pendiente #11)",
      "NO CONFORME (seguridad, requisitos por definir): cubrir bornes de 230 V con "
      "protección evaluada y separar físicamente las ramas de 5 V")

# ---------------------------------------------------------------- resumen ---
totals = {}
for r in results:
    key = r["estado"].split(" (")[0].split(":")[0].strip()
    totals[key] = totals.get(key, 0) + 1

out = {
    "nota": "Comprobaciones documentales y cálculos reproducibles sobre la "
            "reconstrucción del diseño. No es una validación ejecutable del circuito "
            "ni una simulación eléctrica; no hay mediciones físicas.",
    "commit_auditado": "84be976",
    "fecha": "21-10-2026",
    "auditor": "Auditor P",
    "resultados": results,
    "resumen": totals,
    "pruebas_totales": len(results),
}
print(json.dumps(out, ensure_ascii=False, indent=1))
