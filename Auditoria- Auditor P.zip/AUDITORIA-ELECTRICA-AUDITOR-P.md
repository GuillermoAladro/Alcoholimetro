# AUDITORÍA ELÉCTRICA DOCUMENTAL (PRELIMINAR) DEL DISEÑO — Alcoholímetro de pago

**Auditor:** Auditor P
**Fecha de la auditoría:** 21-10-2026
**Objeto auditado:** diseño eléctrico de la máquina descrito en [`MONTAJE-GENERAL.md`](MONTAJE-GENERAL.md) y las 31 fichas de [`componentes/`](componentes/README.md), en el commit `84be976` («Añade LISTA-DE-COMPRA.md», rama `main`). Esta auditoría cubre el **diseño del 20-10-2026** (el de la guía de cableado y `decisiones-diseno.md`); el «diseño A» del 21-10-2026 **no está aprobado ni cubierto** por este documento (ver H14).
**Método:** reconstrucción documental del circuito (redes W1–W29), comprobaciones documentales y cálculos reproducibles por script ([`auditoria/verificacion_circuito.py`](auditoria/verificacion_circuito.py), resultados en [`auditoria/resultados_verificacion.json`](auditoria/resultados_verificacion.json)) y contraste con las copias locales de las hojas de datos. **No se ha realizado ninguna medición física: nada está montado ni energizado.**

---

## 1. Dictamen ejecutivo

**No se autoriza la energización de la máquina.** El resultado de la revisión es: el diseño documentado es coherente en su topología (las conexiones verificadas son compatibles entre sí: UART cruzada, mapa de pines, protocolo del sensor, presupuesto de corriente con datos estimados), pero quedan **requisitos críticos sin cerrar** — protecciones, esquema del módulo de red, decisiones de tierra y de masas, y ajuste de tensión — y **el funcionamiento conjunto del circuito no está demostrado ni puede demostrarse sobre papel**. Esta auditoría es una revisión documental preliminar: la cobertura del repositorio es parcial (apartado 3), no se ha simulado el circuito eléctricamente ni nada está montado. El usuario pidió leer «absolutamente todos los archivos» y comprobar el funcionamiento: eso queda **pendiente**; este documento entrega lo verificable hoy y declara lo que falta.

**Qué se ha confirmado documentalmente** (C-02, C-03, C-08, C-11, C-13):

- La UART Pi↔ZE29A está correctamente cruzada (TX→RX en ambos sentidos), con niveles compatibles a 3,3 V.
- El protocolo del ZE29A recalcula todos sus checksums correctamente (condición ejecutable); la trama de arranque correcta es la que acaba en `0x46`; la variante `0x48` que circula en un foro es errónea.
- El mapa de pines 8/9/10/11 no choca con nada y no usa pines de 5 V.
- Los elementos que quedan sin conectar (LED del pulsador, malla de los bornes USB-A, hilos de datos del latiguillo) están sin conectar por diseño.
- El ajuste a 5,20 V del proyecto es compatible *a priori* con la fuente (ver H6 para el ajuste definitivo).

**Requisitos críticos sin cerrar** (hallazgos H1–H15, apartado 6):

1. **El esquema interno del módulo C14 es desconocido** y el interruptor puede resultar unipolar: con un enchufe Schuko reversible, el fusible y el interruptor pueden quedar en el **neutro** y no en la fase (H1). Bloquea el cableado de red.
2. **El raíl de 5 V no tiene protección por rama demostrada** y la protección de la fuente actúa entre ≈10,6 y 14,4 A, por encima de los 6 A asignados al cable de 0,75 mm² (H2).
3. **La ficha de la fuente (#14) contradice al MONTAJE-GENERAL en la numeración de los bornes**; verificado contra las copias locales de la hoja de datos: el MONTAJE-GENERAL está bien y la ficha está mal (H3). Seguir la ficha pondría 230 V en la salida de 5 V.
4. **Los bornes de 230 V de la fuente quedan al aire**, sin tapa documentada, y el cable de 5 V sin vaina baja junto a la regleta donde +V toca a FG y FG a L (H4).
5. **Tierra y masas con decisiones abiertas**: sección del PE, arquitectura del punto de tierra, unión −V↔PE y la unión de malla del coaxial a través del jack de panel (H5, H8).

**Dictamen: NO APTO PARA ENERGIZAR en su estado actual**, como resultado de una evaluación con requisitos críticos abiertos, no como lista de cuatro arreglos garantizados. Las correcciones propuestas en el apartado 7 son recomendaciones de auditoría que el autor del proyecto debe validar; el plan de verificación física del apartado 8 es la vía para cerrar los requisitos.

## 2. Alcance y limitaciones

- Es una **auditoría documental y de coherencia de diseño**: se reconstruyó el circuito a partir de `MONTAJE-GENERAL.md` y se contrastó con las fichas, los anuncios y las hojas de datos locales. Las comprobaciones del apartado 5 son condiciones sobre datos documentados e hipótesis declaradas (el script las hace reproducibles); **no son una simulación eléctrica ni un ensayo físico**.
- Un dato ausente **no** cuenta como aprobado: se marca «no verificable».
- Los consumos del Solo y de la pantalla son estimaciones de la guía, no medidas.
- Las soluciones propuestas requieren validación del autor del proyecto; donde falta un dato (norma de producto, curva de fusible, consumo real), el requisito queda expresamente abierto.

## 3. Versión y cobertura real

- **Commit auditado:** `84be97669a9efec43e79b3dadc4af5e87458c41a` (rama `main`, 234 archivos, 36 commits).
- **Leído completo:** `README.md`, `LISTA-DE-COMPRA.md`, `MONTAJE-GENERAL.md`, `componentes/README.md`, `componentes/pendientes.md`, `montaje-general/anuncios-amazon-21-10-2026.md`, la ficha de la fuente (#14) y la del sensor (#6) completas.
- **Leído en su sección de resumen y discrepancias** (no completo): las otras 29 fichas de `componentes/*/README.md`.
- **Verificado contra copia local (extracción de texto):** hoja LRS-50 (tres PDF: `LRS-50-SPEC.pdf`, `MEAN_WELL_LRS-50_DATA_SHEET.pdf`, `LRS-50-5.pdf`): numeración de bornes; manual ZE29A V1.1 (`ze29a-c2h5oh.pdf`): pinout y protocolo.
- **Inspeccionado visualmente:** las cuatro figuras del montaje (PNG).
- **No leído:** los 32 `enlaces.md` (índices de enlaces), los ~140 PDF de `datasheets/` (solo páginas clave de los citados arriba), los ZIP de USB-IF y el XLSX del Camera Module. El propio repositorio declara que las copias locales no se leyeron enteras.

La cobertura de los 234 archivos es, por tanto, parcial y así se declara: los hallazgos se apoyan en los documentos de síntesis (MONTAJE-GENERAL, pendientes, fichas) y en las verificaciones puntuales de PDF locales citadas.

## 4. Circuito reconstruido (netlist documental)

Reconstrucción del diseño como redes eléctricas. La fuente de cada conexión es el apartado 2 del `MONTAJE-GENERAL.md`.

| Red | Tensión | Nodos que une |
|---|---|---|
| NET-L | 230 V (fase) | C14 (pestaña del portafusibles T2,5A) → interruptor A–B → borne 1 (AC/L) de la LRS-50-5 *(caso 2: fase → A–B → borne 1; neutro directo)* |
| NET-N | 230 V (neutro) | C14 → interruptor C–D → borne 2 (AC/N) *(caso 2: C14 → borne 2 directo)* |
| NET-PE | Tierra de protección | Pin PE del C14 → espárrago M4 × 20 soldado al cuerpo → FG de la fuente (borne 3), panel frontal, caja interior suspendida y cajón (W6–W10) |
| NET-5V | +5 V | Borne 5 (+V) → WAGO «+5 V» polo 1; polos 2–5 → VBUS micro-USB de la Pi, tornillo «+» del borne USB-A nº 1 (Solo) y nº 2 (pantalla), pin 1 del ZE29A |
| NET-GND | 0 V (retorno de 5 V) | Borne 4 (−V) → WAGO «GND» polo 1; polos 2–5 → GND micro-USB de la Pi, tornillo «−» de ambos bornes USB-A, pin 2 del ZE29A y pin 9 (GND) de la Pi |
| NET-TXD | 3,3 V (señal) | Pi pin 8 (GPIO14/TXD) → ZE29A pin 4 (RXD) |
| NET-RXD | 3,3 V (señal) | ZE29A pin 3 (TXD) → Pi pin 10 (GPIO15/RXD) |
| NET-BTN | 3,3 V / GND | Pulsador faston A → Pi pin 11 (GPIO17, pull-up interno); faston B → Pi pin 9 (GND) |

**Otros enlaces:** HDMI (Pi → pantalla), CSI (FFC de 15 pines, Pi → cámara), USB (Pi → AR9271, único consumidor USB de la Pi), alargo RP-SMA (AR9271 → jack de panel en el techo), tubo de silicona (boquilla → ZE29A), Wi-Fi 2,4 GHz (Pi y Solo → router del bar; sin cable entre Pi y Solo). Los hilos D+ y D− de cada borne USB-A van unidos entre sí (puente BC 1.2); la malla (tornillo «S») queda sin conectar. El pin CC del cable USB-A→USB-C del Solo debe llevar 56 kΩ a VBUS (sin verificar).

**Numeración de bornes de la fuente (verificada contra las copias locales):** 1 = AC/L, 2 = AC/N, 3 = FG, 4 = −V, 5 = +V. El `MONTAJE-GENERAL` la usa correctamente; la fila «Bornes» de la ficha #14 la invierte (ver H3).

## 5. Comprobaciones documentales y cálculos reproducibles

Catorce comprobaciones (C-01 a C-14), reproducibles con `python3 auditoria/verificacion_circuito.py`; salida íntegra en `auditoria/resultados_verificacion.json`. **Advertencia de método:** los estados se derivan de condiciones sobre datos documentados e hipótesis declaradas (consumos estimados, condensador de entrada supuesto, familia de fusible de referencia); solo C-08 (checksums) es una condición ejecutable con prueba de sensibilidad. Resumen: **5 conformes, 6 no conformes, 3 no verificables.**

| ID | Prueba | Criterio | Resultado | Estado |
|---|---|---|---|---|
| C-01 | Bornes de la LRS-50-5 | MONTAJE-GENERAL = ficha #14 = PDF local | El PDF local confirma al MONTAJE-GENERAL (1=L, 2=N, 3=FG, 4=−V, 5=+V); la ficha #14 da el orden inverso | **NO CONFORME (documentación)** |
| C-02 | Pinout ZE29A | Manual V1.1 local | Pines 1 Vin, 2 GND, 3 TXD, 4 RXD a 3,3 V; W19/W20 cruzadas correctamente | CONFORME (documental) |
| C-03 | Mapa GPIO (W19–W22) | Pines usados una vez, ninguno de 5 V | 8/9/10/11 sin conflictos; riesgo documentado de alojamiento Dupont corrido | CONFORME (documental) con advertencia |
| C-04 | Dominios de tensión | Una red = un dominio | Sin mezclas en el papel; la unión −V↔PE sin decidir y el jack RP-SMA puede unir la malla a PE por contacto | NO VERIFICABLE (decisión abierta) |
| C-05 | Presupuesto de corriente | Consumo estimado ≤ capacidad; conductor ≤ asignación | Típico 2,35 A / pico 4,45 A estimados (23–50 % de 10 A). OCP de la fuente entre ≈10,6 y 14,4 A > 6 A del cable, en modo hiccup: sin protección demostrada por rama ni del troncal | **NO CONFORME** |
| C-06 | Fusible T2,5A vs arranque | I²t del pulso ≤ 22 % del nominal | Escenario ilustrativo con condensador supuesto: pulso ≈ 0,7–1,6 A²s frente a 4,9 A²s admisibles (margen 3–7×). Sin incompatibilidad manifiesta; la coordinación queda sin demostrar (condensador real y fusible #16 sin hoja) | NO VERIFICABLE (escenario) |
| C-07 | Márgenes de tensión | Máx ≤ 5,3 V (ZE29A); mín en Pi ≥ umbral | Escenario conservador: 5,20 V → ≈5,32 V (solo suma de tolerancias). Con caída hipotética de 0,35 V, la Pi queda a ≈4,85 V; con ajuste a 5,10 V, a ≈4,75 V. **No existe aún un ajuste aprobado** | **NO CONFORME (marginal) + sin ajuste aprobado** |
| C-08 | Checksums del protocolo | (−suma b1–b7) & 0xFF, con prueba de sensibilidad | Las 11 tramas documentadas recalculan bien; `0x48` erróneo, vale `0x46` | CONFORME (ejecutable) |
| C-09 | Topología de tierra | PE continuo, sin corte | Camino correcto y sin corte en el PE. Sección: decisión abierta (ITC-BT-19 es de instalaciones fijas; EN 60335-1 no leída). Un espárrago con 5 ojales: riesgo a evaluar, no no conformidad automática. Continuidad real no verificable en papel | NO VERIFICABLE físicamente; decisiones abiertas |
| C-10 | Esquema del C14 (W2–W5) | Identificar esquema real; fusible e interruptor en polos identificados | Anuncio contradictorio; con Schuko reversible, un módulo unipolar deja fusible e interruptor en un solo conductor, que puede ser el neutro. Una prueba de continuidad no puede garantizar la fase en ambas orientaciones | **NO CONFORME (bloqueante para cablear)** |
| C-11 | Elementos sin conectar | LED pulsador, malla, D± del latiguillo, base del Solo | Sin conectar por diseño, coherente | CONFORME (documental) |
| C-12 | Corriente por borne USB-A | Corriente ≤ asignación del conector (dato que falta) | Pico estimado del Solo 2 A frente a 1–1,5 A habituales (placas comparables 0,1–0,5 A); el borne no publica corriente: **capacidad no verificable y selección no justificada** (no hay sobrecarga demostrada); puente D+/D− no probado con el Solo y comportamiento de carga sin documentar | NO CONFORME (por verificar) |
| C-13 | UART de la Pi 3B+ | PL011 en GPIO14/15 | Requiere `dtoverlay=disable-bt` (documentado) | CONFORME (pendiente de verificar en la imagen final) |
| C-14 | Separación 230 V / 5 V | Bornes cubiertos, conductores separados | +V junto a FG y FG junto a L; cable de 5 V sin vaina y de 50 V anunciados junto a la regleta; fuente sin tapa de bornes documentada. Requisitos exactos de separación por definir (norma de producto no leída) | **NO CONFORME (seguridad, requisitos por definir)** |

## 6. Hallazgos y soluciones

Ordenados por gravedad. Cada hallazgo indica la conexión afectada, la evidencia, la consecuencia, la solución propuesta (sujeta a validación del autor) y la prueba de aceptación. **Las soluciones no están aprobadas por esta auditoría: son propuestas para cerrar cada requisito.**

### H1 — CRÍTICO (bloquea el cableado de red): el módulo C14 puede dejar el fusible y el interruptor en el neutro

- **Afecta:** W2, W3, W4, W5.
- **Evidencia:** el anuncio del C14 da dos dibujos de cableado que se contradicen y dos reseñas dicen que están mal; el proyecto lo reconoce y define los casos 1 y 2 (`MONTAJE-GENERAL.md` §2A). El enchufe Schuko es reversible.
- **Consecuencia:** si el interruptor es unipolar, en una de las dos orientaciones del enchufe el fusible T2,5A y el interruptor quedan en el **neutro**: un fallo de aislamiento de fase a chasis no es cortado por ellos; solo protegen las protecciones generales del local. La lámpara mal cableada queda permanentemente encendida.
- **Límite de la verificación:** una prueba de continuidad **no puede garantizar** que el fusible quede en la fase en ambas orientaciones del enchufe; lo que la prueba puede hacer es identificar el esquema real del módulo (cuántos polos corta el interruptor, qué polo lleva fusible).
- **Solución:** ejecutar el protocolo de medida del módulo suelto (apartado 4.1 del MONTAJE-GENERAL) antes de cablear, para identificar el esquema real (cuántos polos corta el interruptor, qué polo lleva fusible). Si resulta unipolar, no existe en este proyecto una solución genérica cerrada: se necesita una solución de desconexión y protección **documentada y evaluada para este aparato** (módulo bipolar con esquema verificado, u otra arquitectura justificada por cálculo y norma aplicable), decidida por el autor del proyecto con evaluación competente. «Aceptar el riesgo por escrito» no cierra el requisito. Comprobar además que la lámpara del interruptor es de 230 V (una de 12 V se quema).
- **Prueba de aceptación:** esquema real del módulo dibujado y archivado tras la medición; solución de desconexión documentada que corte el o los polos que el esquema real requiera, con su justificación archivada.

### H2 — CRÍTICO (protección no demostrada): raíl de 5 V sin protección por rama ni del troncal

- **Afecta:** W11–W18 (todo el raíl de 5 V).
- **Evidencia:** la LRS-50-5 limita al 110–150 % de 50 W, es decir ≈10,6–14,4 A a 5,2 V, en modo *hiccup* (reintenta cíclicamente); el cable de 0,75 mm² está dado para 6 A; los bornes USB-A no publican corriente. Comprobación C-05.
- **Consecuencia:** no hay demostración de que un fallo en una rama quede cortado antes de superar la asignación del cable: falta la corriente efectiva, la duración, el ciclo de reintento y la coordinación térmica para afirmar que el cable se sobrecalienta necesariamente, pero también falta cualquier elemento que garantice lo contrario.
- **Solución (propuesta):** añadir protección por rama **y del troncal**. El «diseño A» cita portafusibles de pie con valores Pi 3 A, Solo 3 A, pantalla 3 A y sensor 2 A: son **valores citados del diseño A, pendientes de validación** — no protegen automáticamente los conectores de 1–1,5 A (C-12 sigue abierto), no cubren el troncal aguas arriba de ellos, y queda por seleccionar curva, capacidad de corte en continua, condiciones térmicas y márgenes de arranque. El troncal de 0,75 mm² necesita además su propio fusible (o un calibre mayor justificado por cálculo).
- **Prueba de aceptación:** ensayo de banco definido, limitado y supervisado (no en la máquina montada): con una fuente de laboratorio y una carga de prueba, verificar que cada fusible de rama abre a la corriente esperada y que el fusible del troncal coordina con ellos.

### H3 — GRAVE (documentación): la ficha de la fuente contradice al MONTAJE-GENERAL en los bornes

- **Afecta:** W4, W5, W7, W11, W12 (todas las conexiones a la fuente).
- **Evidencia:** la fila «Bornes» de la ficha #14 (§2) dice «1 = −V, 2 = +V, 3 = FG, 4 = AC/L, 5 = AC/N»; el `MONTAJE-GENERAL` dice «1 (AC/L), 2 (AC/N), 3 (FG), 4 (−V), 5 (+V)». **Verificado por el auditor con las copias locales** (`LRS-50-SPEC.pdf`, `MEAN_WELL_LRS-50_DATA_SHEET.pdf`, `LRS-50-5.pdf`): «Pin 1 AC/L, 2 AC/N, 3 FG, 4 DC OUTPUT −V, 5 DC OUTPUT +V». El MONTAJE-GENERAL es correcto.
- **Consecuencia:** quien cablee siguiendo la ficha (y no el montaje) conectaría la red a los bornes de salida: riesgo de choque eléctrico y daños graves o destrucción de los equipos conectados al raíl de 5 V (la secuencia exacta de fallo no está demostrada; el riesgo es suficiente para bloquear el montaje).
- **Solución:** corregir la fila «Bornes» de la ficha #14. La regla de oro documentada se mantiene: comprobar las marcas serigrafiadas en la unidad física antes de conectar.
- **Prueba de aceptación:** la ficha corregida coincide con la serigrafía de la unidad recibida.

### H4 — GRAVE (seguridad): bornes de 230 V al aire y cable de 5 V sin vaina junto a ellos

- **Afecta:** montaje de la fuente y paso del raíl de 5 V.
- **Evidencia:** la LRS-50-5 no tiene tapa de bornes documentada (ficha #14 §5.2); en su regleta +V toca a FG y FG toca a L; el cable rojo/negro de 0,75 mm² se anuncia sin vaina y con aislamiento de 50 V (ficha #21, pendiente #11 de `pendientes.md`).
- **Consecuencia:** riesgo de contacto accidental con bornes de 230 V durante el mantenimiento, y de que un conductor de 5 V con aislamiento insuficiente pase cerca de la regleta de red. Los requisitos exactos de separación (distancias, grados de contaminación) requieren la norma de producto aplicable, no leída en esta auditoría.
- **Solución (propuesta):** cubrir los bornes de 230 V con una protección aislante **evaluada** (material, temperatura de trabajo, inflamabilidad e índice de aislamiento especificados — no cualquier tapa impresa); enrutar el raíl de 5 V separado físicamente de la regleta de la fuente; en el tramo cercano a la red, cable con vaina y aislamiento adecuados a la tensión de red.
- **Prueba de aceptación:** inspección e informe de la protección elegida contra sus datos de material; ningún conductor de 5 V en el entorno inmediato de los bornes de red.

### H5 — GRAVE (decisiones abiertas): tierra con sección, arquitectura y soldadura sin decidir

- **Afecta:** W6–W10 (toda la tierra de protección).
- **Evidencia:** la guía usa 1,5 mm² y los ojales M4 comprados son de 0,5–1,5 mm²; la ITC-BT-19 §2.3 pide 2,5 mm² **para instalaciones fijas**, y no puede aplicarse directamente al cableado interno de la máquina. **Ninguna norma de producto se ha establecido como aplicable en esta auditoría** (EN 60335-1 no se ha podido leer y su aplicabilidad no está determinada). Un solo espárrago M4 con cinco ojales es un punto único de fallo a evaluar; la práctica citada recomienda 2–3 ojales por espárrago, pero no es una obligación normativa. La soldadura del espárrago (punta de encendido por descarga de condensador) no tiene taller ni herramienta confirmados (ficha #25).
- **Consecuencia:** sin decisión de sección y sin ensayo de continuidad, no se puede afirmar que la tierra cumpla su función ante un fallo de aislamiento; los muelles de la caja interior no valen como tierra (ya documentado).
- **Solución (propuesta):** decidir la sección del PE y el método de ensayo contra la norma de producto que se determine aplicable (obtener el texto o evaluación de un laboratorio/persona competente); valorar dos espárragos o un bloque de tierra como mitigación del punto único (no es automáticamente redundante: la unión al cuerpo sigue siendo única); resolver el método de soldadura con el taller de chapa antes de fabricar.
- **Prueba de aceptación:** ensayo de continuidad definido y ejecutado por personal competente, con método, corriente de prueba y criterio justificados, desde el pin PE del C14 a cada pieza metálica (fuente, panel, caja interior, cajón, techo); resultado archivado.

### H6 — MEDIA: no existe todavía un ajuste de tensión aprobado

- **Afecta:** toda la NET-5V.
- **Evidencia:** el escenario conservador con las tolerancias de la hoja (línea ±0,5 %, carga ±1 %, temperatura ±0,03 %/°C) lleva 5,20 V a ≈5,32 V; es una suma de tolerancias, no evidencia de que la unidad supere 5,3 V. Además, con la caída hipotética de 0,35 V a 2 A, ajustar a 5,10–5,15 V dejaría la Pi a ≈4,75–4,80 V: por debajo de un criterio de 4,9 V y acercándose a la banda del umbral de subtensión (4,63 V, dato no oficial con banda hasta 4,86 V). Los consumos reales de pantalla y Solo no están verificados.
- **Consecuencia:** cualquier ajuste fijado ahora (5,20 V o 5,10–5,15 V) puede incumplir el límite de algún elemento o dejar a la Pi sin margen.
- **Solución:** **no fijar el ajuste todavía.** Medir las caídas reales (latiguillo, contactos, fusibles de rama si se añaden), los consumos reales de pantalla y Solo, y el rizado; calcular después un intervalo admisible común (mínimo en la Pi con margen sobre su umbral, máximo en el ZE29A por debajo de 5,3 V con el rizado y las tolerancias contados) y ajustar dentro de él. El umbral de subtensión no sustituye al rango de alimentación garantizado.
- **Prueba de aceptación:** registro de las medidas reales y del intervalo calculado; ajuste anotado; medición en bornes de cada carga en las peores condiciones de carga.

### H7 — MEDIA: borne USB-A y puente D+/D− sin validar frente al Solo

- **Afecta:** W14–W17 (alimentación del Solo y de la pantalla).
- **Evidencia:** el pico estimado del Solo (2 A) supera la asignación habitual de un receptáculo USB-A de placa (1–1,5 A; placas comparables 0,1–0,5 A); el reconocimiento del puente D+/D− como cargador BC 1.2 no está documentado por SumUp; el cable es de terceros y el manual del Solo solo autoriza el cable incluido (C–C, que no entra en el borne).
- **Consecuencia:** el borne puede quedar por encima de su asignación real (desconocida), y el comportamiento de carga del Solo con ese «cargador» no está documentado: puede limitar su carga o no cargar.
- **Solución (propuesta):** obtener la asignación del borne (pedirla al vendedor o medir); medir la corriente real del Solo en carga y en pico; pedir a SumUp por escrito la autorización del cable y del uso desatendido con carga permanente; si el pico confirmado supera la asignación, alimentar el Solo por otro camino (conector clasificado o empalme protegido con fusible de rama).
- **Prueba de aceptación:** corriente medida del Solo por debajo de la asignación del borne con margen; el Solo carga de forma verificable.

### H8 — MEDIA: configuración de masas sin decidir y con una unión no controlada

- **Afecta:** NET-GND, W12, W26.
- **Evidencia:** el −V flota (aislamiento salida-FG de 1,25 kVAC) y el proyecto no ha decidido si unirlo a PE; además el jack RP-SMA de panel toca el techo (que está a tierra) y puede unir la malla del coaxial a tierra por contacto, sin que nadie lo haya decidido (ficha #13 §4.5). Comprobación C-04.
- **Consecuencia:** hay dos cuestiones de masa sin decidir y una unión posible no controlada. **Si el jack realmente une la malla al 0 V del AR9271 y el techo a PE, la salida ya no flota**: las dos configuraciones (flotante real y unida en un punto) son excluyentes y hay que elegir con datos. No se han distinguido en el proyecto la malla USB, la masa de señal y la masa RF.
- **Solución (propuesta):** medir en la máquina montada (sin tensión de red) la continuidad real entre malla del coaxial, 0 V del AR9271, −V de la fuente y PE; con esos datos, decidir una única configuración por escrito: −V flotante de verdad (aislar el jack del techo) o unión deliberada en un único punto documentado.
- **Prueba de aceptación:** registro de las continuidades medidas y de la decisión tomada; la configuración real coincide con lo decidido.

### H9 — MEDIA (verificación en recepción): polaridades, conectores y cables sin confirmar

- **Afecta:** W13 (polaridad del latiguillo micro-USB: rojo = VBUS es convención, no dato), W15 (resistencia de 56 kΩ en el pin CC del cable del Solo y punta acodada), W17 (cable de la pantalla: A→C o C→C), W18 (conector del ZE29A: ¿JST-XH 2,5 mm?), W24 (FFC con contactos en caras opuestas).
- **Evidencia:** los anuncios no lo dicen; el propio proyecto los lista como pendientes (`pendientes.md` §2).
- **Consecuencia:** cada uno puede bloquear el montaje o dañar la Pi (FFC equivocado, según OpenFlexure, «quema la cámara en segundos»; micro-USB invertido destruye la Pi).
- **Solución:** ejecutar el protocolo de recepción del apartado 4 del MONTAJE-GENERAL (medidas 5 a 11) antes de dar tensión a cada rama. Esta auditoría lo refrenda como procedimiento obligatorio.
- **Prueba de aceptación:** cada medida del apartado 4 anotada con su valor y fecha en la ficha del componente.

### H10 — MEDIA: margen de subtensión de la Pi sin medir

- **Afecta:** W13.
- **Evidencia:** a 2 A de pico, contactos micro-USB (hasta 30 mΩ cada uno) + polifusible F1 (15–100 mΩ) + 16 mΩ del latiguillo dejarían el raíl de la Pi en ≈4,85 V con 5,20 V en la WAGO (estimación de la ficha #19); el umbral de aviso (4,63 V, dato no oficial) tiene una banda de tolerancia que llega a 4,86 V.
- **Consecuencia:** avisos de subtensión intermitentes en pico de carga (foto + Wi-Fi + pago), que degradan la fiabilidad 24/7.
- **Solución (propuesta):** medir la tensión en los pines de la Pi con carga real; latiguillo corto y de cobre verificado (≤15 cm). Si aparecen avisos, el diseño debe revisarse (no basta con subir la fuente: ver H6).
- **Prueba de aceptación:** `vcgencmd get_throttled` = `0x0` tras 30 min con la carga plena de trabajo (foto + Wi-Fi + cobro simultáneos).

### H11 — BAJA-MEDIA: riesgo de alojamiento Dupont desplazado

- **Afecta:** W19–W22.
- **Evidencia:** un alojamiento Dupont desplazado dos columnas hacia el pin 1 aterriza en los pines de 5 V (2 y 4); la figura 3 ya lo advierte.
- **Consecuencia:** 5 V en el RX del ZE29A o en GPIO17; riesgo de destrucción.
- **Solución (propuesta):** un alojamiento estándar de 2×3 **puede desplazarse y girarse** sobre la cabecera: no basta con usarlo. Hace falta una disposición realmente polarizada (alojamiento con polarización mecánica que solo encaja en una orientación, marcado de los hilos y verificación visual contra el esquema antes de cada energizado) o una fijación mecánica del haz.
- **Prueba de aceptación:** procedimiento de inspección escrito; verificación visual firmada antes de energizar.

### H12 — BAJA-MEDIA: pulsador con pull-up débil y ambiente de bar

- **Afecta:** W21, W22.
- **Evidencia:** el pull-up interno (50–65 kΩ) deja una corriente de contacto de ~51–66 µA, por debajo de la carga mínima de referencia de los microcontactos; los líquidos derramados pueden leerse como pulsación; sin protección ESD documentada (ficha #11).
- **Consecuencia:** contactos intermitentes con los meses o falsos arranques con el botón mojado.
- **Solución (propuesta):** pull-up externo de 1–4,7 kΩ (y valorar RC en el extremo de la Pi); identificar el par de faston del microinterruptor con el polímetro (el par que cierra al pulsar).
- **Prueba de aceptación:** 100 pulsaciones de prueba registradas por el software sin falsos disparos.

### H13 — BAJA: OVP de la fuente con bloqueo permanente

- **Afecta:** operación de la máquina.
- **Evidencia:** si la OVP actúa (5,9–7,3 V), la fuente se apaga y no se recupera hasta cortar y dar la red otra vez (ficha #14 §5.6).
- **Consecuencia:** máquina muerta en el bar hasta que alguien la apague y encienda.
- **Solución (propuesta):** procedimiento operativo para el dueño del local y vigilancia remota del estado de la máquina (definir el método de vigilancia es parte del diseño).

### H14 — BAJA (decisión de proyecto, no menor para aplicar este informe): dos diseños en conflicto

- **Afecta:** W1, W6–W10, W11–W18, W21–W24, W26, W28 y W29 según qué diseño mande.
- **Evidencia:** el MONTAJE-GENERAL sigue el diseño del 20-10; el «diseño A» del 21-10 (fuera del repositorio, citado en §6.3) cambia el reparto de 5 V (portafusibles), quita el pulsador, cambia el Wi-Fi y la tierra.
- **Consecuencia:** esta auditoría cubre **exclusivamente** el diseño del 20-10; el diseño A **no está aprobado ni auditado**. Montar contra uno u otro sin decidir invalida las conclusiones aplicables.
- **Solución:** decidir por escrito cuál manda y, si manda el A, auditarlo o actualizar el MONTAJE-GENERAL.

### H15 — BAJA: rizado a carga baja sin medir

- **Afecta:** NET-5V.
- **Evidencia:** la nota 7 de la hoja de la fuente: a 5 V y carga 0–50 % (la carga típica estimada es el 23 %) el modo ráfaga puede sacar el rizado de especificación (ficha #14 §5.5).
- **Consecuencia:** posible rizado excesivo para las cargas (la tolerancia del ZE29A y de la pantalla no está publicada).
- **Prueba de aceptación:** medir el rizado en los bornes de cada carga con osciloscopio (20 MHz) en carga típica.

## 7. Diseño corregido propuesto (sujeto a validación)

Cambios propuestos sobre el diseño del 20-10 (los mismos principios habría que revisarlos contra el diseño A):

1. **C14:** medir el módulo según el protocolo §4.1 antes de cablear; si es unipolar, sustituirlo por uno bipolar documentado o bipolarizar la entrada (H1). No dejar el requisito cerrado «por aceptación de riesgo».
2. **Protección del raíl:** fusibles por rama **y del troncal**, con valores, curva, capacidad de corte y coordinación seleccionados por cálculo; los 3/3/3/2 A del diseño A son el punto de partida citado, no una solución validada (H2).
3. **Corregir la fila «Bornes» de la ficha #14** (H3).
4. **Cubrir los bornes de 230 V** con protección evaluada y separar el cableado de 5 V de la regleta de red (H4).
5. **Tierra:** decidir sección y arquitectura contra la norma de producto aplicable; resolver la soldadura del espárrago (H5).
6. **No fijar el ajuste de la fuente** hasta medir caídas y consumos reales; calcular después el intervalo admisible común (H6, H10).
7. **Recepción obligatoria** de cables y conectores según el apartado 4 del MONTAJE-GENERAL (H9).
8. **Disposición Dupont polarizada o fijada** en la cabecera (H11) y pull-up externo en el pulsador (H12).
9. **Decidir la configuración de masas** con medidas reales (H8).
10. El resto del cableado documentado (UART cruzada, HDMI, CSI, USB del AR9271, bornes USB-A con puente D+/D−, tierra sin interruptor ni fusible) es coherente con los datos disponibles y se mantiene, sin que ello constituya aprobación de funcionamiento.

## 8. Plan de verificación física pendiente (orden de puesta en marcha)

Nada de esto se ha ejecutado; es el orden recomendado, sobre la base del apartado 4 del MONTAJE-GENERAL más las correcciones del apartado 7. Los ensayos deben ejecutarlos personas competentes con los métodos y equipos adecuados.

1. Con el módulo C14 suelto y sin tensión: protocolo de medida (H1). Dibujar y archivar el esquema real.
2. Tierra: ensayo de continuidad con método, corriente de prueba y criterio definidos y justificados por personal competente, desde el pin PE a cada pieza metálica (H5).
3. Fuente sola, sin cargas: comprobar las marcas de bornes contra la serigrafía (H3); ajuste de tensión **solo después** de tener las medidas de H6.
4. Recepción de cables y conectores: medidas 5–11 del apartado 4 del MONTAJE-GENERAL (H9).
5. Con todo cableado y sin tensión: continuidad punto a punto de cada W y comprobación de que cada hilo llega al destino documentado. Los ensayos de aislamiento (p. ej. a 500 VDC) deben definirse en configuración, desconexiones y método según fabricantes y norma aplicable, y ejecutarlos personal competente: no se prescriben aquí genéricamente ni con los equipos conectados.
6. Primera energización sin cargas de 5 V (solo fuente): verificar 5 V, ausencia de calentamiento y lámpara/interruptor del C14 según lo medido en el paso 1.
7. Energizar rama a rama con su protección instalada: primero ZE29A (medir TX en reposo ≈3,3 V antes de conectar la UART), luego Pi (con `vcgencmd get_throttled`), luego pantalla, luego Solo.
8. Pruebas funcionales: UART con el sensor (consulta 0x85 y respuesta), botón (100 pulsaciones), foto, pantalla, cobro de prueba con el Solo, Wi-Fi.
9. Pruebas de resistencia: 30 min a plena carga, temperatura interior cerrada (objetivo <40 °C por el Solo), rizado en cargas (H15), recuperación tras corte de red.
10. Repetir 1–9 en la segunda máquina antes de fabricar en cantidad.

## 9. Anexos

### Anexo A — Comprobaciones reproducibles

El script y su salida se entregan como archivos separados junto a este documento en el chat: **`auditoria/verificacion_circuito.py`** (script Python sin dependencias con las 14 comprobaciones documentales C-01 a C-14: condiciones sobre datos documentados, cálculos de presupuesto de corriente, OCP, I²t del arranque y márgenes de tensión, y una condición ejecutable con prueba de sensibilidad para los checksums) y **`auditoria/resultados_verificacion.json`** (salida íntegra con la advertencia de método). Ejecutar: `python3 auditoria/verificacion_circuito.py`.

Fuentes del repositorio auditado (commit `84be976`, enlaces al repositorio público): [MONTAJE-GENERAL.md](https://github.com/GuillermoAladro/Alcoholimetro/blob/84be976/MONTAJE-GENERAL.md) · [componentes/README.md](https://github.com/GuillermoAladro/Alcoholimetro/blob/84be976/componentes/README.md) · [componentes/pendientes.md](https://github.com/GuillermoAladro/Alcoholimetro/blob/84be976/componentes/pendientes.md) · [ficha de la fuente LRS-50-5](https://github.com/GuillermoAladro/Alcoholimetro/blob/84be976/componentes/meanwell-lrs-50-5/README.md) · [ficha del sensor ZE29A](https://github.com/GuillermoAladro/Alcoholimetro/blob/84be976/componentes/winsen-ze29a/README.md).

### Anexo B — Fuentes externas citadas en la verificación

- Hoja LRS-50 de Mean Well (copias locales en `componentes/meanwell-lrs-50-5/datasheets/`): [meanwell.com](https://www.meanwell.com/Upload/PDF/LRS-50/LRS-50-SPEC.PDF) · [copia 2019 (pulsar.pl)](https://lib.pulsar.pl/karta/es/LRS-50-5.pdf)
- Manual ZE29A V1.1 de Winsen (copia local en `componentes/winsen-ze29a/datasheets/`): [winsen-sensor.com](https://www.winsen-sensor.com/d/files/manual/ze29a-c2h5oh.pdf)
- Fusible Littelfuse 215 T2,5A (familia de referencia): [hoja Littelfuse](https://littelfuse.com/~media/electronics/datasheets/fuses/littelfuse_fuse_215_datasheet.pdf.pdf) · [Fuseology Design Guide](https://info.littelfuse.com/hubfs/Fuseology%20Design%20Guide.pdf)
- Documentación de Raspberry Pi (alimentación y pines): [raspberrypi.com](https://www.raspberrypi.com/documentation/computers/raspberry-pi/)
- Carga USB BC 1.2 (puente D+/D−): [Microchip](https://developerhelp.microchip.com/xwiki/bin/view/applications/usb/power-delivery/battery-charging/)
- Pinout GPIO: [pinout.xyz](https://pinout.xyz/pinout/pin11_gpio17)

### Anexo C — Estado de las comprobaciones

| Estado | Comprobaciones |
|---|---|
| CONFORME (documental/ejecutable) | C-02, C-03 (con advertencia), C-08, C-11, C-13 (pendiente de verificar en la imagen) |
| NO CONFORME | C-01, C-05, C-07, C-10, C-12, C-14 |
| NO VERIFICABLE (requiere decisión, hardware o datos) | C-04, C-06, C-09 |

---

**Firmado:** Auditor P — 21-10-2026
Auditoría independiente sobre el diseño documentado en el commit `84be976`. Este documento no modifica los archivos de diseño originales; las correcciones propuestas requieren la validación del autor del proyecto. No se ha subido ningún cambio al repositorio a petición del autor.
